package workbench.arr;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextPane;
import javax.swing.ScrollPaneConstants;
import javax.swing.text.Style;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyledDocument;

import annotation.DocumentAnnotation;
import annotation.EVAnnotation;
import annotation.SnippetAnnotation;
import annotation.Span;

public class DocumentPane extends JPanel implements MouseMotionListener,
		MouseListener, ActionListener {
	EVAnnotation lastSelectedAnnotation = null;
	static JTextPane documentTextPane = null;

	static EvaluationWorkbench arrTool = null;
	static boolean movingMouse = false;

	DocumentPane(EvaluationWorkbench tool) {
		super(new BorderLayout());
		arrTool = tool;
		documentTextPane = new JTextPane();
		documentTextPane.setPreferredSize(new Dimension(750, 750));
		documentTextPane.addMouseListener(this);
		documentTextPane.addMouseMotionListener(this);
		documentTextPane.setEditable(false);
		documentTextPane.setCaretPosition(0);
		if (tool.analysis != null && tool.analysis.selectedDocument != null) {
			documentTextPane.setText(tool.analysis.selectedDocument.getText());
		}
		this.setToolTipText("");
		FlowLayout fl = new FlowLayout();
		fl.setAlignment(FlowLayout.LEFT);
		JPanel bp = new JPanel(fl);
		JButton b = new JButton("Annotate");
		b.addActionListener(this);
		b.setMnemonic(KeyEvent.VK_A);
		bp.add(b);
		add(bp, BorderLayout.PAGE_END);
		JScrollPane jsp = new JScrollPane(documentTextPane,
				ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED,
				ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		jsp.setPreferredSize(new Dimension(750, 250));
		add(jsp, BorderLayout.CENTER);
		this.setOpaque(true);
	}

	public void actionPerformed(ActionEvent e) {
		String command = e.getActionCommand();
	}

	public void setSelectedDocument(String filename) {
		arrTool.getAnalysis().setSelectedAnnotationEvent(filename);
		arrTool.getAnalysis().setSelectedAnnotation();
		DocumentPane.documentTextPane.setText(arrTool.analysis
				.getSelectedDocument().getText());
		documentTextPane.setCaretPosition(0);
		arrTool.getDetailPane().fireAllTableDataChanged();
		highlightSentences(true);
	}

	void highlightSentences() {
		highlightSentences(false);
	}

	void highlightSentences(boolean permitRedo) {
		EVAnnotation selectedAnnotation = arrTool.getAnalysis()
				.getSelectedAnnotation();
		highlightSentences(selectedAnnotation, permitRedo);
	}

	void highlightSentences(EVAnnotation selectedAnnotation, boolean permitRedo) {
		if (arrTool.analysis.selectedDocument == null) {
			return;
		}
		if (!permitRedo && lastSelectedAnnotation == selectedAnnotation) {
			return;
		}
		lastSelectedAnnotation = selectedAnnotation;
		StyledDocument doc = (StyledDocument) documentTextPane.getDocument();
		Style style = doc.addStyle("Color", null);
		Color background = Color.white;
		StyleConstants.setBackground(style, background);
		StyleConstants.setForeground(style, Color.black);
		doc.setCharacterAttributes(0, arrTool.analysis.selectedDocument
				.getText().length(), style, true);
		Vector<EVAnnotation> annotations = arrTool.getAnalysis()
				.getSelectedAnnotationEvent().getSelectedAnnotationCollection()
				.getAnnotations();
		Class selectedLevel = arrTool.getAnalysis().getSelectedLevel();
		for (EVAnnotation annotation : annotations) {
			if (annotation.getClass().equals(selectedLevel)) {
				if (annotation.isHasMismatch()) {
					highlightAnnotation(annotation, doc, style,
							Colors.lightPink);
				} else if (!annotation.equals(selectedAnnotation)) {
					highlightAnnotation(annotation, doc, style,
							getUnselectedColor(annotation));
				}
			}
		}
		if (selectedAnnotation != null) {
			highlightAnnotation(selectedAnnotation, doc, style,
					getSelectedColor(selectedAnnotation));
		}
		setCaretPosition(selectedAnnotation);
	}

	public void setCaretPosition(EVAnnotation annotation) {
		if (annotation != null && annotation.getSpans() != null
				&& arrTool.analysis.selectedDocument != null) {
			int pos = annotation.getSpans().firstElement().getTextStart();
			if (!withUserInteraction()
					&& pos < arrTool.analysis.selectedDocument.getText()
							.length()) {
				documentTextPane.setCaretPosition(pos);
			}
		}
	}

	void highlightAnnotation(EVAnnotation annotation, Color color) {
		StyledDocument doc = (StyledDocument) documentTextPane.getDocument();
		Style style = doc.addStyle("Color", null);
		highlightAnnotation(annotation, doc, style, color);
	}

	void highlightAnnotation(EVAnnotation annotation, StyledDocument doc,
			Style style, Color color) {
		if (annotation != null && annotation.getSpans() != null) {
			StyleConstants.setBackground(style, color);
			for (Span span : annotation.getSpans()) {
				doc.setCharacterAttributes(span.getTextStart(),
						span.getLength() + 1, style, true);
			}
		}
	}

	public void mouseClicked(MouseEvent e) {
		int offset = documentTextPane.viewToModel(e.getPoint());
		if (arrTool.getAnalysis().getSelectedAnnotation() != null) {
			Class level = (arrTool.getAnalysis().isDocumentLevel() ? SnippetAnnotation.class
					: DocumentAnnotation.class);
			EVAnnotation annotation = arrTool.getAnalysis()
					.getSelectedAnnotationEvent()
					.getSelectedAnnotationCollection()
					.getClosestMatchingAnnotation(level, offset);
			arrTool.getAnalysis().setSelectedAnnotation(annotation);
			arrTool.fireAllTableDataChanged();
		}
	}

	public void mouseExited(MouseEvent e) {
	}

	public void mouseEntered(MouseEvent e) {
	}

	public void mousePressed(MouseEvent e) {
	}

	public void mouseReleased(MouseEvent e) {
	}

	public void mouseMoved(MouseEvent e) {
		if (e.isControlDown()) {
			movingMouse = true;
			int offset = documentTextPane.viewToModel(e.getPoint());
			Class level = arrTool.getAnalysis().getSelectedLevel();
			EVAnnotation annotation = arrTool.getAnalysis()
					.getSelectedAnnotationEvent()
					.getSelectedAnnotationCollection()
					.getClosestMatchingAnnotation(level, offset);
			if (annotation != lastSelectedAnnotation) {
				arrTool.getAnalysis().setSelectedAnnotation(annotation);
				if (annotation != null) {
					arrTool.getAccuracyPane().selectByClassification(
							annotation.getClassification());
				}
				arrTool.fireAllTableDataChanged();
			}
			movingMouse = false;
		}
	}

	public void mouseDragged(MouseEvent e) {
	}

	static boolean withUserInteraction() {
		return movingMouse;
	}

	Color getSelectedColor(EVAnnotation annotation) {
		if (arrTool.getAnalysis().isSnippetLevel()) {
			if (annotation != null && annotation.isVerified()) {
				if (annotation.isVerifiedTrue()) {
					return Colors.verifiedSelectedSnippetAnnotationTrue;
				}
				return Colors.verifiedSelectedSnippetAnnotationFalse;
			}
			return Colors.darkTan;
		} else {
			if (annotation != null && annotation.isVerified()) {
				if (annotation.isVerifiedTrue()) {
					return Colors.verifiedSelectedDocumentAnnotationTrue;
				}
				return Colors.verifiedSelectedDocumentAnnotationFalse;
			}
			return Colors.veryDarkBlueGray;
		}
	}

	Color getUnselectedColor(EVAnnotation annotation) {
		if (arrTool.getAnalysis().isSnippetLevel()) {
			if (annotation != null && annotation.isVerified()) {
				if (annotation.isVerifiedTrue()) {
					return Colors.verifiedUnselectedSnippetAnnotationTrue;
				}
				return Colors.verifiedUnselectedSnippetAnnotationFalse;
			}
			return Colors.lightTan;
		} else {
			if (annotation != null && annotation.isVerified()) {
				if (annotation.isVerifiedTrue()) {
					return Colors.verifiedUnselectedDocumentAnnotationTrue;
				}
				return Colors.verifiedUnselectedDocumentAnnotationFalse;
			}
			return Colors.lightBlueGray;
		}
	}

	// Before 1/30/2012
	// Color getSelectedColor() {
	// if (arrTool.getAnalysis().isSnippetLevel()) {
	// return Colors.darkTan;
	// } else {
	// return Colors.veryDarkBlueGray;
	// }
	// }
	//
	// Color getUnselectedColor() {
	// if (arrTool.getAnalysis().isSnippetLevel()) {
	// return Colors.lightTan;
	// } else {
	// return Colors.lightBlueGray;
	// }
	// }

}
