package workbench.arr;

import java.io.File;

import javax.swing.JFileChooser;
import javax.swing.JFrame;

public class ChooseFile {

	public static int maxDocSize = 1000000;

	public static char[] readBuffer = new char[maxDocSize];
	
	
	public static File chooseFile() {
		JFrame frame = new JFrame();
		JFileChooser chooser = new JFileChooser();
		int rv = chooser.showOpenDialog(frame);
		if (rv == JFileChooser.APPROVE_OPTION) {
			return chooser.getSelectedFile();
		}
		return null;
	}
	
	public static File chooseDirectory() {
		JFrame frame = new JFrame();
		JFileChooser chooser = new JFileChooser(); 
	    chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
	    chooser.setAcceptAllFileFilterUsed(false);
	    int rv = chooser.showOpenDialog(frame);
		if (rv == JFileChooser.APPROVE_OPTION) {
			return chooser.getSelectedFile();
		}
		return null;
	}

}
