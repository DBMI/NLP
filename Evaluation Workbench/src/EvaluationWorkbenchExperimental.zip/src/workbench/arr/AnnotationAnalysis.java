package workbench.arr;

import java.io.File;
import java.util.Collections;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

import javax.swing.JFileChooser;
import javax.swing.JFrame;

import onyx.utilities.FUtils;
import onyx.utilities.VUtils;
import onyx.document.document.Document;
import annotation.AnnotationCollection;
import annotation.Classification;
import annotation.DocumentAnnotation;
import annotation.EVAnnotation;
import annotation.SnippetAnnotation;

public class AnnotationAnalysis {
	String directory = null;
	Annotator primaryAnnotator = null;
	Annotator secondaryAnnotator = null;
	EvaluationWorkbench arrTool = null;
	Document selectedDocument = null;
	AnnotationEvent selectedAnnotationEvent = null;
	Vector<Classification> classifications = null;
	Classification selectedClassification = null;
	Hashtable<Document, Vector<AnnotationCollection>> documentAnnotationCollectionMap = new Hashtable();
	Hashtable<Document, AnnotationEvent> annotationEventMap = new Hashtable();
	Hashtable<String, Document> documentHash = new Hashtable();
	Hashtable<String, Annotator> annotatorHash = new Hashtable();
	Hashtable<Classification, Vector<EVAnnotation>> allClassificationAnnotationMap = new Hashtable();
	Hashtable<String, Vector<EVAnnotation>> allAnnotationTypeClassificationMap = new Hashtable();
	Hashtable<Class, Vector<String>> allClassAttributeMap = new Hashtable();
	Hashtable<String, Vector> allClassAttributeValueMap = new Hashtable();
	Hashtable<Class, Vector<String>> allClassRelationMap = new Hashtable();
	EVAnnotation selectedAnnotation = null;
	EVAnnotation primarySelectedAnnotation = null;
	EVAnnotation secondarySelectedAnnotation = null;
	Class selectedLevel = null;
	boolean refreshClassifications = false;

	public AnnotationAnalysis(EvaluationWorkbench arrTool) {
		this.setSelectedLevel(SnippetAnnotation.class, false);// remove
																// DocumentAnnotation
																// temporarily
		this.arrTool = arrTool;
		this.directory = arrTool.getSourceDirectory().getAbsolutePath();
		this.primaryAnnotator = arrTool.getFirstAnnotator();
		this.primaryAnnotator.setPrimary(true);
		this.secondaryAnnotator = arrTool.getSecondAnnotator();
		this.annotatorHash.put(this.getPrimaryAnnotator().getName(),
				this.getPrimaryAnnotator());
		this.annotatorHash.put(this.getSecondaryAnnotator().getName(),
				this.getSecondaryAnnotator());
		String[] children = arrTool.getSourceDirectory().list();
		for (int i = 0; i < children.length; i++) {
			String str = children[i];
			if (str.indexOf(".xml") > 0
					&& (str.indexOf(arrTool.getFirstAnnotator().getName()) >= 0 || str
							.indexOf(arrTool.getSecondAnnotator().getName()) >= 0)) {
				String filename = this.directory + File.separator + str;
				AnnotationCollection ac = new AnnotationCollection(this,
						filename);
				VUtils.pushHashVector(this.documentAnnotationCollectionMap,
						ac.getDocument(), ac);
			}
		}
		for (Enumeration<Document> e = this.documentAnnotationCollectionMap
				.keys(); e.hasMoreElements();) {
			Document document = e.nextElement();
			AnnotationEvent annotationEvent = new AnnotationEvent(this,
					document);
			if (this.selectedAnnotationEvent == null) {
				this.selectedAnnotationEvent = annotationEvent;
			}
			this.annotationEventMap.put(document, annotationEvent);
		}
	}

	public void writeGrAFAnnotations() {
		for (Enumeration<Document> e = this.documentAnnotationCollectionMap
				.keys(); e.hasMoreElements();) {
			Document document = e.nextElement();
			Vector<AnnotationCollection> collections = this.documentAnnotationCollectionMap
					.get(document);
			for (AnnotationCollection ac : collections) {
				ac.writeGrAFAnnotations();
			}
		}
	}

	public void writeOEMResults() {
		Vector<Class> levels = getAllLevels();
		if (levels != null) {
			StringBuffer sb = new StringBuffer();
			for (Class level : levels) {
				GeneralStatistics gs = arrTool.statisticsHash.get(level);
				if (gs == null) {
					Class currentLevel = getSelectedLevel();
					setSelectedLevel(level);
					gs = GeneralStatistics.create(arrTool, null);
					String str = gs.getOEMSummaryString();
					setSelectedLevel(currentLevel);
					sb.append(str);
				}
			}
			JFileChooser chooser = new JFileChooser(arrTool.rootDirectory);
			int rv = chooser.showSaveDialog(new JFrame());
			if (rv == JFileChooser.APPROVE_OPTION) {
				File file = chooser.getSelectedFile();
				FUtils.writeFile(file.getAbsolutePath(), sb.toString());
			}
		}
	}

	public void verifySelectedAnnotation() {
		EVAnnotation primary = this.getPrimarySelectedAnnotation();
		EVAnnotation secondary = this.getSecondarySelectedAnnotation();
		if (primary != null) {
			primary.setVerified(true);
			primary.setVerifiedTrue(true);
			if (secondary != null) {
				secondary.setVerified(true);
				boolean matches = EVAnnotation.isSameClassificationState(
						primary, secondary, primary.getClassification());
				secondary.setVerifiedTrue(matches);
			}
			arrTool.documentPane.highlightSentences();
		}
	}

	public void unverifySelectedAnnotation() {
		EVAnnotation primary = this.getPrimarySelectedAnnotation();
		EVAnnotation secondary = this.getSecondarySelectedAnnotation();
		if (primary != null) {
			primary.setVerified(false);
			primary.setVerifiedTrue(false);
			if (secondary != null) {
				secondary.setVerified(false);
				secondary.setVerifiedTrue(false);
			}
			arrTool.documentPane.highlightSentences();
		}
	}

	public Document getDocument(String filename) {
		Document document = documentHash.get(filename);
		if (document == null) {
			String fullname = this.directory + File.separator + filename;
			String text = FUtils.readFile(fullname);
			document = new Document(filename, null, text);
			documentHash.put(filename, document);
		}
		return document;
	}

	public Vector<Document> getAllDocuments() {
		if (!documentHash.values().isEmpty()) {
			return new Vector(documentHash.values());
		}
		return null;
	}

	public AnnotationEvent getAnnotationEvent(Document document) {
		return this.annotationEventMap.get(document);
	}

	public Vector<AnnotationEvent> getAnnotationEvents() {
		if (this.annotationEventMap.entrySet() != null) {
			return new Vector(this.annotationEventMap.entrySet());
		}
		return null;
	}

	public void selectAnnotationCollection(int col) {
		if (this.getSelectedAnnotationEvent() != null) {
			this.getSelectedAnnotationEvent().selectAnnotationCollection(
					col <= 1 ? true : false);
			setSelectedAnnotation();
			arrTool.setTitle();
		}
	}

	public Annotator getSelectedAnnotator() {
		if (this.getSelectedAnnotationEvent() != null) {
			return this.getSelectedAnnotationEvent().getSelectedAnnotator();
		}
		return null;
	}

	public String getDirectory() {
		return directory;
	}

	public void setDirectory(String directory) {
		this.directory = directory;
	}

	public Annotator getPrimaryAnnotator() {
		return primaryAnnotator;
	}

	public void setPrimaryAnnotator(Annotator primaryAnnotator) {
		this.primaryAnnotator = primaryAnnotator;
	}

	public Annotator getSecondaryAnnotator() {
		return secondaryAnnotator;
	}

	public Annotator getAnnotator(String name) {
		return this.annotatorHash.get(name);
	}

	public void setSecondaryAnnotator(Annotator secondaryAnnotator) {
		this.secondaryAnnotator = secondaryAnnotator;
	}

	public EvaluationWorkbench getArrTool() {
		return arrTool;
	}

	public void setArrTool(EvaluationWorkbench arrTool) {
		this.arrTool = arrTool;
	}

	public Vector<Classification> getClassifications() {
		return getClassifications(false);
	}

	public Vector<Classification> getClassifications(boolean reset) {
		if (reset) {
			this.classifications = null;
		}
		if (this.doRefreshClassifications() || this.classifications == null
				&& this.selectedLevel != null) {
			Vector classifications = this.allAnnotationTypeClassificationMap
					.get(this.selectedLevel);
			if (classifications != null) {
				Collections.sort(classifications,
						new Classification.ClassificationSorter());
				this.classifications = classifications;
			}
		}
		return this.classifications;
	}

	public boolean doRefreshClassifications() {
		return this.refreshClassifications;
	}

	public void setDoRefreshClassifications() {
		this.refreshClassifications = true;
	}

	public int getClassificationRow() {
		if (this.selectedClassification != null
				&& this.getClassifications() != null) {
			return this.getClassifications().indexOf(selectedClassification);
		}
		return -1;
	}

	public Classification getClassificationByRow(int row) {
		if (this.getClassifications() != null
				&& this.getClassifications().size() > row) {
			// 3/5/2012 -- Summary row offset
			return this.getClassifications().elementAt(row + 1);
		}
		return null;
	}

	public int findClassificationRow(Classification classification) {
		if (this.getClassifications() != null) {
			for (int i = 0; i < this.getClassifications().size(); i++) {
				if (this.getClassifications().elementAt(i)
						.equals(classification)) {
					return i + 1;
					// Before 3/1/2012
//					return i;
				}
			}
		}
		return -1;
	}

	public void setSelectedAnnotationEvent(String filename) {
		this.selectedDocument = this.documentHash.get(filename);
		if (this.selectedDocument != null) {
			AnnotationEvent ae = this.annotationEventMap
					.get(this.selectedDocument);
			this.setSelectedAnnotationEvent(ae);
		}
	}

	public AnnotationEvent getSelectedAnnotationEvent() {
		return selectedAnnotationEvent;
	}

	public void setSelectedAnnotationEvent(
			AnnotationEvent selectedAnnotationEvent) {
		this.selectedAnnotationEvent = selectedAnnotationEvent;
	}

	public EVAnnotation getSelectedAnnotation() {
		return this.selectedAnnotation;
	}

	public EVAnnotation setSelectedAnnotation(EVAnnotation annotation) {
		this.selectedAnnotation = annotation;
		if (annotation != null) {
			if (!annotation.getClass().equals(this.selectedLevel)) {
				setSelectedLevel(annotation.getClass());
			}
			this.setSelectedClassification(annotation.getClassification());
		}
		setPrimarySecondarySelectedAnnotations();
		return this.selectedAnnotation;
	}

	public void nullifySelectedAnnotation() {
		this.selectedAnnotation = null;
	}

	public EVAnnotation setSelectedAnnotation() {
		if (this.selectedClassification != null
				&& this.selectedAnnotationEvent != null) {
			EVAnnotation annotation = this.selectedAnnotationEvent.selectedAnnotationCollection
					.getFirstAnnotation(this.selectedLevel,
							this.selectedClassification);
			setSelectedAnnotation(annotation);
		}
		return this.selectedAnnotation;
	}

	void setPrimarySecondarySelectedAnnotations() {
		if (this.selectedAnnotation != null) {
			AnnotationCollection primaryAC = this.selectedAnnotationEvent.primaryAnnotationCollection;
			AnnotationCollection secondaryAC = this.selectedAnnotationEvent.secondaryAnnotationCollection;
			boolean isPrimary = this.selectedAnnotationEvent.selectedAnnotationCollection
					.isPrimary();
			Vector<Vector<EVAnnotation>> matching = AnnotationCollection
					.getMatchingAnnotations(this.selectedLevel,
							this.selectedAnnotation.getClassification(),
							primaryAC, secondaryAC);
			if (matching != null) {
				for (Vector<EVAnnotation> pair : matching) {
					EVAnnotation primary = pair.elementAt(0);
					EVAnnotation secondary = pair.elementAt(1);
					if (this.selectedAnnotation.equals(primary)
							|| this.selectedAnnotation.equals(secondary)) {
						this.primarySelectedAnnotation = primary;
						this.secondarySelectedAnnotation = secondary;
						break;
					}
				}
			} else if (isPrimary) {
				this.primarySelectedAnnotation = this.selectedAnnotation;
				this.secondarySelectedAnnotation = null;
			} else {
				this.primarySelectedAnnotation = null;
				this.secondarySelectedAnnotation = this.selectedAnnotation;
			}
		}
	}

	public Vector<EVAnnotation> getAnnotationsByClass(Class c) {
		if (this.selectedAnnotationEvent != null) {
			return this.selectedAnnotationEvent.selectedAnnotationCollection
					.getAnnotationsByClass(c);
		}
		return null;
	}

	public Classification getSelectedClassification() {
		return selectedClassification;
	}

	public void setSelectedClassification(Classification selectedClassification) {
		this.selectedClassification = selectedClassification;
	}

	public Hashtable<Document, AnnotationEvent> getAnnotationEventMap() {
		return annotationEventMap;
	}

	public Hashtable<String, Document> getDocumentHash() {
		return documentHash;
	}

	public Hashtable<String, Annotator> getAnnotatorHash() {
		return annotatorHash;
	}

	// ///////////

	public void clearAnnotationMaps() {
		this.allClassificationAnnotationMap.clear();
		this.allClassAttributeMap.clear();
		this.allClassAttributeValueMap.clear();
		this.allClassRelationMap.clear();
	}

	public Hashtable<Classification, Vector<EVAnnotation>> getAllClassificationAnnotationMap() {
		return allClassificationAnnotationMap;
	}

	public void addClassAttribute(Class c, String attribute, Object value) {
		VUtils.pushIfNotHashVector(this.allClassAttributeMap, c, attribute);
		VUtils.pushIfNotHashVector(this.allClassAttributeValueMap, attribute,
				value);
	}

	public void addClassRelation(Class c, String relation) {
		VUtils.pushIfNotHashVector(this.allClassRelationMap, c, relation);
	}

	public Vector<String> getClassAttributes(Class c) {
		return this.allClassAttributeMap.get(c);
	}

	public Vector<String> getClassAttributeValues(String attribute) {
		if (attribute != null) {
			return this.allClassAttributeValueMap.get(attribute);
		}
		return null;
	}

	public Vector<String> getClassRelations(Class c) {
		return this.allClassRelationMap.get(c);
	}

	public Vector<String> getClassRelations() {
		return this.allClassRelationMap.get(this.getSelectedLevel());
	}

	// 1/26/2012
	public Vector<Class> getAllLevels() {
		return new Vector(this.allClassAttributeMap.keySet());
	}

	public Document getSelectedDocument() {
		return selectedDocument;
	}

	public void setSelectedDocument(Document selectedDocument) {
		this.selectedDocument = selectedDocument;
	}

	public Class getSelectedLevel() {
		return selectedLevel;
	}

	public boolean isDocumentLevel() {
		return selectedLevel == DocumentAnnotation.class;
	}

	public boolean isSnippetLevel() {
		return selectedLevel == SnippetAnnotation.class;
	}

	public void setSelectedLevel(Class selectedLevel) {
		setSelectedLevel(selectedLevel, true);
	}

	public void setSelectedLevel(Class selectedLevel, boolean reinitialize) {
		getClassifications(true);
		if (this.selectedLevel != selectedLevel && reinitialize) {
			this.selectedLevel = selectedLevel;
			GeneralStatistics.create(arrTool);
			arrTool.accuracyPane.populate();
			this.arrTool.graphPane.setSelectedLevel(selectedLevel);
			this.arrTool.fireAllTableDataChanged();
		}
		this.selectedLevel = selectedLevel;
	}

	public Vector<Class> getAnnotationLevels() {
		if (this.getSelectedAnnotationEvent() != null) {
			return this.getSelectedAnnotationEvent()
					.getSelectedAnnotationCollection().getAnnotationClasses();
		}
		return null;
	}

	public Hashtable<String, Vector<EVAnnotation>> getAllAnnotationTypeClassificationMap() {
		return allAnnotationTypeClassificationMap;
	}

	public EVAnnotation getPrimarySelectedAnnotation() {
		return primarySelectedAnnotation;
	}

	public EVAnnotation getSecondarySelectedAnnotation() {
		return secondarySelectedAnnotation;
	}

}
