package workbench.arr;

import java.util.Hashtable;
import java.util.Vector;

import onyx.document.document.Document;
import annotation.AnnotationCollection;
import annotation.EVAnnotation;

public class AnnotationEvent {
	AnnotationAnalysis analysis = null;
	Document document = null;
	AnnotationCollection primaryAnnotationCollection = null;
	AnnotationCollection secondaryAnnotationCollection = null;
	AnnotationCollection selectedAnnotationCollection = null;
	Vector<String> attributes = null;
	Vector<String> relations = null;
	Hashtable<String, EVAnnotation> idAnnotationMap = new Hashtable();

	public AnnotationEvent(AnnotationAnalysis analysis, Document document) {
		this.analysis = analysis;
		Vector<AnnotationCollection> collections = this.analysis.documentAnnotationCollectionMap
				.get(document);
		for (AnnotationCollection collection : collections) {
			if (collection.getAnnotator().isPrimary()) {
				this.primaryAnnotationCollection = collection;
				this.primaryAnnotationCollection.setPrimary(true);
			} else {
				this.secondaryAnnotationCollection = collection;
				this.secondaryAnnotationCollection.setPrimary(false);
			}
		}
		selectAnnotationCollection(true);
		resolveReferences();
	}

	public void storeAnnotationByID(EVAnnotation annotation) {
		String key = annotation.getId() + ":"
				+ annotation.getAnnotationCollection().isPrimary();
		this.idAnnotationMap.put(key, annotation);
	}

	public EVAnnotation getAnnotationByID(String id, boolean isPrimary) {
		String key = id + ":" + isPrimary;
		return this.idAnnotationMap.get(key);
	}

	public void resolveReferences() {
		if (this.primaryAnnotationCollection != null
				&& this.primaryAnnotationCollection.getAnnotations() != null
				&& this.secondaryAnnotationCollection != null
				&& this.secondaryAnnotationCollection.getAnnotations() != null) {
			for (EVAnnotation primary : this.primaryAnnotationCollection
					.getAnnotations()) {
				if (primary.getMatchedAnnotationID() != null
						&& primary.getMatchedAnnotation() == null) {
					primary.setMatchedAnnotation(this.getAnnotationByID(
							primary.getMatchedAnnotationID(), false));
				}
			}
			for (EVAnnotation secondary : this.secondaryAnnotationCollection
					.getAnnotations()) {
				if (secondary.getMatchedAnnotationID() != null
						&& secondary.getMatchedAnnotation() == null) {
					secondary.setMatchedAnnotation(this.getAnnotationByID(
							secondary.getMatchedAnnotationID(), true));
				}
			}
		}
	}

	public AnnotationAnalysis getAnalysis() {
		return analysis;
	}

	public void setAnalysis(AnnotationAnalysis analysis) {
		this.analysis = analysis;
	}

	public Document getDocument() {
		return document;
	}

	public void setDocument(Document document) {
		this.document = document;
	}

	public AnnotationCollection getPrimaryAnnotationCollection() {
		return primaryAnnotationCollection;
	}

	public AnnotationCollection getSecondaryAnnotationCollection() {
		return secondaryAnnotationCollection;
	}

	public AnnotationCollection getSelectedAnnotationCollection() {
		return selectedAnnotationCollection;
	}

	public void selectAnnotationCollection(int col) {
		selectAnnotationCollection(col <= 1);
	}

	public void selectAnnotationCollection(boolean isPrimary) {
		if (isPrimary) {
			this.selectedAnnotationCollection = this
					.getPrimaryAnnotationCollection();
		} else {
			this.selectedAnnotationCollection = this
					.getSecondaryAnnotationCollection();
		}
	}

	public Annotator getSelectedAnnotator() {
		if (this.selectedAnnotationCollection != null) {
			return this.selectedAnnotationCollection.getAnnotator();
		}
		return null;
	}

}
