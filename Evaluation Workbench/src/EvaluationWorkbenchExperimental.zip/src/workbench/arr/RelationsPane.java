package workbench.arr;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.util.Vector;
import javax.swing.CellEditor;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ScrollPaneConstants;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.TableCellEditor;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumn;
import annotation.EVAnnotation;
import annotation.RelationObject;

public class RelationsPane extends JPanel implements MouseMotionListener,
		MouseListener, ActionListener {
	EvaluationWorkbench arrTool = null;

	relationTableModel model = null;

	relationTable relationTable = null;

	JScrollPane scrollPane = null;

	JLabel label = null;

	static Font smallFont = new Font("Serif", Font.PLAIN, 12);

	static Color tempColor = new Color(0xffffff);

	static boolean processingMouseEvent = false;

	static boolean processingMouseMoved = false;

	static int lastMouseRow = -1;

	static int lastMouseColumn = -1;

	public RelationsPane(EvaluationWorkbench tool) {
		super(new BorderLayout());
		arrTool = tool;
		model = new relationTableModel();
		relationTable = new relationTable();
		initializeColumns();
		relationTable
				.setPreferredScrollableViewportSize(new Dimension(300, 200));
		relationTable.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
		relationTable.addMouseMotionListener(this);
		relationTable.addMouseListener(this);
		scrollPane = new JScrollPane(relationTable,
				ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED,
				ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		this.label = new JLabel("RELATIONS", null, JLabel.CENTER);
		add(this.label, BorderLayout.PAGE_START);
		add(scrollPane, BorderLayout.PAGE_END);
		this.setOpaque(true);
	}

	public void actionPerformed(ActionEvent e) {
		String command = e.getActionCommand();
	}

	void resetLabel() {
		EVAnnotation annotation = arrTool.getAnalysis().getSelectedAnnotation();
		String annotator = arrTool.getAnalysis().getSelectedAnnotator()
				.getName().toUpperCase();
		if (annotation != null) {
			String str = annotation.getClassification().getValue();
			if (str.length() > 20) {
				str = str.substring(0, 20) + "...";
			}
			str = "RELATIONS (" + annotator + ") \"" + str + "\"";
			label.setText(str);
		}
	}

	void initializeColumns() {
		// model.fireTableStructureChanged();
		for (int i = 0; i < relationTable.getColumnCount(); i++) {
			TableColumn column = relationTable.getColumnModel().getColumn(i);
			int width = (i == 0 ? 100 : 200);
			column.setPreferredWidth(width);
		}
		model.fireTableDataChanged();
	}

	public class relationTable extends JTable implements ListSelectionListener {

		String selectedState = null;

		int selectedRow = -1;

		int selectedColumn = -1;

		relationTable() {
			super(model);
			relationTable = this;
			this.setShowGrid(true);
			this.setGridColor(Color.GRAY);
			this.setRowHeight(15);
			this.setFont(smallFont);
			setToolTipText("");
		}

		public void processMouseEvent(MouseEvent e) {
			processingMouseEvent = true;
			super.processMouseEvent(e);
			processingMouseEvent = false;
		}

		public int getRowHeight(int row) {
			return 15;
		}

		public Component prepareRenderer(TableCellRenderer renderer,
				int rowIndex, int colIndex) {
			Component c = super.prepareRenderer(renderer, rowIndex, colIndex);
			Color color = getColor(rowIndex, colIndex);
			c.setBackground(color);
			return c;
		}

		public TableCellEditor getCellEditor() {
			return super.getCellEditor();
		}

		Color getColor(int row, int col) {
			boolean selectedCell = (row == relationTable.selectedRow && col == relationTable.selectedColumn);
			if (col > 0 && selectedCell) {
				return Colors.darkBlueGray;
			}
			if (arrTool.getAnalysis().getSelectedClassification() != null
					&& arrTool
							.getAnalysis()
							.getSelectedClassification()
							.equals(arrTool.getAnalysis()
									.getClassificationByRow(row))) {
				return Colors.lightBlueGray;
			}

			if (row == relationTable.selectedRow) {
				return Colors.darkBlueGray;
			}
			if (col > 0 && col == relationTable.selectedColumn) {
				return Colors.lightBlueGray;
			}
			return Color.white;
		}

		void doSelection(int row, int col) {
			selectedRow = row;
			selectedColumn = col;
			arrTool.getAnalysis().selectAnnotationCollection(col);
			arrTool.getAnalysis().setSelectedAnnotation(model.getRelatum(row));
			// arrTool.accuracyPane.accuracyTable.doExternalSelection();
			arrTool.accuracyPane.doExternalSelection();
		}

	};

	public class relationTableModel extends AbstractTableModel {

		relationTableModel() {
			this.fireTableRowsInserted(0, getRowCount());
		}

		public int getColumnCount() {
			return 2;
		}

		public int getRowCount() {
			resetLabel();
			if (arrTool.getAnalysis() != null
					&& arrTool.getAnalysis().getSelectedAnnotation() != null
					&& arrTool.getAnalysis().getSelectedAnnotation()
							.getRelationObjects() != null) {
				return arrTool.getAnalysis().getSelectedAnnotation()
						.getRelationObjects().size();
			}
			return 0;
		}

		public String getColumnName(int col) {
			switch (col) {
			case 0:
				return "Relation";
			case 1:
				return "Relatum";
			}
			return ".";
		}

		public Object getValueAt(int row, int col) {
			if (arrTool.getAnalysis().getSelectedClassification() == null
					|| arrTool.getAnalysis().getSelectedAnnotationEvent() == null) {
				return null;
			}
			if (col == 0) {
				return getRelation(row);
			}
			return getRelatum(row);
		}

		public String getRelation() {
			return (relationTable.selectedRow >= 0 ? getRelation(relationTable.selectedRow)
					: null);
		}

		public String getRelation(int row) {
			if (arrTool.getAnalysis().getSelectedAnnotation() != null) {
				Vector<RelationObject> v = arrTool.getAnalysis()
						.getSelectedAnnotation().getRelationObjects();
				if (v != null && row >= 0 && row < v.size()) {
					RelationObject ro = v.elementAt(row);
					return ro.getRelation();
				}
			}
			return null;
		}

		public EVAnnotation getRelatum(int row) {
			if (arrTool.getAnalysis().getSelectedAnnotation() != null) {
				Vector<RelationObject> v = arrTool.getAnalysis()
						.getSelectedAnnotation().getRelationObjects();
				if (v != null && row >= 0 && row < v.size()) {
					RelationObject ro = v.elementAt(row);
					return ro.getRelatum();
				}
			}
			return null;
		}

		public Class getColumnClass(int col) {
			return String.class;
		}

		public boolean isCellEditable(int row, int col) {
			return false;
		}

		private void setColumnWidth(int col, int width) {
			TableColumn column = relationTable.getColumnModel().getColumn(col);
			column.setMaxWidth(width);
			column.setMinWidth(width);
			column.setWidth(width);
			column.setPreferredWidth(width);
			relationTable.sizeColumnsToFit(-1);
		}

		private int getPreferredColumnWidth(int col) {
			return (col == 0 ? 160 : 250);
		}

		public void setPreferredColumnWidth(int col) {
			int width = getPreferredColumnWidth(col);
			setColumnWidth(col, width);
		}

		DefaultComboBoxModel getSelectedComboBoxModel() {
			return null;
		}
	}

	public void mouseMoved(MouseEvent e) {
		if (e.isControlDown()) {
			processingMouseMoved = true;
			Point p = new Point(e.getX(), e.getY());
			int col = relationTable.columnAtPoint(p);
			int row = relationTable.rowAtPoint(p);
			if (col != lastMouseColumn || row != lastMouseRow) {
				lastMouseRow = row;
				lastMouseColumn = col;
				CellEditor ce = relationTable.getCellEditor();
				if (ce != null) {
					ce.stopCellEditing();
				}
				relationTable.selectedRow = row;
				relationTable.selectedColumn = col;
				EVAnnotation relatum = model.getRelatum(row);
				if (relatum != null) {
					arrTool.getDocumentPane().highlightSentences(true);
					arrTool.getDocumentPane().highlightAnnotation(relatum,
							Colors.darkPurple);
					arrTool.getDocumentPane().setCaretPosition(relatum);
				}
				model.fireTableDataChanged();
			}
			processingMouseMoved = false;
		}
	}

	public void mouseDragged(MouseEvent e) {
	}

	/** ******* Mouse operations ****** */
	public void mousePressed(MouseEvent e) {

	}

	public void mouseReleased(MouseEvent e) {

	}

	public void mouseEntered(MouseEvent e) {

	}

	public void mouseExited(MouseEvent e) {

	}

	public void mouseClicked(MouseEvent e) {
		if (relationTable.selectedRow >= 0 && relationTable.selectedColumn >= 0) {
			relationTable.doSelection(relationTable.selectedRow,
					relationTable.selectedColumn);
		}
	}

}
