package workbench.arr;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.util.Vector;

import javax.swing.CellEditor;
import javax.swing.DefaultCellEditor;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ScrollPaneConstants;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.TableCellEditor;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumn;

import annotation.Classification;
import annotation.EVAnnotation;

public class AttributesPane extends JPanel implements MouseMotionListener,
		MouseListener, ActionListener {
	JLabel label = null;
	EvaluationWorkbench arrTool = null;

	attributeTableModel model = null;

	attributeTable attributeTable = null;

	JScrollPane scrollPane = null;

	Vector comboBoxes = null;

	ConceptJComboBox selectedComboBox = null;

	static Font smallFont = new Font("Serif", Font.PLAIN, 12);

	static Color tempColor = new Color(0xffffff);

	static boolean processingMouseEvent = false;

	static boolean processingMouseMoved = false;

	static int lastMouseRow = -1;

	static int lastMouseColumn = -1;

	public AttributesPane(EvaluationWorkbench tool) {
		super(new BorderLayout());
		arrTool = tool;
		model = new attributeTableModel();
		attributeTable = new attributeTable();
		initializeColumns();
		attributeTable.setPreferredScrollableViewportSize(new Dimension(300,
				200));
		attributeTable.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
		attributeTable.addMouseMotionListener(this);
		attributeTable.addMouseListener(this);
		scrollPane = new JScrollPane(attributeTable,
				ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED,
				ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		this.label = new JLabel("ATTRIBUTES", null, JLabel.CENTER);
		add(this.label, BorderLayout.PAGE_START);
		add(scrollPane, BorderLayout.PAGE_END);
		this.setOpaque(true);
	}
	
	void resetLabel() {
		EVAnnotation annotation = arrTool.getAnalysis().getSelectedAnnotation();
		String annotator = arrTool.getAnalysis().getSelectedAnnotator().getName().toUpperCase();
		if (annotation != null) {
			String str = annotation.getClassification().getValue();
			if (str != null) {
				if (str.length() > 20) {
					str = str.substring(0, 20) + "...";
				}
				str = "ATTRIBUTES (" + annotator + ") \"" + str + "\"";
				label.setText(str);
			}
		}
	}

	public void actionPerformed(ActionEvent e) {
		String command = e.getActionCommand();
	}

	void initializeColumns() {
		model.fireTableStructureChanged();
		for (int i = 0; i < attributeTable.getColumnCount(); i++) {
			TableColumn column = attributeTable.getColumnModel().getColumn(i);
			ConceptJComboBox cb = new ConceptJComboBox();
			cb.setEditable(true);
			DefaultCellEditor dce = new MyTableCellEditor(cb);
			column.setCellEditor(dce);
			int width = (i == 0 ? 100 : 80);
			column.setPreferredWidth(width);
		}
		model.fireTableDataChanged();
	}

	public class attributeTable extends JTable implements ListSelectionListener {

		ConceptJComboBox selectedComboBox = null;

		String selectedState = null;

		int selectedRow = -1;

		int selectedColumn = -1;

		attributeTable() {
			super(model);
			attributeTable = this;
			this.setShowGrid(true);
			this.setGridColor(Color.GRAY);
			this.setRowHeight(15);
			this.setFont(smallFont);
			setToolTipText("");
		}

		public void processMouseEvent(MouseEvent e) {
			processingMouseEvent = true;
			super.processMouseEvent(e);
			processingMouseEvent = false;
		}

		public int getRowHeight(int row) {
			return 15;
		}

		public Component prepareRenderer(TableCellRenderer renderer,
				int rowIndex, int colIndex) {
			Component c = super.prepareRenderer(renderer, rowIndex, colIndex);
			Color color = getColor(rowIndex, colIndex);
			c.setBackground(color);
			return c;
		}

		public TableCellEditor getCellEditor() {
			return super.getCellEditor();
		}

		Color getColor(int row, int col) {
			boolean selectedCell = (row == attributeTable.selectedRow && col == attributeTable.selectedColumn);
			if (col > 0 && selectedCell) {
				return Colors.darkBlueGray;
			}
			if (row == attributeTable.selectedRow) {
				return Colors.lightBlueGray;
			}
			if (col > 0 && col == attributeTable.selectedColumn) {
				return Color.LIGHT_GRAY;
			}
			return Color.white;
		}

		void doSelection(int row, int col) {
			selectedRow = row;
			selectedColumn = col;
			arrTool.getAnalysis().selectAnnotationCollection(col);
			arrTool.fireAllTableDataChanged();
		}

	};

	public class attributeTableModel extends AbstractTableModel {

		attributeTableModel() {
			this.fireTableRowsInserted(0, getRowCount());
		}

		public int getColumnCount() {
			return 3;
		}
		
		public int getRowCount() {
			resetLabel();
			EVAnnotation annotation = arrTool.getAnalysis().getSelectedAnnotation();
			if (annotation != null) {
				return annotation.getNumberOfAttributes();
			}
			return 0;
		}

// Before 1/30/2012
//		public int getRowCount() {
//			resetLabel();
//			Vector<String> attributes = null;
//			if (arrTool.getAnalysis() != null) {
//				attributes = arrTool.getAnalysis().getClassAttributes(
//						arrTool.getAnalysis().getSelectedLevel());
//			}
//			return (attributes != null ? attributes.size() : 0);
//		}

		public String getColumnName(int col) {
			switch (col) {
			case 0:
				return "Attribute";
			case 1:
				return arrTool.getAnalysis().getPrimaryAnnotator().getName();
			case 2:
				return arrTool.getAnalysis().getSecondaryAnnotator().getName();
			}
			return ".";
		}
		
		public Object getValueAt(int row, int col) {
			Classification c = arrTool.getAnalysis()
					.getSelectedClassification();
			if (c == null
					|| arrTool.getAnalysis().getSelectedAnnotationEvent() == null) {
				return null;
			}
			String attribute = getAttribute(row);
			if (col == 0) {
				return attribute;
			}
			if (col == 1
					&& arrTool.getAnalysis().getPrimarySelectedAnnotation() != null) {
				return arrTool.getAnalysis().getPrimarySelectedAnnotation()
						.getAttribute(attribute);
			}
			if (col == 2
					&& arrTool.getAnalysis().getSecondarySelectedAnnotation() != null) {
				return arrTool.getAnalysis().getSecondarySelectedAnnotation()
						.getAttribute(attribute);
			}
			return "*";
		}

		// Before 1/30/2012
//		public Object getValueAt(int row, int col) {
//			Classification c = arrTool.getAnalysis()
//					.getSelectedClassification();
//			if (c == null
//					|| arrTool.getAnalysis().getSelectedAnnotationEvent() == null) {
//				return null;
//			}
//			String attribute = getAttribute(row);
//			if (col == 0) {
//				return attribute;
//			}
//			if (col == 1
//					&& arrTool.getAnalysis().getPrimarySelectedAnnotation() != null) {
//				return arrTool.getAnalysis().getPrimarySelectedAnnotation()
//						.getAttribute(attribute);
//			}
//			if (col == 2
//					&& arrTool.getAnalysis().getSecondarySelectedAnnotation() != null) {
//				return arrTool.getAnalysis().getSecondarySelectedAnnotation()
//						.getAttribute(attribute);
//			}
//			return "*";
//		}

		public String getAttribute() {
			return (attributeTable.selectedRow >= 0 ? getAttribute(attributeTable.selectedRow)
					: null);
		}
		
		public String getAttribute(int row) {
			EVAnnotation annotation = arrTool.getAnalysis().getSelectedAnnotation();
			if (annotation == null || row < 0) {
				return null;
			}
			Vector<String> attributes = annotation.getAttributes();
			if (row < attributes.size()) {
				String attribute = attributes.elementAt(row);
				return attribute;
			}
			return null;
		}

		// Before 1/30/2012
//		public String getAttribute(int row) {
//			if (row >= 0) {
//				Vector<String> attributes = arrTool.getAnalysis()
//						.getClassAttributes(
//								arrTool.getAnalysis().getSelectedLevel());
//				if (row < attributes.size()) {
//					String attribute = attributes.elementAt(row);
//					return attribute;
//				}
//			}
//			return null;
//		}

		public Class getColumnClass(int col) {
			return String.class;
		}

		public boolean isCellEditable(int row, int col) {
			boolean editable = (col > 0);
			if (processingMouseEvent) {
				attributeTable.doSelection(row, col);
			}
			return editable;
		}

		private void setColumnWidth(int col, int width) {
			TableColumn column = attributeTable.getColumnModel().getColumn(col);
			column.setMaxWidth(width);
			column.setMinWidth(width);
			column.setWidth(width);
			column.setPreferredWidth(width);
			attributeTable.sizeColumnsToFit(-1);
		}

		private int getPreferredColumnWidth(int col) {
			return (col == 0 ? 250 : 160);
		}

		public void setPreferredColumnWidth(int col) {
			int width = getPreferredColumnWidth(col);
			setColumnWidth(col, width);
		}

		DefaultComboBoxModel getSelectedComboBoxModel() {
			return null;
		}
	}

	class ConceptJComboBox extends JComboBox {

		public ConceptJComboBox() {
			setPreferredSize(new Dimension(150, 20));
			setEditable(true);
			this.setFont(smallFont);
			if (attributeTable.selectedRow >= 0) {
				String attribute = model
						.getAttribute(attributeTable.selectedRow);
				Vector values = arrTool.getAnalysis().getClassAttributeValues(
						attribute);
				if (values != null) {
					for (Object value : values) {
						addItem(value);
					}
				}
				Object selection = (String) attributeTable.getValueAt(
						attributeTable.selectedRow,
						attributeTable.selectedColumn);
				if (selection != null) {
					setSelectedItem(selection);
				}
			}
			this.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					comboBoxActionPerformed(e);
				}
			});
		}

		public String toString() {
			Object o = getSelectedItem();
			return o.toString();
		}

		protected void comboBoxActionPerformed(ActionEvent e) {
			if ("comboBoxChanged".equals(e.getActionCommand())) {
				if (attributeTable.selectedRow >= 0) {
					ConceptJComboBox cb = (ConceptJComboBox) e.getSource();
					Object o = cb.getSelectedItem();
					EVAnnotation annotation = arrTool.getAnalysis()
							.getSelectedAnnotation();
					if (o != null && annotation != null) {
						String attribute = model.getAttribute();
						annotation.setAttribute(attribute, o);
						model.fireTableDataChanged();
					}
				}
			}
		}

	}

	public class MyTableCellEditor extends DefaultCellEditor {
		public static final long serialVersionUID = 0;

		ConceptJComboBox cb = null;

		public MyTableCellEditor(ConceptJComboBox cb) {
			super(cb);
			this.cb = cb;
		}

		public Component getTableCellEditorComponent(JTable table,
				Object value, boolean isSelected, int row, int col) {
			if (col > 0) {
				attributeTable.doSelection(row, col);
				this.cb = new ConceptJComboBox();
				EVAnnotation annotation = arrTool.getAnalysis()
						.getSelectedAnnotation();
				if (annotation != null) {
					String attribute = model.getAttribute();
					Object av = annotation.getAttribute(attribute);
					if (av != null) {
						this.cb.setSelectedItem(av);
					}
				}
				return this.cb;
			}
			return null;
		}
	}

	public void mouseMoved(MouseEvent e) {
		if (e.isControlDown()) {
			processingMouseMoved = true;
			Point p = new Point(e.getX(), e.getY());
			int col = attributeTable.columnAtPoint(p);
			int row = attributeTable.rowAtPoint(p);
			if (col != lastMouseColumn || row != lastMouseRow) {
				lastMouseRow = row;
				lastMouseColumn = col;
				CellEditor ce = attributeTable.getCellEditor();
				if (ce != null) {
					ce.stopCellEditing();
				}
				attributeTable.doSelection(row, col);
			}
			processingMouseMoved = false;
		}
	}

	public void mouseDragged(MouseEvent e) {
	}

	/** ******* Mouse operations ****** */
	public void mousePressed(MouseEvent e) {

	}

	public void mouseReleased(MouseEvent e) {

	}

	public void mouseEntered(MouseEvent e) {

	}

	public void mouseExited(MouseEvent e) {

	}

	public void mouseClicked(MouseEvent e) {

	}

}
