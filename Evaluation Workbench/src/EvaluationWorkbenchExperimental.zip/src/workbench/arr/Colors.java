package workbench.arr;

import java.awt.Color;

public class Colors {
	
	public static Color darkTan = new Color(0x8C8A71);
	public static Color lightTan = new Color(0xCCCAB0);
	public static Color darkTaupe = new Color(0xACBA9D);
	public static Color lightTaupe = new Color(0xD3DBCA);
	public static Color darkBlueGray = new Color(0xA6ADCC);
	public static Color veryDarkBlueGray = new Color(0x616781);
	public static Color lightBlueGray = new Color(0xD3D7E6);
	public static Color lightPurple = new Color(0xE9C5E9);
	public static Color darkPurple = new Color(0xC973C9);
	public static Color veryLightGray = new Color(0xEBEBEB);
	public static Color lightPink = new Color(0xBF6D8C);
	
	public static Color verifiedSelectedSnippetAnnotationTrue = new Color(0x7DBF15);
	public static Color verifiedSelectedSnippetAnnotationFalse = new Color(0x9BBF97);
	public static Color verifiedUnselectedSnippetAnnotationTrue = new Color(0xBDBF19);
	public static Color verifiedUnselectedSnippetAnnotationFalse = new Color(0xBFBD7E);
	public static Color verifiedSelectedDocumentAnnotationTrue = new Color(0x548CBF);
	public static Color verifiedSelectedDocumentAnnotationFalse = new Color(0x7C8EBF);
	public static Color verifiedUnselectedDocumentAnnotationTrue = new Color(0x2896BF);
	public static Color verifiedUnselectedDocumentAnnotationFalse = new Color(0x97BFB7);
	
	public static Color getUnselectedClassificationPaneColor(Class level) {
		String levelName = level.getSimpleName().toLowerCase();
		if ("documentannotation".equals(levelName)) {
			return Color.white;
		}
		if ("snippetannotation".equals(levelName)) {
			return lightTan;
		}
		return Color.white;
	}

}
