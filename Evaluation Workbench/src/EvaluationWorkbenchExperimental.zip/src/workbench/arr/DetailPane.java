package workbench.arr;

import java.awt.FlowLayout;
import javax.swing.JPanel;

public class DetailPane extends JPanel {
	
	EvaluationWorkbench arrTool = null;
	AttributesPane attributesPane = null;
	RelationsPane relationsPane = null;
//	AnnotationListPane displayCheckboxPane = null;
	ReportListPane reportListPane = null;
	
	public DetailPane(EvaluationWorkbench tool) {
		super(new FlowLayout());
		this.arrTool = tool;
		reportListPane = new ReportListPane(tool);
		add(reportListPane);
		attributesPane = new AttributesPane(tool);
		add(attributesPane);
		relationsPane = new RelationsPane(tool);
		add(relationsPane);
		this.setOpaque(true);
	}
	
	public void fireAllTableDataChanged() {
		attributesPane.initializeColumns();
		relationsPane.model.fireTableDataChanged();
	}

}
