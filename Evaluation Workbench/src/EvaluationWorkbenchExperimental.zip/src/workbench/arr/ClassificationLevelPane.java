package workbench.arr;

import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;

import typesystem.Annotation;
import typesystem.Attribute;
import typesystem.Classification;

public class ClassificationLevelPane extends JPanel {

	private EvaluationWorkbench arrTool = null;
	public ClassificationLevelComboBox comboBox = null;
	public Attribute selectedAttribute = null;

	public ClassificationLevelPane(EvaluationWorkbench arrTool) {
		super(new FlowLayout());
		this.arrTool = arrTool;
		add(new JLabel("Classification Name:"));
		comboBox = new ClassificationLevelComboBox(this);
		add(comboBox);
	}

	public void setSelectedLevel() {
		this.remove(comboBox);
		this.comboBox = new ClassificationLevelComboBox(this);
		this.add(comboBox);
		this.arrTool.clearGeneralStatisticsTable();
		this.arrTool.fireAllTableDataChanged();
	}

	class ClassificationLevelComboBox extends JComboBox {
		public static final long serialVersionUID = 0;
		private ClassificationLevelPane pane = null;

		public ClassificationLevelComboBox(ClassificationLevelPane pane) {
			this.pane = pane;
			setPreferredSize(new Dimension(150, 20));
			Class level = arrTool.getAnalysis().getSelectedLevel();
			Annotation annotation = arrTool.getTypeSystem().getUimaAnnotation(
					level.getSimpleName());
			if (annotation != null) {
				Classification c = annotation.getFirstClassification();
				if (c.getAttributes() != null) {
					for (int i = 0; i < c.getAttributes().size(); i++) {
						Attribute attribute = c.getAttributes().elementAt(i);
						addItem(attribute);
						if (attribute.isDisplay()) {
							selectedAttribute = attribute;
						}
					}
					this.setSelectedItem(selectedAttribute);
				}
				this.addActionListener( new MyActionListener());
			}
		}
		
		public class MyActionListener implements ActionListener {
			public MyActionListener() {
				
			}
			public void actionPerformed(ActionEvent e) {
				comboBoxActionPerformed(e);
			}
		}

		public String toString() {
			Attribute attribute = (Attribute) getSelectedItem();
			return attribute.getName();
		}
		
		public void updateDisplayableNameSelection() {
			int displayIndex = -1;
			for (int i = 0; i < this.getItemCount(); i++) {
				Attribute selectedAttribute = (Attribute) this.getItemAt(i);
				if (selectedAttribute.isDisplay()) {
					displayIndex = i;
					break;
				}
			}
			if (displayIndex > 0) {
				this.setSelectedIndex(displayIndex);
			}
		}

		protected void comboBoxActionPerformed(ActionEvent e) {
			if ("comboBoxChanged".equals(e.getActionCommand())) {
				ClassificationLevelComboBox cb = (ClassificationLevelComboBox) e
						.getSource();
				Attribute attribute = (Attribute) cb.getSelectedItem();
				Classification c = (Classification) attribute.getParent();
				String name = attribute.getName();
				c.setDisplayAttribute(name);
				Attribute displayAttribute = c.getDisplayAttribute();
				this.setSelectedItem(displayAttribute);
				pane.arrTool.fireAllTableDataChanged();
			}
		}

	}

}
