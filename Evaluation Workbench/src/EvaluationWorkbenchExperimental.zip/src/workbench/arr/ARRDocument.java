package workbench.arr;

import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.Vector;

import onyx.utilities.FUtils;
import onyx.utilities.HUtils;

public class ARRDocument {
	public AnnotationAnalysis analysis = null;
	public String filename = null;
	public String text = null;
	public static Map<String, ARRDocument> documentMap = new HashMap<String, ARRDocument>();
	
	public ARRDocument(AnnotationAnalysis analysis, String filename) {
		this.analysis = analysis;
		this.filename = filename;
		String fullname = analysis.directory + "/" + filename;
		this.text = FUtils.readFile(fullname);
		documentMap.put(this.filename, this);
	}
	
	public static ARRDocument create(AnnotationAnalysis analysis, String filename) {
		ARRDocument document = documentMap.get(filename);
		if (document == null) {
			document = new ARRDocument(analysis, filename);
		}
		return document;
	}
	
	public String toString() {
		return "[" + this.filename + "]";
	}
	
	public static ARRDocument getDocument(String filename) {
		return documentMap.get(filename);
	}
	
	public static Vector getDocuments() {
		Vector v = HUtils.getElements(documentMap);
		Collections.sort(v, new NameSorter());
		return v;
	}
	
	public static Vector getDocumentNames() {
		Vector v = HUtils.getKeys(documentMap);
		Collections.sort(v);
		return v;
	}
	
	public static class NameSorter implements Comparator {
		public int compare(Object o1, Object o2) {
			ARRDocument d1 = (ARRDocument) o1;
			ARRDocument d2 = (ARRDocument) o2;
			return d1.filename.compareTo(d2.filename);
		}
	}

}
