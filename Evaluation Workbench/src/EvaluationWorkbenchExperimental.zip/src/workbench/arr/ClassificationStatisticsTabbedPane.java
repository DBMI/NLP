package workbench.arr;

import javax.swing.JTabbedPane;

import annotation.Classification;

public class ClassificationStatisticsTabbedPane extends JTabbedPane {
	EvaluationWorkbench arrTool = null;
	ClassificationStatisticsPane firstPane = null;
	ClassificationStatisticsPane secondPane = null;
	ClassificationStatisticsPane selectedPane = null;
	
	
	public ClassificationStatisticsTabbedPane(EvaluationWorkbench arrTool) {
		this.arrTool = arrTool;
		selectedPane = firstPane = new ClassificationStatisticsPane(arrTool);
		secondPane = new ClassificationStatisticsPane(arrTool);
		addTab("All", firstPane);
		addTab("Binary", secondPane);
	}
	
	void setSelectedPane(int index) {
		selectedPane = (index == 0 ? firstPane : secondPane);
		populate();
	}
	
	public boolean isCompareConglomerate() {
		return selectedPane == secondPane;
	}
	
	void populate() {
		if (arrTool.analysis != null && arrTool.statistics != null) {
			arrTool.analysis.getClassifications();
			firstPane.resetLabel();
			firstPane.model.fireTableRowsInserted(0, firstPane.model.getRowCount());
			firstPane.model.fireTableDataChanged();
			secondPane.resetLabel();
			secondPane.model.fireTableRowsInserted(0, secondPane.model.getRowCount());
			secondPane.model.fireTableDataChanged();
		}
	}
	
	public void fireTableDataChanged() {
		firstPane.model.fireTableDataChanged();
		secondPane.model.fireTableDataChanged();
	}
	
//	public void fireTableDataChanged() {
//		if (arrTool.analysis != null && arrTool.statistics != null) {
//			firstPane.model.fireTableDataChanged();
//			secondPane.model.fireTableDataChanged();
//		}
//	}
	
	public void selectByClassification(Classification classification) {
		firstPane.selectByClassification(classification);
		secondPane.selectByClassification(classification);
	}
	
//	public void selectByClassification(Classification classification) {
//		firstPane.selectByClassification(classification);
//		secondPane.selectByClassification(classification);
//	}
	
	public void doExternalSelection(int row, int col) {
		firstPane.accuracyTable.doExternalSelection(row, col);
		secondPane.accuracyTable.doExternalSelection(row, col);
	}
	
	public void doExternalSelection() {
		firstPane.accuracyTable.doExternalSelection();
		secondPane.accuracyTable.doExternalSelection();
	}
	
	void doExternalSelection(ClassificationStatisticsPane pane, int row, int col) {
		pane.accuracyTable.doExternalSelection(row, col);
	}
	
	void createGeneralStatistics() {
		
	}
	
	public ClassificationStatisticsPane getFirstPane() {
		return firstPane;
	}

	public ClassificationStatisticsPane getSecondPane() {
		return secondPane;
	}

}
