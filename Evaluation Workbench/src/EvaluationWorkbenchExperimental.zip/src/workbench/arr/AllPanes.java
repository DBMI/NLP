package workbench.arr;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;

import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.ScrollPaneConstants;

public class AllPanes extends JPanel {
	
	public DocumentPane documentPane = null;

	public DetailPane detailPane = null;

	public ClassificationStatisticsPane accuracyPane = null;
	
	public AllPanes(EvaluationWorkbench arrTool) {
		initializeLayout(arrTool);
	}
	
	void initializeLayout(EvaluationWorkbench arrTool) {
		documentPane = new DocumentPane(arrTool);
		accuracyPane = new ClassificationStatisticsPane(arrTool);
		JScrollPane accuracyScrollPane = new JScrollPane(accuracyPane,
				ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED,
				ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		detailPane = new DetailPane(arrTool);
		JScrollPane detailScrollPane = new JScrollPane(detailPane,
				ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED,
				ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);

		GridBagConstraints c = new GridBagConstraints();
		this.setLayout(new GridBagLayout());

		c.fill = GridBagConstraints.BOTH;
		c.gridwidth = 1;
		c.gridheight = 2;
		c.gridx = 0;
		c.gridy = 0;
		c.weightx = 0.35;
		c.weighty = 0.5;
		this.add(documentPane, c);

		c.fill = GridBagConstraints.BOTH;
		c.gridwidth = 1;
		c.gridheight = 1;
		c.gridx = 1;
		c.gridy = 0;
		c.weightx = 0.65;
		c.weighty = 0.5;
		this.add(accuracyScrollPane, c);

		c.fill = GridBagConstraints.BOTH;
		c.gridwidth = 1;
		c.gridheight = 1;
		c.gridx = 1;
		c.gridy = 1;
		c.weightx = 0.5;
		c.weighty = 0.5;
		this.add(detailScrollPane, c);
	}


}
