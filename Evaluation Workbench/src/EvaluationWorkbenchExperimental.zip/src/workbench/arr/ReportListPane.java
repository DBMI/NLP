package workbench.arr;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.util.Vector;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ScrollPaneConstants;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.TableCellEditor;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumn;

import annotation.Classification;

public class ReportListPane extends JPanel implements MouseMotionListener,
		MouseListener, ActionListener {
	JLabel label = null;
	EvaluationWorkbench arrTool = null;

	ReportListJTableModel model = null;

	ReportListJTable reportListTable = null;

	static Font smallFont = new Font("Serif", Font.PLAIN, 12);

	static Color tempColor = new Color(0xffffff);

	static boolean processingMouseEvent = false;

	static boolean processingMouseMoved = false;

	static int lastMouseRow = -1;

	static int lastMouseColumn = -1;

	static Color selectedCellColor = Colors.darkBlueGray;

	static Color unselectedColor = Colors.lightBlueGray;

	public ReportListPane(EvaluationWorkbench tool) {
		super(new BorderLayout());
		arrTool = tool;
		model = new ReportListJTableModel(this);
		reportListTable = new ReportListJTable();
		reportListTable.setPreferredScrollableViewportSize(new Dimension(200,
				200));
		reportListTable.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
		reportListTable.addMouseMotionListener(this);
		reportListTable.addMouseListener(this);
		JScrollPane sp = new JScrollPane(reportListTable,
				ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED,
				ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		this.label = new JLabel("REPORTS", null, JLabel.CENTER);
		add(this.label, BorderLayout.PAGE_START);
		add(sp, BorderLayout.PAGE_END);
		this.setOpaque(true);
	}

	public void actionPerformed(ActionEvent e) {
		String command = e.getActionCommand();
	}

	public void resetLabel() {
		String annotator = arrTool.getAnalysis().getSelectedAnnotator()
				.getName().toUpperCase();
		String filename = (reportListTable != null
				&& reportListTable.selectedFilename != null ? reportListTable.selectedFilename
				: "*");
		if (label != null) {
			label.setText("REPORT (" + annotator + ")=" + filename);
		}
	}

	public class ReportListJTable extends JTable implements
			ListSelectionListener {
		Vector<String> reportList = null;
		String selectedFilename = null;
		int selectedRow = -1;
		int selectedColumn = -1;
		String currentOEMType = null;

		ReportListJTable() {
			super(model);
			reportListTable = this;
			this.setShowGrid(true);
			this.setGridColor(Color.GRAY);
			this.setRowHeight(15);
			this.setFont(smallFont);
			setToolTipText("");
		}

		public void setReportList(Classification classification, int col) {
			if (col > 0 && GeneralStatistics.statistics != null) {
				switch (col) {
				case 1:
					this.currentOEMType = GeneralStatistics.TruePositive;
					this.reportList = GeneralStatistics.statistics
							.getTruePositiveReports(classification);
					break;
				case 2:
					this.currentOEMType = GeneralStatistics.FalsePositive;
					this.reportList = GeneralStatistics.statistics
							.getFalsePositiveReports(classification);
					break;
				case 3:
					this.currentOEMType = GeneralStatistics.TrueNegative;
					this.reportList = GeneralStatistics.statistics
							.getTrueNegativeReports(classification);
					break;
				case 4:
					this.currentOEMType = GeneralStatistics.FalseNegative;
					this.reportList = GeneralStatistics.statistics
							.getFalseNegativeReports(classification);
					break;
				}
				model.fireTableStructureChanged();
				model.fireTableDataChanged();
			}
		}

		public void doSelection(int row, int col) {
			model.fireTableDataChanged();
			if (this.reportList != null && row < this.reportList.size()) {
				this.selectedFilename = this.reportList.elementAt(row);
				arrTool.getAnalysis().nullifySelectedAnnotation();
				arrTool.getDocumentPane().setSelectedDocument(
						this.selectedFilename);
				arrTool.setTitle();
				resetLabel();
			}
		}

		public void processMouseEvent(MouseEvent e) {
			processingMouseEvent = true;
			super.processMouseEvent(e);
			processingMouseEvent = false;
		}

		public int getRowHeight(int row) {
			return 15;
		}

		public Component prepareRenderer(TableCellRenderer renderer,
				int rowIndex, int colIndex) {
			Component c = super.prepareRenderer(renderer, rowIndex, colIndex);
			Color color = getColor(rowIndex, colIndex);
			c.setBackground(color);
			return c;
		}

		public TableCellEditor getCellEditor() {
			return super.getCellEditor();
		}

		Color getColor(int row, int col) {
			boolean selectedCell = (row == reportListTable.selectedRow && col == reportListTable.selectedColumn);
			return (selectedCell ? selectedCellColor : unselectedColor);
		}
	};

	public class ReportListJTableModel extends AbstractTableModel {
		ReportListPane pane = null;

		ReportListJTableModel(ReportListPane pane) {
			this.pane = pane;
			this.fireTableRowsInserted(0, getRowCount());
		}

		public int getColumnCount() {
			return 2;
		}

		public int getRowCount() {
			resetLabel();
			if (reportListTable != null && reportListTable.reportList != null) {
				if (reportListTable.reportList.size() == 1) {
					return 2;
				}
				return reportListTable.reportList.size();
			}
			return 0;
		}

		public String getColumnName(int col) {
			if (col == 0) {
				return "Reports";
			}
			if (pane.reportListTable != null
					&& pane.reportListTable.currentOEMType != null) {
				return pane.reportListTable.currentOEMType;
			}
			return "*";
		}

		public Object getValueAt(int row, int col) {
			if (reportListTable.reportList != null
					&& row < reportListTable.reportList.size()) {
				String rname = reportListTable.reportList.elementAt(row);
				if (col == 0) {
					return rname;
				} else if (arrTool.statistics != null) {
					Classification c = arrTool.getAnalysis()
							.getSelectedClassification();
					return arrTool.statistics.getOutcomeDocumentMeasureCount(c,
							rname, this.pane.reportListTable.currentOEMType);
					// Before 3/30/2012
//					return arrTool.statistics.getOutcomeDocumentMeasureCount(
//							c.getValue(), rname,
//							this.pane.reportListTable.currentOEMType);
				}
			}
			return "*";
		}

		// Before 2/17/2012
		// public Object getValueAt(int row, int col) {
		// if (reportListTable.reportList != null
		// && row < reportListTable.reportList.size()) {
		// return reportListTable.reportList.elementAt(row);
		// }
		// return null;
		// }

		public Class getColumnClass(int col) {
			return String.class;
		}

		public boolean isCellEditable(int row, int col) {
			return false;
		}

		private void setColumnWidth(int col, int width) {
			TableColumn column = reportListTable.getColumnModel()
					.getColumn(col);
			column.setMaxWidth(width);
			column.setMinWidth(width);
			column.setWidth(width);
			column.setPreferredWidth(width);
			reportListTable.sizeColumnsToFit(-1);
		}

		private int getPreferredColumnWidth(int col) {
			return 160;
		}

		public void setPreferredColumnWidth(int col) {
			int width = getPreferredColumnWidth(col);
			setColumnWidth(col, width);
		}
	}

	public void mouseMoved(MouseEvent e) {
		if (e.isControlDown()) {
			processingMouseMoved = true;
			Point p = new Point(e.getX(), e.getY());
			int col = reportListTable.columnAtPoint(p);
			int row = reportListTable.rowAtPoint(p);
			if (col != lastMouseColumn || row != lastMouseRow) {
				lastMouseRow = reportListTable.selectedRow = row;
				lastMouseColumn = reportListTable.selectedColumn = col;
				reportListTable.doSelection(row, col);
			}
			processingMouseMoved = false;
		}
	}

	public void mouseDragged(MouseEvent e) {
	}

	/** ******* Mouse operations ****** */
	public void mousePressed(MouseEvent e) {

	}

	public void mouseReleased(MouseEvent e) {

	}

	public void mouseEntered(MouseEvent e) {

	}

	public void mouseExited(MouseEvent e) {

	}

	public void mouseClicked(MouseEvent e) {

	}

}
