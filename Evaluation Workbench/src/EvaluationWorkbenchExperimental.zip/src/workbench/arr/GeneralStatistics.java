package workbench.arr;

import java.util.Collections;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;
import onyx.document.document.Document;
import annotation.AnnotationCollection;
import annotation.Classification;
import annotation.EVAnnotation;
import typesystem.Annotation;
import typesystem.Attribute;
import workbench.arr.ClassificationStatisticsPane.AccuracyJTableModel;
import onyx.utilities.HUtils;
import onyx.utilities.VUtils;

public class GeneralStatistics {
	EvaluationWorkbench arrTool = null;
	Hashtable<String, Vector<String>> documentTruePositiveFileHash = new Hashtable();
	Hashtable<String, Vector<String>> documentTrueNegativeFileHash = new Hashtable();
	Hashtable<String, Vector<String>> documentFalsePositiveFileHash = new Hashtable();
	Hashtable<String, Vector<String>> documentFalseNegativeFileHash = new Hashtable();
	Hashtable<String, Integer> selectionOutcomeMeasureHash = new Hashtable();
	Hashtable<String, Vector> documentTruePositiveCountHash = new Hashtable();
	Hashtable<String, Vector> documentTrueNegativeCountHash = new Hashtable();
	Hashtable<String, Vector> documentFalsePositiveCountHash = new Hashtable();
	Hashtable<String, Vector> documentFalseNegativeCountHash = new Hashtable();
	int totalTruePositive = 0;
	int totalFalsePositive = 0;
	int totalTrueNegative = 0;
	int totalFalseNegative = 0;

	Object selectedItem = null;
	Vector alternativeValues = null;
	public static GeneralStatistics statistics = null;

	static String TruePositive = "TP";
	static String TrueNegative = "TN";
	static String TrueMissing = "TM";
	static String FalsePositive = "FP";
	static String FalseNegative = "FN";
	static String FalseMissing = "FM";

	public GeneralStatistics(EvaluationWorkbench arrTool, Object o) {
		this.arrTool = arrTool;
		this.arrTool.statistics = statistics = this;
		this.selectedItem = o;
		gatherAlternativeValues();
		if (this.alternativeValues != null) {
			doAnalysis();
		}
	}

	public static GeneralStatistics create(EvaluationWorkbench arrTool, Object o) {
		GeneralStatistics gs = new GeneralStatistics(arrTool, o);
		arrTool.analysis.setDoRefreshClassifications();
		arrTool.accuracyPane.doExternalSelection();
		return gs;
	}

	public static GeneralStatistics create(EvaluationWorkbench arrTool) {
		return create(arrTool, null);
	}

	void doAnalysis() {
		for (Document document : arrTool.analysis.getAllDocuments()) {
			if (this.selectedItemIsAnnotation()) {
				analyzeAnnotationMatch(document,
						arrTool.analysis.getSelectedLevel());
			} else if (this.selectedItemIsAttribute()) {
				analyzeAttributeAttributeValueMatch(document);
			} else if (this.selectItemIsLevel()) {
				analyzeLevelMatch(document);
			}
		}
	}

	void analyzeLevelMatch(Document document) {
		AnnotationEvent ae = arrTool.analysis.getAnnotationEvent(document);
		AnnotationCollection primaryAC = ae.getPrimaryAnnotationCollection();
		AnnotationCollection secondaryAC = ae
				.getSecondaryAnnotationCollection();
		for (Enumeration e = this.alternativeValues.elements(); e
				.hasMoreElements();) {
			typesystem.Classification c = (typesystem.Classification) e
					.nextElement();
			Annotation parent = (Annotation) c.getParent();
			Class level = parent.getAnnotationClass();
			Vector<Vector<EVAnnotation>> matching = AnnotationCollection
					.getMatchingAnnotations(level, null, primaryAC, secondaryAC);
			if (matching != null) {
				for (Vector<EVAnnotation> pair : matching) {
					EVAnnotation primary = pair.firstElement();
					EVAnnotation secondary = pair.lastElement();
					if (primary == null
							|| secondary == null
							|| primary.getClassification().equals(
									secondary.getClassification())) {
						String result = matchLevel(document, primary, secondary);
						Object key = getResultKey(c, result);
						HUtils.incrementCount(selectionOutcomeMeasureHash, key);
						key = getDocumentResultKey(c, document.getName(),
								result);
						HUtils.incrementCount(selectionOutcomeMeasureHash, key);
					}
				}
			}
		}
	}

	void analyzeAnnotationMatch(Document document, Class level) {
		AnnotationEvent ae = arrTool.analysis.getAnnotationEvent(document);
		AnnotationCollection primaryAC = ae.getPrimaryAnnotationCollection();
		AnnotationCollection secondaryAC = ae
				.getSecondaryAnnotationCollection();
		for (Enumeration e = this.alternativeValues.elements(); e
				.hasMoreElements();) {
			Classification classification = (Classification) e.nextElement();
			Vector<Vector<EVAnnotation>> matching = AnnotationCollection
					.getMatchingAnnotations(level, classification, primaryAC,
							secondaryAC);
			if (matching != null) {
				for (Vector<EVAnnotation> pair : matching) {
					EVAnnotation primary = pair.firstElement();
					EVAnnotation secondary = pair.lastElement();
					String result = matchClassification(document, primary,
							secondary);
					if (isMismatch(result)) {
						if (primary != null) {
							primary.setHasMismatch(true);
						}
						if (secondary != null) {
							secondary.setHasMismatch(true);
						}
					}
					
					// 3/30/2012
					Object key = getResultKey(classification, result);
					HUtils.incrementCount(selectionOutcomeMeasureHash, key);
					key = getDocumentResultKey(classification,
							document.getName(), result);
					HUtils.incrementCount(selectionOutcomeMeasureHash, key);
					
					// 3/28/2012 -- Since different classification properties may be visible,
					// need to index on all of them.  (Is there a better way?  Could use all
					// the properties together as the index...)
//					for (String attribute : classification.getPropertyNames()) {
//						Object value = classification.getProperty(attribute);
//						Object key = getResultKey(value, result);
//						HUtils.incrementCount(selectionOutcomeMeasureHash, key);
//						key = getDocumentResultKey(value, document.getName(),
//								result);
//						HUtils.incrementCount(selectionOutcomeMeasureHash, key);
//					}
					
					// Before 3/28/2012
//					Object key = getResultKey(classification, result);
//					HUtils.incrementCount(selectionOutcomeMeasureHash, key);
//					key = getDocumentResultKey(classification,
//							document.getName(), result);
//					HUtils.incrementCount(selectionOutcomeMeasureHash, key);

				}
			}
		}
	}

	void analyzeAttributeAttributeValueMatch(Document document) {
		String attribute = getSelectedAttribute();
		AnnotationEvent ae = arrTool.analysis.getAnnotationEvent(document);
		AnnotationCollection primaryAC = ae.getPrimaryAnnotationCollection();
		AnnotationCollection secondaryAC = ae
				.getSecondaryAnnotationCollection();
		Vector<Vector<EVAnnotation>> matching = AnnotationCollection
				.getMatchingAnnotations(arrTool.analysis.getSelectedLevel(),
						null, primaryAC, secondaryAC);
		if (matching != null) {
			for (Vector<EVAnnotation> pair : matching) {
				EVAnnotation primary = pair.firstElement();
				EVAnnotation secondary = pair.lastElement();
				for (Object value : this.alternativeValues) {
					String result = matchAttributeValue(document, primary,
							secondary, attribute, value.toString());
					Object key = getResultKey(attribute, value, result);
					HUtils.incrementCount(selectionOutcomeMeasureHash, key);

					// 2/17/2012
					key = getDocumentResultKey(attribute, document.getName(),
							result);
					HUtils.incrementCount(selectionOutcomeMeasureHash, key);
				}
			}
		}
	}

	void gatherAlternativeValues() {
		this.alternativeValues = null;
		if (this.selectedItemIsAttribute()) {
			String attribute = null;
			String value = null;
			if (this.selectedItem instanceof Attribute) {
				attribute = ((Attribute) this.selectedItem).getName();
			} else {
				String[] avpair = ((String) this.selectedItem).split("=");
				attribute = avpair[0];
				value = avpair[1];
			}
			Vector v = this.arrTool.getAnalysis().getClassAttributeValues(
					attribute);
			if (v != null) {
				Vector values = new Vector(v);
				if (value != null) {
					values.remove(value);
					values.insertElementAt(value, 0);
				}
				this.alternativeValues = values;
			}
		} else if (this.selectedItemIsAnnotation()) {
			this.alternativeValues = arrTool.getAnalysis().getClassifications();
		} else if (this.selectItemIsLevel()) {
			Annotation annotation = (Annotation) this.selectedItem;
			this.alternativeValues = annotation.getClassifications();
		}
	}

	public boolean isMismatch(String result) {
		return result == FalsePositive || result == FalseNegative;
	}
	
	static String getResultKey(Object o, String result) {
		String str = null;
		if (o instanceof annotation.Classification) {
			annotation.Classification c = (annotation.Classification) o;
			str = c.getAttributeString();
		} else {
			str = o.toString();
		}
		return str + ":" + result;
	}
	
	// Before 3/30/2012
//	static String getResultKey(Object o, String result) {
//		return o + ":" + result;
//	}

	static String getResultKey(String attribute, Object value, String result) {
		return attribute + ":" + value + ":" + result;
	}
	
	static String getDocumentResultKey(Object o, String document, String result) {
		String str = null;
		if (o instanceof annotation.Classification) {
			annotation.Classification c = (annotation.Classification) o;
			str = c.getAttributeString();
		} else {
			str = o.toString();
		}
		return str + ":" + document + ":" + result;
	}

	// Before 3/30/2012
//	static String getDocumentResultKey(Object o, String document, String result) {
//		return o + ":" + document + ":" + result;
//	}

	String matchLevel(Document document, EVAnnotation primary,
			EVAnnotation secondary) {
		Class level = (primary != null ? primary.getClass() : null);
		if (EVAnnotation.isPresentLevel(primary, level)) {
			if (EVAnnotation.isPresentLevel(secondary, level)) {
				VUtils.pushIfNotHashVector(documentTruePositiveFileHash, level,
						document.getName());
				return TruePositive;
			}
			VUtils.pushIfNotHashVector(documentFalseNegativeFileHash, level,
					document.getName());
			return FalseNegative;
		}
		if (EVAnnotation.isPresentLevel(secondary, level)) {
			VUtils.pushIfNotHashVector(documentFalsePositiveFileHash, level,
					document.getName());
			return FalsePositive;
		}
		VUtils.pushIfNotHashVector(documentTrueNegativeFileHash, level,
				document.getName());
		return TrueNegative;
	}
	
	String matchClassification(Document document, EVAnnotation primary,
			EVAnnotation secondary) {
		Classification classification = (primary != null ? primary
				.getClassification() : null);
		String key = classification.getAttributeString();
		if (EVAnnotation.isPresentClassification(primary, classification)) {
			if (EVAnnotation.isPresentClassification(secondary, classification)) {
				VUtils.pushIfNotHashVector(documentTruePositiveFileHash,
						key, document.getName());
				HUtils.incrementHashObjectInfoWrapper(
						documentTruePositiveCountHash, key,
						document.getName());
				this.totalTruePositive++;
				return TruePositive;
			}
			VUtils.pushIfNotHashVector(documentFalseNegativeFileHash,
					key, document.getName());
			HUtils.incrementHashObjectInfoWrapper(
					documentFalseNegativeCountHash, key,
					document.getName());
			this.totalFalseNegative++;
			return FalseNegative;
		}
		if (EVAnnotation.isPresentClassification(secondary, classification)) {
			VUtils.pushIfNotHashVector(documentFalsePositiveFileHash,
					key, document.getName());
			HUtils.incrementHashObjectInfoWrapper(
					documentFalsePositiveCountHash, key,
					document.getName());
			this.totalFalsePositive++;
			return FalsePositive;
		}
		VUtils.pushIfNotHashVector(documentTrueNegativeFileHash,
				key, document.getName());
		HUtils.incrementHashObjectInfoWrapper(documentTrueNegativeCountHash,
				key, document.getName());
		this.totalTrueNegative++;
		return TrueNegative;
	}

	// Before 3/30/2012
//	String matchClassification(Document document, EVAnnotation primary,
//			EVAnnotation secondary) {
//		Classification classification = (primary != null ? primary
//				.getClassification() : null);
//		if (EVAnnotation.isPresentClassification(primary, classification)) {
//			if (EVAnnotation.isPresentClassification(secondary, classification)) {
//				VUtils.pushIfNotHashVector(documentTruePositiveFileHash,
//						classification, document.getName());
//				HUtils.incrementHashObjectInfoWrapper(
//						documentTruePositiveCountHash, classification,
//						document.getName());
//				this.totalTruePositive++;
//				return TruePositive;
//			}
//			VUtils.pushIfNotHashVector(documentFalseNegativeFileHash,
//					classification, document.getName());
//			HUtils.incrementHashObjectInfoWrapper(
//					documentFalseNegativeCountHash, classification,
//					document.getName());
//			this.totalFalseNegative++;
//			return FalseNegative;
//		}
//		if (EVAnnotation.isPresentClassification(secondary, classification)) {
//			VUtils.pushIfNotHashVector(documentFalsePositiveFileHash,
//					classification, document.getName());
//			HUtils.incrementHashObjectInfoWrapper(
//					documentFalsePositiveCountHash, classification,
//					document.getName());
//			this.totalFalsePositive++;
//			return FalsePositive;
//		}
//		VUtils.pushIfNotHashVector(documentTrueNegativeFileHash,
//				classification, document.getName());
//		HUtils.incrementHashObjectInfoWrapper(documentTrueNegativeCountHash,
//				classification, document.getName());
//		this.totalTrueNegative++;
//		return TrueNegative;
//	}

	String matchAttributeValue(Document document, EVAnnotation primary,
			EVAnnotation secondary, String attribute, String value) {
		String avpair = attribute + "=" + value;
		if (EVAnnotation.isPresentAttributeValue(primary, attribute, value)) {
			if (EVAnnotation.isPresentAttributeValue(secondary, attribute,
					value)) {
				VUtils.pushIfNotHashVector(documentTruePositiveFileHash,
						avpair, document.getName());
				return TruePositive;
			}
			VUtils.pushIfNotHashVector(documentFalseNegativeFileHash, avpair,
					document.getName());
			return FalseNegative;
		}
		if (EVAnnotation.isPresentAttributeValue(secondary, attribute, value)) {
			VUtils.pushIfNotHashVector(documentFalsePositiveFileHash, avpair,
					document.getName());
			return FalsePositive;
		}
		VUtils.pushIfNotHashVector(documentTrueNegativeFileHash, avpair,
				document.getName());
		return TrueNegative;
	}
	
	// 3/1/2012 -- Adding the first summary row.
	public Object getValueAt(int row, int col) {
		row = row - 1;
		if (col == 0) {
			return getFirstColumnName(row);
		}
		if (row == -1) {
			switch (col) {
			case 1:
				return new Integer(getCumulativeOutcomeMeasureCount(TruePositive, -1));
			case 2:
				return new Integer(getCumulativeOutcomeMeasureCount(FalsePositive, -1));
			case 3:
				return new Integer(getCumulativeOutcomeMeasureCount(TrueNegative, -1));
			case 4:
				return new Integer(getCumulativeOutcomeMeasureCount(FalseNegative, -1));
			case 5:
				return getAccuracy(row);
			case 6:
				return getPPV(row);
			case 7:
				return getSensitivity(row);
			case 8:
				return getNPV(row);
			case 9:
				return getSpecificity(row);
			}
		} else {
			switch (col) {
			case 1:
				return getTruePositive(row);
			case 2:
				return getFalsePositive(row);
			case 3:
				return getTrueNegative(row);
			case 4:
				return getFalseNegative(row);
			case 5:
				return getAccuracy(row);
			case 6:
				return getPPV(row);
			case 7:
				return getSensitivity(row);
			case 8:
				return getNPV(row);
			case 9:
				return getSpecificity(row);
			}
		}
		return "*";
	}

	public int getTruePositive(int row) {
		return new Integer(getOutcomeMeasureCount(TruePositive, row));
	}

	public int getFalsePositive(int row) {
		return new Integer(getOutcomeMeasureCount(FalsePositive, row));
	}

	public int getTrueNegative(int row) {
		return new Integer(getOutcomeMeasureCount(TrueNegative, row));
	}

	public int getFalseNegative(int row) {
		return new Integer(getOutcomeMeasureCount(FalseNegative, row));
	}

	public String getAccuracy(int row) {
		float tp = getTruePositive(row);
		float fp = getFalsePositive(row);
		float tn = getTrueNegative(row);
		float fn = getFalseNegative(row);
		float num = tp + tn;
		float den = tp + fp + tn + fn;
		return getResultString(num, den);
	}

	public String getPPV(int row) {
		float tp = getTruePositive(row);
		float fp = getFalsePositive(row);
		float num = tp;
		float den = tp + fp;
		return getResultString(num, den);
	}

	public String getSensitivity(int row) {
		float tp = getTruePositive(row);
		float fn = getFalseNegative(row);
		float num = tp;
		float den = tp + fn;
		return getResultString(num, den);
	}

	public String getNPV(int row) {
		float tn = getTrueNegative(row);
		float fn = getFalseNegative(row);
		float num = tn;
		float den = tn + fn;
		return getResultString(num, den);
	}

	public String getSpecificity(int row) {
		float fp = getFalsePositive(row);
		float tn = getTrueNegative(row);
		float num = tn;
		float den = tn + fp;
		return getResultString(num, den);
	}

	String getResultString(float numerator, float denominator) {
		float result = 0;
		String resultString = "*";
		if (denominator > 0) {
			result = numerator / denominator;
			resultString = String.valueOf(result);
			if (resultString.length() > 4) {
				resultString = resultString.substring(0, 4);
			}
		}
		return resultString;
	}
	
	// 2/17/2012
	public static String getSelectedOEMType(int col) {
		switch (col) {
		case 1:
			return TruePositive;
		case 2:
			return FalsePositive;
		case 3:
			return TrueNegative;
		case 4:
			return FalseNegative;
		}
		return null;
	}

	public int getRowCount() {
		if (doCompareConglomerate(arrTool)) {
			return 2;
		}
		if (this.alternativeValues != null) {
			return (this.alternativeValues.size());
		}
		return 0;
	}

	String getFirstColumnName(int row) {
		if (row < 0) {
			return "SUMMARY";
		}
		if (doCompareConglomerate(arrTool)) {
			return getFirstColumnNameSummary(row);
		} else {
			return getFirstColumnNameAll(row);
		}
	}

	String getFirstColumnNameAll(int row) {
		Object value = (this.alternativeValues != null ? this.alternativeValues
				.elementAt(row) : null);
		if (this.selectedItemIsAnnotation()) {
			return (row + 1) + ":" + value.toString();
		}
		if (this.selectedItemIsAttribute()) {
			return (this.getSelectedAttribute() + "=" + value);
		}
		if (this.selectItemIsLevel()) {
			typesystem.Classification c = (typesystem.Classification) value;
			return c.toString();
		}
		return "*";
	}

	String getFirstColumnNameSummary(int row) {
		int selectedRow = 0;
		if (this.selectedItemIsAnnotation()
				&& arrTool.accuracyPane.selectedPane.getSelectedRow() >= 0) {
			selectedRow = arrTool.accuracyPane.selectedPane.getSelectedRow();
		}
		if (row == 0) {
			Vector av = this.alternativeValues;
			Object value = (this.alternativeValues != null ? this.alternativeValues
					.elementAt(selectedRow) : null);
			if (this.selectedItemIsAnnotation()) {
				return value.toString();
			}
			if (this.selectedItemIsAttribute()) {
				return (this.getSelectedAttribute() + "=" + value);
			}
			if (this.selectItemIsLevel()) {
				Annotation annotation = (Annotation) this.selectedItem;
				typesystem.Classification c = annotation
						.getFirstClassification();
				return c.toString();
			}
		} else {
			return "REST";
		}
		return "*";
	}
	
	public int getOutcomeMeasureCount(String result, int row) {
		if (doCompareConglomerate(arrTool)) {
			return getOutcomeMeasureCountSummary(result, row);
		} else if (row == -1) {
			return getCumulativeOutcomeMeasureCount(result, -1);
		} else {
			return getOutcomeMeasureCountAll(result, row);
		}
	}


	// Before 3/1/2012
//	public int getOutcomeMeasureCount(String result, int row) {
//		if (doCompareConglomerate(arrTool)) {
//			return getOutcomeMeasureCountSummary(result, row);
//		} else {
//			return getOutcomeMeasureCountAll(result, row);
//		}
//	}

	public int getOutcomeMeasureCountAll(String result, int row) {
		String attribute = this.getSelectedAttribute();
		Object value = (this.alternativeValues != null ? this.alternativeValues
				.elementAt(row) : null);
		Object key = null;
		if (this.selectedItemIsAnnotation() || this.selectItemIsLevel()) {
			key = getResultKey(value, result);
		} else if (this.selectedItemIsAttribute()) {
			key = getResultKey(attribute, value, result);
		}
		if (key != null) {
			return HUtils.getCount(selectionOutcomeMeasureHash, key);
		}
		return 0;
	}
	
	public int getOutcomeDocumentMeasureCount(Classification classification, String rname,
			String result) {
		Object key = getDocumentResultKey(classification, rname, result);
		return HUtils.getCount(selectionOutcomeMeasureHash, key);
	}

	// Before 3/30/2012
//	public int getOutcomeDocumentMeasureCount(String cname, String rname,
//			String result) {
//		Object key = getDocumentResultKey(cname, rname, result);
//		return HUtils.getCount(selectionOutcomeMeasureHash, key);
//	}

	public int getOutcomeMeasureCountSummary(String result, int row) {
		int selectedRow = 0;
		if (this.selectedItemIsAnnotation()
				&& arrTool.accuracyPane.selectedPane.getSelectedRow() >= 0) {
			selectedRow = arrTool.accuracyPane.selectedPane.getSelectedRow();
		}
		if (row == 1) {
			return getCumulativeOutcomeMeasureCount(result, selectedRow);
		} else {
			return getOutcomeMeasureCountAll(result, selectedRow);
		}
	}
	
	public int getCumulativeOutcomeMeasureCount(String result, int selectedRow) {
		String attribute = this.getSelectedAttribute();
		int count = 0;
		if (this.alternativeValues != null) {
			for (int i = 0; i < this.alternativeValues.size(); i++) {
				if (selectedRow == -1 || i != selectedRow) {
					Object key = null;
					Object value = this.alternativeValues.elementAt(i);
					if (this.selectedItemIsAnnotation()
							|| this.selectItemIsLevel()) {
						key = getResultKey(value, result);
					} else if (this.selectedItemIsAttribute()) {
						key = getResultKey(attribute, value, result);
					}
					if (key != null) {
						Object o = this.selectionOutcomeMeasureHash.get(key);
						if (o != null) {
							count += (Integer) o;
						}
					}
				}
			}
		}
		return count;
	}

	public String getOEMSummaryString() {
		StringBuffer sb = new StringBuffer();
		AccuracyJTableModel model = this.arrTool.accuracyPane.firstPane.model;
		int numcols = model.getColumnCount();
		int numrows = model.getRowCount();
		sb.append("Level=");
		sb.append(this.arrTool.getAnalysis().getSelectedLevel().getSimpleName());
		sb.append("\n");
		for (int row = 0; row < numrows; row++) {
			for (int col = 0; col < numcols; col++) {
				String name = model.getColumnName(col);
				Object value = this.getValueAt(row, col);
				sb.append(name + "=" + value);
				if (col < numcols - 1) {
					sb.append(",");
				}
			}
			sb.append("\n");
		}
		return sb.toString();
	}

	public static boolean doCompareConglomerate(EvaluationWorkbench arrTool) {
		return arrTool.accuracyPane.isCompareConglomerate();
	}

	public String getSelectedItemString() {
		if (this.selectedItem instanceof EVAnnotation) {
			return ((EVAnnotation) this.selectedItem).getClassification()
					.toString();
		} else if (this.selectedItem instanceof String) {
			return this.selectedItem.toString();
		}
		return null;
	}

	public boolean selectedItemIsAnnotation() {
		return this.selectedItem instanceof EVAnnotation
				|| this.selectedItem == null;
	}

	public boolean selectedItemIsAttribute() {
		return this.selectedItem instanceof String
				|| this.selectedItem instanceof Attribute;
	}

	public boolean selectItemIsLevel() {
		return this.selectedItem instanceof Annotation;
	}

	public String getSelectedAttribute() {
		if (this.selectedItem instanceof Attribute) {
			return ((Attribute) this.selectedItem).getName();
		}
		if (this.selectedItem instanceof String) {
			String[] strings = ((String) this.selectedItem).split("=");
			return strings[0];
		}
		return null;
	}

	EVAnnotation getSelectedAnnotation() {
		if (this.selectedItemIsAnnotation()) {
			return (EVAnnotation) this.selectedItem;
		}
		return null;
	}

	public Vector getTruePositiveReports(Classification classification) {
		Vector<String> reports = null;
		try {
			String key = classification.getAttributeString();
			reports = documentTruePositiveFileHash
					.get(key);
			if (reports != null) {
				Collections.sort(reports);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return reports;
	}

	public Vector getTrueNegativeReports(Classification classification) {
		String key = classification.getAttributeString();
		Vector<String> reports = (Vector) documentTrueNegativeFileHash
				.get(key);
		if (reports != null) {
			Collections.sort(reports);
		}
		return reports;
	}

	public Vector getFalsePositiveReports(Classification classification) {
		String key = classification.getAttributeString();
		Vector<String> reports = documentFalsePositiveFileHash
				.get(key);
		if (reports != null) {
			Collections.sort(reports);
		}
		return reports;
	}

	public Vector getFalseNegativeReports(Classification classification) {
		String key = classification.getAttributeString();
		Vector<String> reports = documentFalseNegativeFileHash
				.get(key);
		if (reports != null) {
			Collections.sort(reports);
		}
		return reports;
	}
	
	// Before 3/30/2012
//	public Vector getTruePositiveReports(Classification classification) {
//		Vector<String> reports = null;
//		try {
//			reports = documentTruePositiveFileHash
//					.get(classification);
//			if (reports != null) {
//				Collections.sort(reports);
//			}
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//		return reports;
//	}
//
//	public Vector getTrueNegativeReports(Classification classification) {
//		Vector<String> reports = (Vector) documentTrueNegativeFileHash
//				.get(classification);
//		if (reports != null) {
//			Collections.sort(reports);
//		}
//		return reports;
//	}
//
//	public Vector getFalsePositiveReports(Classification classification) {
//		Vector<String> reports = documentFalsePositiveFileHash
//				.get(classification);
//		if (reports != null) {
//			Collections.sort(reports);
//		}
//		return reports;
//	}
//
//	public Vector getFalseNegativeReports(Classification classification) {
//		Vector<String> reports = documentFalseNegativeFileHash
//				.get(classification);
//		if (reports != null) {
//			Collections.sort(reports);
//		}
//		return reports;
//	}

}
