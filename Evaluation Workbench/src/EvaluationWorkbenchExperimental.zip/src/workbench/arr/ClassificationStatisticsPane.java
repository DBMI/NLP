package workbench.arr;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.util.Vector;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.TableCellEditor;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumn;

import onyx.utilities.VUtils;
import annotation.Classification;

public class ClassificationStatisticsPane extends JPanel implements
		MouseMotionListener, MouseListener, ActionListener {
	EvaluationWorkbench arrTool = null;

	AccuracyJTableModel model = null;

	AccuracyJTable accuracyTable = null;

	JLabel label = null;

	static Font smallFont = new Font("Serif", Font.PLAIN, 12);

	static Color tempColor = new Color(0xffffff);

	static boolean processingMouseEvent = false;

	static boolean processingMouseMoved = false;

	int lastMouseRow = -1;

	int lastMouseColumn = -1;

	int lastSelectedMouseRow = -1;

	int lastSelectedMouseColumn = -1;

	static Color selectedCellColor = Colors.veryDarkBlueGray;

	static Color selectedRowColor = Colors.darkBlueGray;

	static Color selectedColumnColor = Colors.darkBlueGray;

	static Color unselectedColor = Color.white;

	static int gvacount = 0;

	static Vector<String> columnLabels = VUtils.arrayToVector(new String[] {
			"Concept", "TP", "FP", "TN", "FN", "Acc", "PPV", "Sen", "NPV",
			"Spec" });

	public ClassificationStatisticsPane(EvaluationWorkbench tool) {
		super(new BorderLayout());
		arrTool = tool;
		model = new AccuracyJTableModel();
		accuracyTable = new AccuracyJTable(this);
		initializeColumns();
		accuracyTable
				.setPreferredScrollableViewportSize(new Dimension(600, 300));
		accuracyTable.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
		accuracyTable.addMouseMotionListener(this);
		accuracyTable.addMouseListener(this);
		this.label = new JLabel("LEVEL", null, JLabel.CENTER);
		add(this.label, BorderLayout.PAGE_START);
		JPanel pane = new JPanel();
		pane.add(new JScrollPane(accuracyTable));
		add(pane, BorderLayout.CENTER);
		this.setOpaque(true);
	}

	public void actionPerformed(ActionEvent e) {
		String command = e.getActionCommand();
	}

	public void selectByClassification(Classification classification) {
		int row = arrTool.getAnalysis().findClassificationRow(classification);
		if (row >= 0) {
			lastSelectedMouseRow = accuracyTable.selectedRow = row;
			lastSelectedMouseColumn = accuracyTable.selectedColumn;
			accuracyTable
					.doExternalSelection(row, accuracyTable.selectedColumn);
		}
	}

	void initializeColumns() {
		for (int i = 0; i < accuracyTable.getColumnCount(); i++) {
			TableColumn column = accuracyTable.getColumnModel().getColumn(i);
			int width = (i == 0 ? 200 : 40);
			column.setPreferredWidth(width);
		}
	}

	public void resetLabel() {
		String str = "OUTCOME MEASURES (";
		if (arrTool.getAnalysis().getSelectedLevel() != null) {
			str += arrTool.getAnalysis().getSelectedLevel().getSimpleName();
		}
		str += ")";
		this.label.setText(str);
	}

	public String getColumnLabel(int col) {
		if (col < columnLabels.size()) {
			return columnLabels.elementAt(col);
		}
		return "*";
	}

	public class AccuracyJTable extends JTable implements ListSelectionListener {
		ClassificationStatisticsPane cpane = null;
		Vector accuracy = null;

		int selectedRow = -1;

		int selectedColumn = -1;

		AccuracyJTable(ClassificationStatisticsPane cpane) {
			super(model);
			this.cpane = cpane;
			accuracyTable = this;
			this.setShowGrid(true);
			this.setGridColor(Color.GRAY);
			this.setRowHeight(15);
			this.setFont(smallFont);
			setToolTipText("");
		}

		boolean isInternalOrValidExternalOperation() {
			return (withUserInteraction() || GraphPane.withUserInteraction() || DocumentPane
					.withUserInteraction());
		}

		void populate() {
			if (arrTool.analysis != null
					&& isInternalOrValidExternalOperation()) {

				model.fireTableRowsInserted(0, getRowCount());
				model.fireTableDataChanged();
			}
		}

		public void doExternalSelection(int row, int col) {
			if (row >= 0
					&& row < arrTool.getAnalysis().getClassifications().size()) {
				lastSelectedMouseRow = accuracyTable.selectedRow = row;
				lastSelectedMouseColumn = accuracyTable.selectedColumn = col;
				populate();
				showCell(row, col);
			}
		}

		public void doExternalSelection() {
			EvaluationWorkbench workbench = arrTool;
			int row = arrTool.getAnalysis().getClassificationRow();
			int col = accuracyTable.selectedColumn;
			if (row >= 0
					&& row < arrTool.getAnalysis().getClassifications().size()) {
				lastSelectedMouseRow = accuracyTable.selectedRow = row;
				lastSelectedMouseColumn = accuracyTable.selectedColumn = col;
				populate();
				showCell(row, col);
			}
		}

		public void doSelection(int row, int col) {
			Classification classification = null;
			if (!canDoUserSelection()) {
				model.fireTableDataChanged();
				return;
			}
			// 3/5/2012
			int classRow = row - 1;
			if (classRow >= 0 && arrTool.statistics != null
					&& arrTool.statistics instanceof GeneralStatistics
					&& arrTool.statistics.selectedItemIsAnnotation()) {
				classification = (Classification) arrTool.statistics.alternativeValues
						.elementAt(classRow);
				arrTool.getAnalysis().setSelectedClassification(classification);
				arrTool.getAnalysis().setSelectedAnnotation();
			} else {
				Vector<Classification> classifications = arrTool.getAnalysis()
						.getClassifications();
				if (classRow >= 0 && classifications != null && classRow < classifications.size()) {
					classification = (Classification) classifications
							.elementAt(classRow);
					arrTool.getAnalysis().setSelectedClassification(
							classification);
					arrTool.getAnalysis().setSelectedAnnotation();
				}
			}
			if (classification != null && arrTool.statistics != null) {
				arrTool.detailPane.reportListPane.reportListTable
						.setReportList(classification, col);
				arrTool.fireAllTableDataChanged();
				showCell(row, col);
			}
		}
		
		// Before 3/5/2012
//		public void doSelection(int row, int col) {
//			Classification classification = null;
//			if (!canDoUserSelection()) {
//				model.fireTableDataChanged();
//				return;
//			}
//			if (arrTool.statistics != null
//					&& arrTool.statistics instanceof GeneralStatistics
//					&& arrTool.statistics.selectedItemIsAnnotation()) {
//				classification = (Classification) arrTool.statistics.alternativeValues
//						.elementAt(row);
//				arrTool.getAnalysis().setSelectedClassification(classification);
//				arrTool.getAnalysis().setSelectedAnnotation();
//			} else {
//				Vector<Classification> classifications = arrTool.getAnalysis()
//						.getClassifications();
//				if (classifications != null && row < classifications.size()) {
//					classification = (Classification) classifications
//							.elementAt(row);
//					arrTool.getAnalysis().setSelectedClassification(
//							classification);
//					arrTool.getAnalysis().setSelectedAnnotation();
//				}
//			}
//			if (classification != null && arrTool.statistics != null) {
//				arrTool.detailPane.reportListPane.reportListTable
//						.setReportList(classification, col);
//				arrTool.fireAllTableDataChanged();
//				showCell(row, col);
//			}
//		}

		public void processMouseEvent(MouseEvent e) {
			processingMouseEvent = true;
			super.processMouseEvent(e);
			processingMouseEvent = false;
		}

		public int getRowHeight(int row) {
			return 15;
		}

		public Component prepareRenderer(TableCellRenderer renderer,
				int rowIndex, int colIndex) {
			Component c = super.prepareRenderer(renderer, rowIndex, colIndex);
			Color color = getColor(rowIndex, colIndex);
			c.setBackground(color);
			return c;
		}

		public TableCellEditor getCellEditor() {
			return super.getCellEditor();
		}

		Color getColor(int row, int col) {
			boolean isSelectedRow = false;
			boolean isSelectedCol = false;
			// isSelectedRow = (row == lastMouseRow);
			// isSelectedCol = (col == lastMouseColumn);
			isSelectedRow = (row == lastSelectedMouseRow);
			isSelectedCol = (col == lastSelectedMouseColumn);
			Class level = arrTool.getAnalysis().getSelectedLevel();
			if (col > 0) {
				if (isSelectedRow && isSelectedCol) {
					return selectedCellColor;
				}
				if (isSelectedCol) {
					return selectedColumnColor;
				}
			}
			if (isSelectedRow) {
				return selectedRowColor;
			}
			return Colors.getUnselectedClassificationPaneColor(level);
		}

		public void showCell(int row, int column) {
			if (!processingMouseMoved) {
				// DOESN'T WORK
				Rectangle rect = getCellRect(row, column, true);
				scrollRectToVisible(rect);
			}
		}

	};

	public class AccuracyJTableModel extends AbstractTableModel {

		AccuracyJTableModel() {
			this.fireTableRowsInserted(0, getRowCount());
		}

		public int getColumnCount() {
			return columnLabels.size();
		}
		
		public int getRowCount() {
			if (arrTool.statistics != null) {
				return arrTool.statistics.getRowCount() + 1;
			}
			return 1;
		}

		// Before 3/1/2012
//		public int getRowCount() {
//			if (arrTool.statistics != null) {
//				return arrTool.statistics.getRowCount();
//			}
//			return 1;
//		}

		public String getColumnName(int col) {
			String name = getColumnLabel(col);
			return name;
		}
		
		public Object getValueAt(int row, int col) {
			if (arrTool.statistics != null) {
				Object o = arrTool.statistics.getValueAt(row, col);
				return o;
			}
			return "*";
		}

		public Class getColumnClass(int col) {
			return String.class;
		}

		public boolean isCellEditable(int row, int col) {
			return false;
		}

		private void setColumnWidth(int col, int width) {
			TableColumn column = accuracyTable.getColumnModel().getColumn(col);
			column.setMaxWidth(width);
			column.setMinWidth(width);
			column.setWidth(width);
			column.setPreferredWidth(width);
			accuracyTable.sizeColumnsToFit(-1);
		}

		private int getPreferredColumnWidth(int col) {
			return (col == 0 ? 200 : 40);
		}

		public void setPreferredColumnWidth(int col) {
			int width = getPreferredColumnWidth(col);
			setColumnWidth(col, width);
		}
	}

	public void mouseMoved(MouseEvent e) {
		if (e.isControlDown() || e.isMetaDown()) {
			processingMouseMoved = true;
			Point p = new Point(e.getX(), e.getY());
			int col = accuracyTable.columnAtPoint(p);
			int row = accuracyTable.rowAtPoint(p);
			if (col != lastSelectedMouseColumn || row != lastSelectedMouseRow) {
				lastSelectedMouseRow = row;
				lastSelectedMouseColumn = col;
				if (!canDoUserSelection()) {
					arrTool.accuracyPane.fireTableDataChanged();
				} else {
					changeSelectedPosition(row, col);
				}
			}
			processingMouseMoved = false;
		}
	}

	public boolean withUserInteraction() {
		return processingMouseMoved;
	}

	public void changeSelectedPosition(int row, int col) {
		lastSelectedMouseRow = accuracyTable.selectedRow = row;
		lastSelectedMouseColumn = accuracyTable.selectedColumn = col;
		accuracyTable.doSelection(row, col);
	}

	boolean canDoUserSelection() {
		if ((withUserInteraction() || DocumentPane.withUserInteraction())
				&& arrTool.statistics.selectedItemIsAnnotation()
				&& !arrTool.doCompareConglomerate()) {
			return true;
		}
		return false;
	}

	public void mouseDragged(MouseEvent e) {
	}

	/** ******* Mouse operations ****** */
	public void mousePressed(MouseEvent e) {

	}

	public void mouseReleased(MouseEvent e) {

	}

	public void mouseEntered(MouseEvent e) {

	}

	public void mouseExited(MouseEvent e) {

	}

	public void mouseClicked(MouseEvent e) {

	}

	public int getSelectedRow() {
		return this.accuracyTable.selectedRow;
	}

	public int getSelectedColumn() {
		return this.accuracyTable.selectedColumn;
	}

}
