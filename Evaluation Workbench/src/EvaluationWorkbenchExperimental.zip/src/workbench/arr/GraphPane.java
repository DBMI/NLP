package workbench.arr;

import java.awt.BorderLayout;
import java.awt.Component;
import java.util.Vector;

import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import typesystem.Annotation;
import typesystem.Attribute;
import typesystem.TypeSystemJTree;
import onyx.utilities.VUtils;
import annotation.AnnotationCollection;
import annotation.EVAnnotation;

public class GraphPane extends JPanel {
	EvaluationWorkbench arrTool = null;
	Vector<Class> levels = new Vector(EVAnnotation.getAnnotationLevels());
	TypeSystemJTree schemaJTreePane = null;
	ClassificationLevelPane classLevelPane = null;
	JTabbedPane tabbedPane = null;
	Vector<TypeSystemLevelJTree> trees = null;
	Vector<Component> tabComponents = null;
	AnnotationCollection annotationCollection = null;
	int selectedTabIndex = 0;
	int selectedLevelIndex = -1;

	public GraphPane(EvaluationWorkbench tool) {
		super(new BorderLayout());
		arrTool = tool;

		classLevelPane = new ClassificationLevelPane(tool);
		add(classLevelPane, BorderLayout.PAGE_START);
		tabbedPane = new JTabbedPane();
		schemaJTreePane = new TypeSystemJTree(tool);
		tabbedPane.addTab("Schem", null, schemaJTreePane, "SchemaPane");
		for (Class level : levels) {
			Annotation annotationType = Annotation.getAnnotationByClass(level);
			TypeSystemLevelJTree tree = new TypeSystemLevelJTree(tool,
					annotationType);
			trees = VUtils.add(trees, tree);
			String name = level.getSimpleName() + "s";
			if (name.length() > 4) {
				name = name.substring(0, 4);
			}
			tabbedPane.addTab(name, null, tree, "");
		}
		for (int i = 0; i < levels.size(); i++) {
			Component c = tabbedPane.getComponentAt(i);
			tabComponents = VUtils.add(tabComponents, c);
		}
		add(tabbedPane, BorderLayout.PAGE_END);
		tabbedPane.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent evt) {
				JTabbedPane pane = (JTabbedPane) evt.getSource();
				selectedTabIndex = pane.getSelectedIndex();
				selectedLevelIndex = selectedTabIndex - 1;
				if (selectedLevelIndex >= 0
						&& selectedLevelIndex < levels.size()) {
					Class level = levels.elementAt(selectedLevelIndex);
					arrTool.getAnalysis().setSelectedLevel(level, true);
					classLevelPane.setSelectedLevel();
					Attribute attribute = (Attribute) classLevelPane.comboBox
							.getSelectedItem();
					int index = classLevelPane.comboBox.getSelectedIndex();
				}
			}
		});
	}

	public static boolean withUserInteraction() {
		return TypeSystemJTree.withUserInteraction()
				|| TypeSystemLevelJTree.withUserInteraction();
	}

	public void setSelectedLevel(Class level) {
		if (getSelectedJTree() != null) {
			this.selectedLevelIndex = levels.indexOf(level);
			this.selectedTabIndex = this.selectedLevelIndex + 1;
			Component c = tabbedPane.getComponentAt(this.selectedTabIndex);
			tabbedPane.setSelectedComponent(c);
			classLevelPane.setSelectedLevel();
		}
	}

	public TypeSystemLevelJTree getSelectedAnnotationJTree() {
		if (this.selectedLevelIndex >= 0
				&& this.selectedLevelIndex < levels.size()) {
			return trees.elementAt(this.selectedLevelIndex);
		}
		return null;
	}

	public int getSelectedTabIndex() {
		return selectedTabIndex;
	}

	public int getSelectedLevelIndex() {
		return selectedLevelIndex;
	}

	public TypeSystemLevelJTree getSelectedJTree() {
		if (selectedLevelIndex >= 0 && selectedLevelIndex < trees.size()) {
			TypeSystemLevelJTree tree = trees.elementAt(selectedLevelIndex);
			return tree;
		}
		return null;
	}

}
