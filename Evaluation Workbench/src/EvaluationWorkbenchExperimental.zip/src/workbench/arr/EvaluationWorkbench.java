package workbench.arr;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Hashtable;
import java.util.Properties;
import java.util.Vector;

import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.KeyStroke;
import javax.swing.ScrollPaneConstants;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import annotation.DocumentAnnotation;
import annotation.SnippetAnnotation;
import typesystem.TypeSystem;
import onyx.utilities.VUtils;

public class EvaluationWorkbench extends JPanel implements ActionListener {

	public TypeSystem typeSystem = null;

	public AnnotationAnalysis analysis = null;

	public JTabbedPane tabbedPane = null;

	public DocumentPane documentPane = null;

	public DetailPane detailPane = null;

	public ClassificationStatisticsTabbedPane accuracyPane = null;

	public GraphPane graphPane = null;

	public JFrame frame = null;

	public GeneralStatistics statistics = null;
	static EvaluationWorkbench evaluationWorkbench = null;
	Hashtable<Object, GeneralStatistics> statisticsHash = new Hashtable();

	Annotator firstAnnotator = null;
	Annotator secondAnnotator = null;
	File sourceDirectory = null;
	String rootDirectoryFilename = null;
	File rootDirectory = null;

	String GrAFTypeSystemFilename = "TypeSystemSpecs";
	String LispSystemFilename = "TypeSystemSpecsLisp";

	// public Analysis jessAnalysis = null;

	private static String[][] menuInfo = { { null, "file", "File" },
			{ null, "annotate", "Annotate" } };

	private static Object[][] menuItemInfo = {
			{ "file", "storeOEM", "Store OEM" },
			{ "file", "storeVerifiedAnnotations", "Store Verified Annotations" },
			{ "file", "quit", "Quit" },
			{ "annotate", "verifyAnnotation", "Verify Annotation" },
			{ "annotate", "unverifyAnnotation", "Unverify Annotation" }, };

	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				UIManager.put("swing.boldMetal", Boolean.FALSE);
				createAndShowGUI();
			}
		});
	}

	static boolean gettingGeneralStatics = false;
	
	public void getGeneralStatistics(Object selectedItem) {
		// I am sometimes calling this twice in a row.  Why?
//		if (gettingGeneralStatics) {
//			gettingGeneralStatics = false;
//			return;
//		}
//		gettingGeneralStatics = true;
		Object key = selectedItem;
		if (key == null) {
			key = this.getAnalysis().getSelectedLevel();
		}
		GeneralStatistics gs = statisticsHash.get(key);
		
		// 3/28/2012:  TEMPORARY
//		gs = null;
		
		if (gs == null) {
			gs = GeneralStatistics.create(this, selectedItem);
			statisticsHash.put(key, gs);
		}
		this.statistics = gs;
		fireAllTableDataChanged();
	}
	
	public void clearGeneralStatisticsTable() {
		statisticsHash.clear();
	}

	private static void createAndShowGUI() {
		JFrame frame = new JFrame("ARRTool");
		evaluationWorkbench = new EvaluationWorkbench(frame);
		frame.setContentPane(evaluationWorkbench);
		frame.pack();
		frame.setVisible(true);
	}

	public EvaluationWorkbench(JFrame frame) {
		try {
			this.frame = frame;
			getProperties();
			String typeSystemFileName = this.rootDirectoryFilename
					+ File.separator + LispSystemFilename;
			this.typeSystem = TypeSystem.getTypeSystem(typeSystemFileName);
			this.analysis = new AnnotationAnalysis(this);
			initializeLayout();
			this.frame.setJMenuBar(createMenuBar(menuInfo, menuItemInfo, this,
					this));
			GeneralStatistics.create(this);
			accuracyPane.populate();
			detailPane.attributesPane.initializeColumns();
			fireAllTableDataChanged();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void fireAllTableDataChanged() {
		accuracyPane.populate();
		detailPane.attributesPane.model.fireTableDataChanged();
		detailPane.relationsPane.model.fireTableDataChanged();
		detailPane.reportListPane.model.fireTableDataChanged();
		documentPane.highlightSentences();
		setTitle();
	}

	void getProperties() throws Exception {
		Properties properties = new Properties();
		InputStream is = getClass().getResourceAsStream("/startup.properties");
		if (is == null) {
			is = getClass().getResourceAsStream("startup.properties");
		}
		if (is == null) {
			is = new FileInputStream("startup.properties");
		}
		properties.load(is);
		String name = properties.getProperty("firstAnnotator");
		this.firstAnnotator = new Annotator(analysis, name);
		name = properties.getProperty("secondAnnotator");
		this.secondAnnotator = new Annotator(analysis, name);
		String dir = properties.getProperty("output_directory");
		this.sourceDirectory = new File(dir);
		this.rootDirectoryFilename = properties
				.getProperty("utopaz_root_directory");
		this.rootDirectory = new File(this.rootDirectoryFilename);
	}

	public void actionPerformed(ActionEvent e) {
		String command = e.getActionCommand();
		if ("quit".equals(command)) {
			System.exit(0);
		} else if ("storeOEM".equals(command)) {
			evaluationWorkbench.getAnalysis().writeOEMResults();
		} else if ("verifyAnnotation".equals(command)) {
			evaluationWorkbench.getAnalysis().verifySelectedAnnotation();
		} else if ("unverifyAnnotation".equals(command)) {
			evaluationWorkbench.getAnalysis().unverifySelectedAnnotation();
		} else if ("storeVerifiedAnnotations".equals(command)) {
			evaluationWorkbench.getAnalysis().writeGrAFAnnotations();
		}
	}

	void setLevel() {
		Vector v = this.getAnalysis().getAnnotationLevels();
		if (v != null) {
			Object[] levels = (Object[]) VUtils.vectorToArray(v);
			Class level = (Class) JOptionPane.showInputDialog(new JFrame(),
					"Select Level", "Level:", JOptionPane.PLAIN_MESSAGE, null,
					levels, levels[0]);
			if (level != null) {
				this.getAnalysis().setSelectedLevel(level, true);
				detailPane.fireAllTableDataChanged();
			}
		}
	}

	String getUserSelection() {
		int start = DocumentPane.documentTextPane.getSelectionStart();
		int end = DocumentPane.documentTextPane.getSelectionEnd();
		if (start < end) {
			return DocumentPane.documentTextPane.getText()
					.substring(start, end);
		}
		return null;
	}

	void selectFile() {
		Object[] names = VUtils.vectorToArray(ARRDocument.getDocumentNames());
		String s = (String) JOptionPane.showInputDialog(frame,
				"Annotation File", "Annotation File",
				JOptionPane.PLAIN_MESSAGE, null, names, names[0]);

		if (s != null) {
			documentPane.setSelectedDocument(s);
			setTitle();
		}
	}

	void setTitle() {
		String filename = "*";
		String annotator = "*";
		String level = "*";
		if (analysis.selectedAnnotationEvent != null) {
			annotator = analysis.getSelectedAnnotator().getName();
		}
		if (analysis.selectedDocument != null) {
			filename = analysis.getSelectedDocument().getName();
		}
		if (this.getAnalysis().getSelectedLevel() != null) {
			if (DocumentAnnotation.class.equals(this.getAnalysis()
					.getSelectedLevel())) {
				level = "DOCUMENT";
			} else if (SnippetAnnotation.class.equals(this.getAnalysis()
					.getSelectedLevel())) {
				level = "SNIPPET";
			}
		}
		String title = "Level=" + level + " File=" + filename + " Annotator="
				+ annotator;
		this.frame.setTitle(title);
	}
	
	void initializeLayout() {
		documentPane = new DocumentPane(this);
		graphPane = new GraphPane(this);
		accuracyPane = new ClassificationStatisticsTabbedPane(this);
		accuracyPane.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent evt) {
				ClassificationStatisticsTabbedPane pane = (ClassificationStatisticsTabbedPane) evt
						.getSource();
				int index = pane.getSelectedIndex();
				accuracyPane.setSelectedPane(index);
			}
		});
		JScrollPane graphScrollPane = new JScrollPane(graphPane,
				ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED,
				ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		detailPane = new DetailPane(this);
		JScrollPane detailScrollPane = new JScrollPane(detailPane,
				ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED,
				ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);

		GridBagConstraints c = new GridBagConstraints();
		this.setLayout(new GridBagLayout());

		c.fill = GridBagConstraints.BOTH;
		c.gridwidth = 1;
		c.gridheight = 6;
		c.gridx = 0;
		c.gridy = 0;
		c.weightx = 0.35;
		c.weighty = 0.5;
		this.add(documentPane, c);

		c.fill = GridBagConstraints.BOTH;
		c.gridwidth = 1;
		c.gridheight = 5;
		c.gridx = 1;
		c.gridy = 0;
		c.weightx = 0.6;
		c.weighty = 0.6;
		this.add(accuracyPane, c);

		c.fill = GridBagConstraints.BOTH;
		c.gridwidth = 1;
		c.gridheight = 5;
		c.gridx = 2;
		c.gridy = 0;
		c.weightx = 0.4;
		c.weighty = 0.6;
		this.add(graphScrollPane, c);

		c.fill = GridBagConstraints.BOTH;
		c.gridwidth = 2;
		c.gridheight = 1;
		c.gridx = 1;
		c.gridy = 5;
		c.weightx = 0.5;
		c.weighty = 0.4;
		this.add(detailScrollPane, c);
	}
	
	public static JMenuBar createMenuBar(String[][] menuinfo,
			Object[][] menuiteminfo, ActionListener listener,
			JComponent component) {
		Hashtable menuhash = new Hashtable();
		JMenuBar menubar = new JMenuBar();

		for (int i = 0; i < menuinfo.length; i++) {
			String[] array = (String[]) menuinfo[i];
			String parentname = array[0];
			String menuname = array[1];
			String displayname = array[2];
			JMenu menu = new JMenu(displayname);
			menuhash.put(menuname, menu);
			if (parentname != null) {
				JMenu parent = (JMenu) menuhash.get(parentname);
				parent.add(menu);
			} else {
				menubar.add(menu);
			}
		}

		for (int i = 0; i < menuiteminfo.length; i++) {
			Object[] array = (Object[]) menuiteminfo[i];
			String menuname = (String) array[0];
			String actionname = (String) array[1];
			String displayname = (String) array[2];
			int key = -1;
			int modifier = -1;
			if (array.length > 3) {
				Integer k = (Integer) array[3];
				key = k.intValue();
				Integer m = (Integer) array[4];
				modifier = m.intValue();
			}
			JMenu menu = (JMenu) menuhash.get(menuname);
			JMenuItem menuitem = new JMenuItem(displayname);
			menuitem.setActionCommand(actionname);
			menuitem.addActionListener(listener);
			if (modifier > 0) {
				KeyStroke ks = KeyStroke.getKeyStroke(key, modifier);
				menuitem.setAccelerator(ks);
			}
			menu.add(menuitem);
		}
		return menubar;
	}

	public AnnotationAnalysis getAnalysis() {
		return analysis;
	}

	public void setAnalysis(AnnotationAnalysis analysis) {
		this.analysis = analysis;
	}

	public DocumentPane getDocumentPane() {
		return documentPane;
	}

	public DetailPane getDetailPane() {
		return detailPane;
	}

	public ClassificationStatisticsTabbedPane getAccuracyPane() {
		return accuracyPane;
	}

	public JFrame getFrame() {
		return frame;
	}

	public void setFrame(JFrame frame) {
		this.frame = frame;
	}

	public Annotator getFirstAnnotator() {
		return firstAnnotator;
	}

	public void setFirstAnnotator(Annotator firstAnnotator) {
		this.firstAnnotator = firstAnnotator;
	}

	public Annotator getSecondAnnotator() {
		return secondAnnotator;
	}

	public void setSecondAnnotator(Annotator secondAnnotator) {
		this.secondAnnotator = secondAnnotator;
	}

	public File getSourceDirectory() {
		return sourceDirectory;
	}

	public void setSourceDirectory(File sourceDirectory) {
		this.sourceDirectory = sourceDirectory;
	}

	public boolean doCompareConglomerate() {
		return GeneralStatistics.doCompareConglomerate(this);
	}

	public TypeSystem getTypeSystem() {
		return typeSystem;
	}

	public void setTypeSystem(TypeSystem typeSystem) {
		this.typeSystem = typeSystem;
	}

}
