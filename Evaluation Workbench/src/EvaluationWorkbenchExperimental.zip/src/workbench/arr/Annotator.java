package workbench.arr;

import java.util.HashMap;
import java.util.Map;
import annotation.AnnotationCollection;
import annotation.EVAnnotation;

public class Annotator {
	AnnotationAnalysis analysis = null;
	String name = null;
	boolean isGold = false;
	boolean isPrimary = false;
	AnnotationCollection annotationCollection = null;
	EVAnnotation documentAnnotation = null;
	EVAnnotation componentAnnotation = null;
	static Map<String, Annotator> annotatorMap = new HashMap<String, Annotator>();
	
	public Annotator(AnnotationAnalysis analysis, String name) {
		this.analysis = analysis;
		this.name = name;
		annotatorMap.put(name, this);
	}
	
	public String toString() {
		return "[" + this.name + "]";
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public boolean isPrimary() {
		return isPrimary;
	}

	public void setPrimary(boolean isPrimary) {
		this.isPrimary = isPrimary;
	}

	public void setGold(boolean isGold) {
		this.isGold = isGold;
	}

	public AnnotationCollection getAnnotationCollection() {
		return annotationCollection;
	}

	public void setAnnotationCollection(AnnotationCollection annotationCollection) {
		this.annotationCollection = annotationCollection;
	}

	public EVAnnotation getDocumentAnnotation() {
		return documentAnnotation;
	}

	public void setDocumentAnnotation(EVAnnotation documentAnnotation) {
		this.documentAnnotation = documentAnnotation;
	}

	public EVAnnotation getComponentAnnotation() {
		return componentAnnotation;
	}

	public void setComponentAnnotation(EVAnnotation componentAnnotation) {
		this.componentAnnotation = componentAnnotation;
	}
	
	
	
}
