package workbench.arr;

import java.awt.Point;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;
import java.util.Hashtable;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTree;
import javax.swing.event.TreeModelEvent;
import javax.swing.event.TreeModelListener;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreePath;
import javax.swing.tree.TreeSelectionModel;

import typesystem.Annotation;
import typesystem.Attribute;

import annotation.AnnotationCollection;

public class TypeSystemLevelJTree extends JPanel implements
		TreeSelectionListener, MouseMotionListener {
	EvaluationWorkbench arrTool = null;
	Annotation annotationType = null;
	TSLJTree tree = null;
	DefaultTreeModel treeModel = null;
	AnnotationCollection annotationCollection = null;
	TypeSystemLevelMutableTreeNode rootNode = null;
	TypeSystemLevelMutableTreeNode selectedNode = null;
	Hashtable userObjectNodeHash = new Hashtable();
	TreePath lastTreePath = null;
	static boolean isMouseDown = false;

	public TypeSystemLevelJTree(EvaluationWorkbench tool,
			Annotation annotationType) {
		this.arrTool = tool;
		this.annotationType = annotationType;
		rootNode = new TypeSystemLevelMutableTreeNode(this, annotationType);
		treeModel = new TypeSystemLevelDefaultTreeModel(rootNode);
		if (annotationType.getAttributes() != null) {
			for (Attribute attribute : annotationType.getAttributes()) {
				if (attribute.getValues() != null) {
					TypeSystemLevelMutableTreeNode anode = new TypeSystemLevelMutableTreeNode(
							this, attribute);
					treeModel.insertNodeInto(anode, rootNode,
							rootNode.getChildCount());
					for (Object value : attribute.getValues()) {
						String vname = value.toString();
						AVPair pair = new AVPair(attribute, vname);
						TypeSystemLevelMutableTreeNode vnode = new TypeSystemLevelMutableTreeNode(
								this, pair);
						treeModel.insertNodeInto(vnode, anode,
								anode.getChildCount());
					}
				}
			}
		}
		treeModel.addTreeModelListener(new TypeSystemLevelTreeModelListener());
		tree = new TSLJTree(treeModel);
		tree.setEditable(true);
		tree.getSelectionModel().setSelectionMode(
				TreeSelectionModel.SINGLE_TREE_SELECTION);
		tree.setShowsRootHandles(true);
		tree.addTreeSelectionListener(this);
		tree.addMouseMotionListener(this);
		for (int i = 0; i < tree.getRowCount(); i++) {
			tree.expandRow(i);
		}
		JScrollPane scrollPane = new JScrollPane(tree);
		add(scrollPane);
	}

	public void valueChanged(TreeSelectionEvent e) {
		TypeSystemLevelMutableTreeNode node = (TypeSystemLevelMutableTreeNode) tree
				.getLastSelectedPathComponent();
		if (node != null) {
			this.selectedNode = node;
			Object o = node.getUserObject();
			processValueSelection(o);
		}
	}

	void processValueSelection(Object o) {
		if (o != null) {
			if (o instanceof AVPair) {
				AVPair pair = (AVPair) o;
				arrTool.getGeneralStatistics(pair.getKey());
			} else if (o instanceof Annotation) {
				Annotation annotationType = (Annotation) o;
				arrTool.getAnalysis().setSelectedLevel(
						annotationType.getAnnotationClass(), true);
				arrTool.getGeneralStatistics(null);
			} else if (o instanceof Attribute) {
				Attribute attribute = (Attribute) o;
				arrTool.getGeneralStatistics(attribute);
			}
		}
	}

	class TypeSystemLevelMutableTreeNode extends DefaultMutableTreeNode {
		public static final long serialVersionUID = 0;

		TypeSystemLevelMutableTreeNode(TypeSystemLevelJTree tree, Object o) {
			super(o);
			tree.userObjectNodeHash.put(o, this);

		}

		public String toString() {
			Object o = this.getUserObject();
			if (o instanceof Annotation) {
				Annotation annotation = (Annotation) o;
				return annotation.getName();
			}
			if (o instanceof Attribute) {
				Attribute attribute = (Attribute) o;
				return attribute.getName();
			}
			if (o instanceof AVPair) {
				AVPair pair = (AVPair) o;
				return pair.getValue();
			}
			return o.toString();
		}
	}

	class TypeSystemLevelDefaultTreeModel extends DefaultTreeModel {
		public static final long serialVersionUID = 0;

		TypeSystemLevelDefaultTreeModel(TypeSystemLevelMutableTreeNode node) {
			super(node);
		}

		public void valueForPathChanged(TreePath path, Object newValue) {
			TypeSystemLevelMutableTreeNode pathnode = (TypeSystemLevelMutableTreeNode) path
					.getLastPathComponent();
		}
	}

	class TSLJTree extends JTree {
		public static final long serialVersionUID = 0;

		TSLJTree(DefaultTreeModel model) {
			super(model);
		}

		public String getToolTipText(MouseEvent e) {
			Point p = e.getPoint();
			TreePath path = tree.getClosestPathForLocation(p.x, p.y);
			TypeSystemLevelMutableTreeNode node = (TypeSystemLevelMutableTreeNode) path
					.getLastPathComponent();
			return "";
		}

	}

	class TypeSystemLevelTreeModelListener implements TreeModelListener {

		public void treeNodesChanged(TreeModelEvent e) {
			TypeSystemLevelMutableTreeNode node = (TypeSystemLevelMutableTreeNode) (e
					.getTreePath().getLastPathComponent());
			try {
				int index = e.getChildIndices()[0];
				node = (TypeSystemLevelMutableTreeNode) (node.getChildAt(index));
			} catch (NullPointerException exc) {
			}
		}

		public void treeNodesInserted(TreeModelEvent e) {
		}

		public void treeNodesRemoved(TreeModelEvent e) {
		}

		public void treeStructureChanged(TreeModelEvent e) {
		}
	}

	public TSLJTree getTree() {
		return tree;
	}

	public void setTree(TSLJTree tree) {
		this.tree = tree;
	}

	public String toString() {
		return "<AnnotationJTree:  Level=" + this.annotationType + ">";
	}

	public void mouseClicked(MouseEvent e) {
	}

	public void mouseExited(MouseEvent e) {
	}

	public void mouseEntered(MouseEvent e) {
	}

	public void mousePressed(MouseEvent e) {
	}

	public void mouseReleased(MouseEvent e) {
	}

	public void mouseMoved(MouseEvent e) {
		if (e.isControlDown()) {
			isMouseDown = true;
			TreePath path = tree.getPathForLocation(e.getX(), e.getY());
			if (path != null && path != this.lastTreePath) {
				this.lastTreePath = path;
				if (tree.isPathSelected(path)) {
					tree.removeSelectionPath(path);
				} else {
					Object lastElement = path.getLastPathComponent();
					this.selectedNode = (TypeSystemLevelMutableTreeNode) lastElement;
					tree.addSelectionPath(path);
					processValueSelection(this.selectedNode.getUserObject());
				}
			}
			isMouseDown = false;
		}
	}

	public void mouseDragged(MouseEvent e) {
	}

	Hashtable<String, AVPair> AVPairHash = new Hashtable();

	class AVPair {
		Attribute attribute = null;
		String value = null;

		AVPair(Attribute attribute, String value) {
			this.attribute = attribute;
			this.value = value;
		}

		public String toString() {
			return this.attribute.getName() + "=" + this.value;
		}

		String getAttributeName() {
			return this.attribute.getName();
		}

		String getValue() {
			return this.value;
		}

		String getKey() {
			String str = this.attribute.getName() + "=" + this.value;
			return str;
			// Before 1/11/2012
//			return str.toLowerCase();
		}
	}

	public static boolean withUserInteraction() {
		return isMouseDown;
	}
	

}
