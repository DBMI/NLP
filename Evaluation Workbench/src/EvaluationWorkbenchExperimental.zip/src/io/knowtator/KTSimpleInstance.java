package io.knowtator;

import java.util.Vector;

import onyx.utilities.JDomUtils;
import onyx.utilities.VUtils;

import org.jdom.Element;

public class KTSimpleInstance {
	Element node = null;
	KnowtatorIO kt = null;
	String name = null;
	String id = null;
	String level = "snippet";
	static int currentID = 0;

	public KTSimpleInstance(KnowtatorIO kt, String name, Element node) {
		this.kt = kt;
		this.name = name;
		this.node = node;
		this.id = "SimpleInstance_" + currentID++;
		kt.addHashItem(name, this);
		kt.simpleInstances = VUtils.add(kt.simpleInstances, this);
	}

	static void extractSimpleInstances(KnowtatorIO kt) {
		try {
			Vector<Element> nodes = JDomUtils.getElementsByName(kt.getRoot(),
					"simple_instance");
			if (nodes != null) {
				for (Element node : nodes) {
					Element cnode = JDomUtils.getElementByName(node, "name");
					String name = cnode.getText();
					cnode = JDomUtils.getElementByName(node, "type");
					String type = cnode.getText();
					if ("knowtator class mention".equals(type)) {
						new KTClassMention(kt, name, node);
					} else if ("knowtator complex slot mention".equals(type)) {
						new KTComplexSlotMention(kt, name, node);
					} else if ("knowtator annotation".equals(type)) {
						new KTAnnotation(kt, name, node);
					} else if ("knowtator human annotator".equals(type)) {
						new KTAnnotator(kt, name, node);
					} else if ("knowtator string slot mention".equals(type)) {
						new KTStringSlotMention(kt, name, node);
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void resolveReferences() {
	}

	public String toString() {
		return "<SI:" + this.name + ">";
	}
	
	public String getID() {
		return this.id;
	}
	
	public String getLevel() {
		return this.level;
	}

}
