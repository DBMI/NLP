package io.knowtator;

import java.util.Vector;

import org.jdom.Element;

import onyx.utilities.JDomUtils;
import onyx.utilities.StrUtils;
import onyx.utilities.VUtils;
import typesystem.TypeSystem;

import annotation.AnnotationCollection;
import annotation.Classification;
import annotation.SnippetAnnotation;
import annotation.Span;

public class KTAnnotation extends KTSimpleInstance {

	String textSource = null;
	String creationDate = null;
	int textStart = 0;
	int textEnd = 0;
	String knowtatorAnnotatedMentionID = null; // ??
	KTClassMention knowtatorAnnotatedMention = null;
	String annotatorID = null;
	String annotator = null;
	String text = null;
	SnippetAnnotation snippet = null;

	public KTAnnotation(KnowtatorIO kt, String name, Element node) {
		super(kt, name, node);
		extractInformation();
		Vector<String> key = new Vector(0);
		key.add(this.textSource);
		key.add(this.annotatorID);
		kt.annotations = VUtils.add(kt.annotations, this);
		VUtils.pushHashVector(kt.annotationHash, key, this);
	}

	public void extractInformation() {
		Vector<Element> OSVNodes = JDomUtils.getElementsByName(this.node,
				"own_slot_value");
		if (OSVNodes != null) {
			for (Element osvnode : OSVNodes) {
				Element cnode = JDomUtils.getElementByName(osvnode,
						"slot_reference");
				String rvalue = cnode.getValue();
				cnode = JDomUtils.getElementByName(osvnode, "value");
				String vvalue = cnode.getValue();
				if ("knowtator_annotation_text_source".equals(rvalue)) {
					this.textSource = vvalue;
				} else if ("knowtator_annotation_creation_date".equals(rvalue)) {
					this.creationDate = vvalue;
				} else if ("knowtator_annotation_span".equals(rvalue)) {
					Vector<String> v = StrUtils.stringList(vvalue, '|');
					this.textStart = Integer.parseInt(v.elementAt(0));
					this.textEnd = Integer.parseInt(v.elementAt(1));
				} else if ("knowtator_annotated_mention".equals(rvalue)) {
					this.knowtatorAnnotatedMentionID = vvalue;
				} else if ("knowtator_annotation_annotator".equals(rvalue)) {
					this.annotatorID = vvalue;
				} else if ("knowtator_annotation_text".equals(rvalue)) {
					this.text = vvalue;
				}
			}
		}
	}

	public void resolveReferences() {
		if (this.knowtatorAnnotatedMentionID != null) {
			this.knowtatorAnnotatedMention = (KTClassMention) this.kt
					.getHashItem(knowtatorAnnotatedMentionID);
		}
	}

	public String toString() {
		return "<KTAnnotation:" + this.name + ">";
	}

	SnippetAnnotation extractSnippet(TypeSystem ts, AnnotationCollection ac) {
		if (this.text != null && this.textStart > 0) {
			this.snippet = new SnippetAnnotation();
			snippet.setAnnotationCollection(ac);
			String annotationName = "Annotation:" + this.getID();
			snippet.setId(annotationName);
			Span span = new Span(snippet, this.textStart, this.textEnd);
			span.setAnnotationCollection(ac);
			String spanID = "SPAN:" + this.getID();
			span.setId(spanID);
			snippet.addSpan(span);
			String cstr = this.knowtatorAnnotatedMention.knowtatorMentionClass.name;
			String value = null;
			String cname = cstr + ":CLASS";
			typesystem.Classification classification = ts
					.getUimaClassification(cname);
			if (this.knowtatorAnnotatedMention.knowtatorSlotMentions != null) {
				for (KTSlotMention sm : this.knowtatorAnnotatedMention.knowtatorSlotMentions) {
					if (sm instanceof KTStringSlotMention) {
						KTStringSlotMention ssm = (KTStringSlotMention) sm;
						if (ssm.stringValue != null
								&& ssm.mentionSlotID.toLowerCase().indexOf(
										"concept") >= 0) {
							value = ssm.stringValue;
							break;
						}
					}
				}
			}
			if (value == null) {
				if (this.text != null) {
					value = this.text;
				} else {
					value = this.knowtatorAnnotatedMention.knowtatorMentionClass.name;
				}
			}
			Classification c = new Classification(null, classification, cstr,
					value, "CoreConcept");
//			c.setProperty("SnippetCUI", c.getValue());
			snippet.setClassification(c);
			if (this.text != null) {
				snippet.setAttribute(
						this.knowtatorAnnotatedMention.knowtatorMentionClassID,
						this.text);
			}
		}
		return snippet;
	}

	void addCorefAttributes() {
		if (this.knowtatorAnnotatedMention != null
				&& this.knowtatorAnnotatedMention.knowtatorSlotMentions != null
				&& this.snippet != null) {
			for (KTSlotMention sm : this.knowtatorAnnotatedMention.knowtatorSlotMentions) {
				if (sm.knowtatorMentionSlotValues != null) {
					for (KTClassMention kmsv : sm.knowtatorMentionSlotValues) {
						KTAnnotation kta = kmsv.knowtatorMentionAnnotation;
						String attribute = kta.knowtatorAnnotatedMention.knowtatorMentionClassID;
						String value = kta.text;
						if (attribute != null && value != null) {
							this.snippet.setAttribute(attribute, value);
						}
					}
				}
			}
		}
	}

	public String getAnnotator() {
		return annotator;
	}

	public String getTextSource() {
		return textSource;
	}

}
