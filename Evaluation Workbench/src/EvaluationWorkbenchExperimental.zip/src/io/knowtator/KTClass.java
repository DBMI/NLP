package io.knowtator;

import java.util.Vector;

import onyx.utilities.JDomUtils;
import onyx.utilities.VUtils;

import org.jdom.Element;

public class KTClass {

	String name = null;
	KTClass superclass = null;
	String superclassName = null;
	Vector<KTSlot> slots = null;
	Vector<String> slotNames = null;
	KnowtatorIO kt = null;

	static void extractClasses(KnowtatorIO kt) {
		try {
			Vector<Element> nodes = JDomUtils.getElementsByName(kt.getRoot(),
					"class");
			if (nodes != null) {
				for (Element node : nodes) {
					KTClass kc = new KTClass();
					kc.kt = kt;
					Element cnode = JDomUtils.getElementByName(node, "name");
					kc.setName(cnode.getText());
					cnode = JDomUtils.getElementByName(node, "superclass");
					if (cnode != null) {
						kc.setSuperclassName(cnode.getText());
					}
					Vector<Element> snodes = JDomUtils.getElementsByName(node,
							"template_slot");
					if (snodes != null) {
						for (Element snode : snodes) {
							String sname = snode.getText();
							kc.addSlotNames(sname);
						}
					}
					if (!kc.isSystemClass()) {
						kt.classes = VUtils.add(kt.classes, kc);
					}
					if (kc.getName() != null) {
						kt.addHashItem(kc.getName(), kc);
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void resolveReferences() {
		if (this.slotNames != null) {
			for (String name : this.slotNames) {
				KTSlot slot = (KTSlot) this.kt.getHashItem(name);
				if (slot != null) {
					this.slots = VUtils.add(this.slots, slot);
				}
			}
		}
	}

	public boolean isSystemClass() {
		if (this.name.charAt(0) == ':' || this.name.indexOf("knowtator") >= 0
				|| this.name.indexOf("file") >= 0
				|| this.name.indexOf("source") >= 0
				|| this.name.indexOf("coref") >= 0) {
			return true;
		}
		return false;
	}

	String toLisp(int depth) {
		StringBuffer sb = new StringBuffer();
		addSpaces(sb, depth);
		sb.append("(\"" + this.name + "\"");
		addSpaces(sb, depth + 2);
		sb.append("(level \"snippet\")");
		addSpaces(sb, depth + 2);
		sb.append("(workbench \"SnippetAnnotation\")\n");
		addSpaces(sb, depth + 2);
		sb.append("(classifications\n");
		addSpaces(sb, depth + 4);
		sb.append("(Class:" + this.name + "\"");
		sb.append(")");
		return sb.toString();
	}

	void addSpaces(StringBuffer sb, int num) {
		sb.append("\n");
		for (int i = 0; i < num; i++) {
			sb.append(' ');
		}
	}

	public String toString() {
		return "<C:" + this.getName() + ">";
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name.toLowerCase();
	}

	public KTClass getSuperclass() {
		return superclass;
	}

	public String getSuperclassName() {
		return superclassName;
	}

	public void setSuperclassName(String superclassName) {
		this.superclassName = superclassName;
	}

	public Vector<KTSlot> getSlots() {
		return slots;
	}

	public void setSlots(Vector<KTSlot> slots) {
		this.slots = slots;
	}

	public Vector<String> getSlotNames() {
		return slotNames;
	}

	public void addSlotNames(String sname) {
		this.slotNames = VUtils.add(this.slotNames, sname);
	}

}
