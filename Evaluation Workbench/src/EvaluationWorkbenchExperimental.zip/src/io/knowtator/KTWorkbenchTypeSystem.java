package io.knowtator;

import java.io.File;

public class KTWorkbenchTypeSystem {
	
	public KTWorkbenchTypeSystem() {
		String fname = "/Users/leechristensen/Desktop/KnowtatorTest/KT.xml";
		File file = new File(fname);
		if (file.exists()) {
			KnowtatorIO KT = new KnowtatorIO(file);
			if (KT.classes != null) {
				for (KTClass ktclass : KT.classes) {
					
				}
			}
		}
		
	}

}
