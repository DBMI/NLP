package io.knowtator;

import io.GrAF;

import java.io.File;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

import org.jdom.Element;
import org.jdom.input.SAXBuilder;

import annotation.AnnotationCollection;
import annotation.SnippetAnnotation;
import onyx.utilities.FUtils;
import onyx.utilities.VUtils;
import typesystem.Annotation;
import typesystem.Attribute;
import typesystem.Classification;
import typesystem.TypeSystem;

public class KnowtatorIO {

	File file = null;
	Element root = null;
	Vector<KTSimpleInstance> simpleInstances = null;
	Vector<KTAnnotation> annotations = null;
	Hashtable<Vector<String>, Vector<KTAnnotation>> annotationHash = new Hashtable();
	Vector<KTClass> classes = null;
	Vector<KTSlot> slots = null;
	Hashtable<String, Object> IDHash = new Hashtable();
	Vector<String> textSources = null;
	Vector<String> annotators = null;
	String outputDirectory = "/Users/leechristensen/Desktop/LeeNLPFolder/Results KT";

	public static void main(String[] args) {
		String fname = "/Users/leechristensen/Desktop/KnowtatorTest/KT.xml";
		File ktfile = new File(fname);
		if (ktfile.exists()) {
			KnowtatorIO kt = new KnowtatorIO(ktfile);
			TypeSystem ts = kt.extractTypeSystem();
			Annotation root = (Annotation) ts.getRoot();
			String typexml = "'" + root.toLisp(2);
			String filename = kt.outputDirectory + File.separatorChar
					+ "TypeSystemSpecsLisp";
			FUtils.writeFile(filename, typexml);
			kt.writeGrAF(ts, 0);
			kt.writeGrAF(ts, 1);
		}
	}

	public KnowtatorIO(File file) {
		this.file = file;
		readAnnotations();
	}

	void readAnnotations() {
		try {
			org.jdom.Document jdoc = new SAXBuilder().build(this.file
					.getAbsoluteFile().toURI().toString());
			this.root = jdoc.getRootElement();
			KTClass.extractClasses(this);
			KTSlot.extractSlots(this);
			KTSimpleInstance.extractSimpleInstances(this);
			if (this.classes != null) {
				for (KTClass ktclass : this.classes) {
					ktclass.resolveReferences();
				}
			}
			if (this.slots != null) {
				for (KTSlot slot : this.slots) {
					slot.resolveReferences();
				}
			}
			if (this.simpleInstances != null) {
				for (KTSimpleInstance si : this.simpleInstances) {
					si.resolveReferences();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	void resolveSlots() {
		for (KTClass ktclass : this.classes) {
			if (ktclass.getSuperclassName() != null) {
				Object o = this.IDHash.get(ktclass.getSuperclassName());
				if (o != null && o instanceof KTClass) {
					ktclass.superclass = (KTClass) o;
				}
			}
			if (ktclass.getSlotNames() != null) {
				for (String sname : ktclass.getSlotNames()) {
					KTSlot slot = (KTSlot) this.IDHash.get(sname);
					if (slot != null) {
						ktclass.slots = VUtils.add(ktclass.slots, slot);
					}
				}
			}
		}
	}

	public void writeGrAF(TypeSystem ts, int id) {
		this.outputDirectory = "/Users/leechristensen/Desktop/LeeNLPFolder/Results KT";
		for (Enumeration<Vector<String>> e = this.annotationHash.keys(); e
				.hasMoreElements();) {
			Vector<String> key = e.nextElement();
			String sourceText = key.firstElement();
			String annotatorID = key.lastElement();
			KTAnnotator annotator = (KTAnnotator) this.getHashItem(annotatorID);
			Vector<KTAnnotation> annotations = this.annotationHash.get(key);
			String xml = getGRafXML(ts, sourceText, annotator, annotations, id);
			String filename = getOutputFileName(sourceText, annotator, id);
			FUtils.writeFile(filename, xml);
		}
	}

	String getOutputFileName(String sourceText, KTAnnotator annotator, int id) {
		int index = sourceText.indexOf('.');
		String shortname = new String(sourceText);
		if (index >= 0) {
			shortname = sourceText.substring(0, index);
		}
		String filename = this.outputDirectory + File.separatorChar + shortname
				+ "_" + annotator.getFullName() + "_" + id + ".xml";
		return filename;
	}

	String getGRafXML(TypeSystem ts, String textSource, KTAnnotator annotator,
			Vector<KTAnnotation> annotations, int id) {
		AnnotationCollection ac = new AnnotationCollection();
		StringBuffer sb = new StringBuffer();
		sb.append("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>\n"
				+ "<graph source_file=\""
				+ textSource
				+ "\" "
				+ "annotator_name=\""
				+ annotator.getFullName()
				+ "_"
				+ id
				+ "\">\n");
		Vector<SnippetAnnotation> snippets = null;
		for (KTAnnotation annotation : annotations) {
			SnippetAnnotation snippet = annotation.extractSnippet(ts, ac);
			if (snippet != null) {
				snippets = VUtils.add(snippets, snippet);
			}
		}
		for (KTAnnotation annotation : annotations) {
			annotation.addCorefAttributes();
		}
		for (SnippetAnnotation snippet : snippets) {
			String xml = GrAF.toXML(snippet);
			sb.append(xml);
		}
		sb.append("</graph>\n");
		return sb.toString();
	}

	public TypeSystem extractTypeSystem() {
		TypeSystem ts = null;
		try {
			ts = TypeSystem.getTypeSystem(null);
			Class c = Class.forName("annotation.DocumentAnnotation");
			Annotation root = new Annotation(ts, "KnowtatorRoot", c, null);
			TypeSystem.addTypeObjectByID(root);
			root.setLevel("document");
			if (this.classes != null) {
				for (KTClass ktclass : this.classes) {
					String cname = ktclass.getName() + ":Annotation";
					Class cc = Class.forName("annotation.SnippetAnnotation");
					Annotation child = new Annotation(ts, cname, cc, null);
					child.setLevel("snippet");
					root.addComponent(child);
					child.setParent(root);
					TypeSystem.addTypeObjectByID(child);
					String clname = ktclass.getName() + ":CLASS";
					String clid = ktclass.getName() + ":ID";
					Classification ccl = new Classification(ts, clname, null);
					child.setClassification(ccl);
					TypeSystem.addTypeObjectByID(ccl);
					Attribute cla = new Attribute(ts, clid, ktclass.getName(),
							null);
					ccl.addAttribute(cla);
					if (ktclass.getSlots() != null) {
						for (KTSlot slot : ktclass.getSlots()) {
							String sname = slot.getName();
							String sid = sname + ":ID";
							cla = new Attribute(ts, sid, sname, null);
							ccl.addAttribute(cla);
							TypeSystem.addTypeObjectByID(ccl);
						}
					}
				}
			}
		} catch (Exception e) {
			System.out.println(e);
		}
		return ts;
	}

	void addHashItem(String name, Object item) {
		this.IDHash.put(name, item);
	}

	Object getHashItem(String name) {
		if (name != null) {
			return this.IDHash.get(name);
		}
		return null;
	}

	public Vector<KTAnnotation> getAnnotations(String source, String annotator) {
		Vector<String> key = new Vector(0);
		key.add(source);
		key.add(annotator);
		return annotationHash.get(key);
	}

	public Element getRoot() {
		return root;
	}

	public Vector<KTSimpleInstance> getSimpleInstances() {
		return simpleInstances;
	}

	public Vector<KTClass> getClasses() {
		return classes;
	}

	public Vector<String> getTextSources() {
		return textSources;
	}

	public Vector<String> getAnnotators() {
		return annotators;
	}

}
