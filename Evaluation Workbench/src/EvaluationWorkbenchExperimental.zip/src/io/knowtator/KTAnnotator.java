package io.knowtator;

import java.util.Vector;
import onyx.utilities.JDomUtils;

import org.jdom.Element;

public class KTAnnotator extends KTSimpleInstance {
	
	String firstName = null;
	String lastName = null;
	String fullName = null;
	String affiliation = null;
	String annotatorID = null;
	
	public KTAnnotator(KnowtatorIO kt, String name, Element node) {
		super(kt, name, node);
		extractInformation();
	}
	
	public void extractInformation() {
		Vector<Element> OSVNodes = JDomUtils.getElementsByName(this.node,
				"own_slot_value");
		if (OSVNodes != null) {
			for (Element osvnode : OSVNodes) {
				Element cnode = JDomUtils.getElementByName(osvnode,
						"slot_reference");
				String rvalue = cnode.getValue();
				cnode = JDomUtils.getElementByName(osvnode, "value");
				String vvalue = cnode.getValue();
				if ("knowtator_annotation_annotator_lastname".equals(rvalue)) {
					this.lastName = vvalue;
				} else if ("knowtator_annotation_annotator_firstname".equals(rvalue)) {
					this.firstName = vvalue;
				} else if ("knowtator_annotation_annotator_affiliation".equals(rvalue)) {
					this.affiliation = vvalue;
				} else if ("knowtator_annotator_id".equals(rvalue)) {
					this.annotatorID = vvalue;
				}
			}
			this.fullName = this.firstName + "_" + this.lastName;
		}
	}
	
	public String getFullName() {
		return this.fullName;
	}


}
