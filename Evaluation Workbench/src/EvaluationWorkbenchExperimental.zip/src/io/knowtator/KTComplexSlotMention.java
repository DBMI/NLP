package io.knowtator;

import java.util.Vector;
import onyx.utilities.JDomUtils;
import onyx.utilities.VUtils;

import org.jdom.Element;

public class KTComplexSlotMention extends KTSlotMention {

	public KTComplexSlotMention(KnowtatorIO kt, String name, Element node) {
		super(kt, name, node);
		extractInformation();
	}

	public void extractInformation() {
		Vector<Element> OSVNodes = JDomUtils.getElementsByName(this.node,
				"own_slot_value");
		if (OSVNodes != null) {
			for (Element osvnode : OSVNodes) {
				Element rnode = JDomUtils.getElementByName(osvnode,
						"slot_reference");
				String rvalue = rnode.getValue();
				Vector<Element> vnodes = JDomUtils.getElementsByName(osvnode,
						"value");
				String vvalue = vnodes.firstElement().getValue();
				if ("knowtator_mentioned_in".equals(rvalue)) {
					this.knowtatorMentionedInID = vvalue;
				} else if ("knowtator_mention_slot".equals(rvalue)) {
					this.mentionSlotID = vvalue;
				} else if ("knowtator_mention_slot_value".equals(rvalue)) {
					for (Element vnode : vnodes) {
						this.knowtatorMentionSlotIDs = VUtils.add(
								this.knowtatorMentionSlotIDs, vnode.getValue());
					}
				}
			}
		}
	}

	public void resolveReferences() {
		if (this.knowtatorMentionedInID != null) {
			this.knowtatorMentionedInInstance = (KTSimpleInstance) this.kt
					.getHashItem(this.knowtatorMentionedInID);
		}
		if (this.knowtatorMentionSlotIDs != null) {
			for (String sid : this.knowtatorMentionSlotIDs) {
				KTClassMention cm = (KTClassMention) this.kt.getHashItem(sid);
				if (cm != null) {
					this.knowtatorMentionSlotValues = VUtils.add(
							this.knowtatorMentionSlotValues, cm);
				}
			}
		}
		if (this.mentionSlotID != null) {
			this.slotMention = (KTSlot) this.kt.getHashItem(this.mentionSlotID);
		}
	}

	public String toString() {
		return "<KTComplexSlotMention:" + this.name + ">";
	}

}
