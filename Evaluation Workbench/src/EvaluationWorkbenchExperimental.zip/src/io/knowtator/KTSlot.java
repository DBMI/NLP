package io.knowtator;

import java.util.Vector;

import onyx.utilities.JDomUtils;
import onyx.utilities.VUtils;

import org.jdom.Element;

public class KTSlot {

	String name = null;
	KTClass sclass = null;
	String sclassName = null;
	KnowtatorIO kt = null;

	public static void extractSlots(KnowtatorIO kt) {
		Vector<KTSlot> slots = null;
		try {
			Vector<Element> nodes = JDomUtils.getElementsByName(kt.getRoot(),
					"slot");
			if (nodes != null) {
				for (Element node : nodes) {
					KTSlot slot = new KTSlot();
					slot.kt = kt;
					kt.slots = VUtils.add(slots, slot);
					Element cnode = JDomUtils.getElementByName(node, "name");
					String sname = cnode.getText().trim();
					slot.setName(sname);
					Vector<Element> snodes = JDomUtils.getElementsByName(node,
							"own_slot_value");
					if (snodes != null) {
						for (Element snode : snodes) {
							Vector<Element> vnodes = JDomUtils
									.getElementsByName(snode, "value");
							if (vnodes != null) {
								for (Element vnode : vnodes) {
									String vtype = vnode.getAttribute(
											"value_type").getValue();
									String value = vnode.getText().trim();
									if ("class".equals(vtype)) {
										slot.setSclassName(value);
									}
								}
							}
						}
					}
					if (slot.getName() != null) {
						kt.addHashItem(slot.getName(), slot);
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void resolveReferences() {
		String cname = this.sclassName;
		if (cname != null) {
			if (cname.charAt(0) == ':') {
				cname = cname.substring(1);
			}
			this.sclass = (KTClass) this.kt.getHashItem(cname);
		}
	}
	
	public String toString() {
		return "<KTSlot:" + this.getName() + ">";
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public KTClass getSclass() {
		return sclass;
	}

	public void setSclass(KTClass sclass) {
		this.sclass = sclass;
	}

	public String getSclassName() {
		return sclassName;
	}

	public void setSclassName(String sclassName) {
		this.sclassName = sclassName;
	}

}
