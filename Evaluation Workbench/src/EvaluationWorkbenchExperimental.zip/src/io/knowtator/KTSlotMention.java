package io.knowtator;

import java.util.Vector;

import org.jdom.Element;

public class KTSlotMention extends KTSimpleInstance {
	
	String knowtatorMentionedInID = null;
	KTSimpleInstance knowtatorMentionedInInstance = null;
	KTSlot slotMention = null;
	Vector<String> knowtatorMentionSlotIDs = null;
	Vector<KTClassMention> knowtatorMentionSlotValues = null;
	String mentionSlotID = null;
	
	public KTSlotMention(KnowtatorIO kt, String name, Element node) {
		super(kt, name, node);
	}

}
