package io.knowtator;

import java.util.Vector;

import onyx.utilities.JDomUtils;
import onyx.utilities.VUtils;

import org.jdom.Element;

public class KTClassMention extends KTSimpleInstance {

	Vector<String> knowtatorSlotMentionIDs = null;
	Vector<KTSlotMention> knowtatorSlotMentions = null;
	String knowtatorMentionClassID = null;
	KTClass knowtatorMentionClass = null;
	String knowtatorMentionAnnotationID = null;
	KTAnnotation knowtatorMentionAnnotation = null;

	public KTClassMention(KnowtatorIO kt, String name, Element node) {
		super(kt, name, node);
		extractInformation();
	}

	public void extractInformation() {
		Vector<Element> OSVNodes = JDomUtils.getElementsByName(this.node,
				"own_slot_value");
		if (OSVNodes != null) {
			for (Element osvnode : OSVNodes) {
				Element rnode = JDomUtils.getElementByName(osvnode,
						"slot_reference");
				String rvalue = rnode.getValue();
				Vector<Element> children = JDomUtils.getElementsByName(osvnode,
						"value");
				String firstValue = children.firstElement().getValue();
				if ("knowtator_slot_mention".equals(rvalue)) {
					for (Element child : children) {
						String sid = child.getValue();
						this.knowtatorSlotMentionIDs = VUtils.add(
								this.knowtatorSlotMentionIDs, sid);
					}
				} else if ("knowtator_mention_class".equals(rvalue)) {
					this.knowtatorMentionClassID = firstValue;
				} else if ("knowtator_mention_annotation".equals(rvalue)) {
					this.knowtatorMentionAnnotationID = firstValue; // ?? What
																	// is //
					// this??
				}
			}
		}
	}

	public void resolveReferences() {
		if (this.knowtatorSlotMentionIDs != null) {
			for (String sid : this.knowtatorSlotMentionIDs) {
				KTSlotMention sm = (KTSlotMention) this.kt.getHashItem(sid);
				if (sm != null) {
					this.knowtatorSlotMentions = VUtils.add(
							this.knowtatorSlotMentions, sm);
				}
			}
		}
		if (this.knowtatorMentionClassID != null) {
			this.knowtatorMentionClass = (KTClass) this.kt
					.getHashItem(this.knowtatorMentionClassID);
		}
		if (this.knowtatorMentionAnnotationID != null) {
			this.knowtatorMentionAnnotation = (KTAnnotation) this.kt
					.getHashItem(this.knowtatorMentionAnnotationID);
		}
	}

	public String toString() {
		return "<KTClassMention:" + this.name + ">";
	}

}
