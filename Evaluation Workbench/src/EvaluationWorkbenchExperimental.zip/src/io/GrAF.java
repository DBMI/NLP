package io;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Collections;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Vector;
import org.apache.uima.cas.FSIndex;
import org.apache.uima.cas.FSIterator;
import org.apache.uima.cas.Feature;
import org.apache.uima.cas.Type;
import org.apache.uima.cas.impl.XmiCasDeserializer;
import org.apache.uima.cas.impl.XmiCasSerializer;
import org.apache.uima.cas.text.AnnotationFS;
import org.apache.uima.jcas.JCas;
import org.apache.uima.jcas.cas.FSArray;
import org.apache.uima.util.XMLSerializer;
import org.jdom.Element;
import org.jdom.input.SAXBuilder;

import edu.mayo.bmi.uima.core.type.NamedEntity;
import edu.mayo.bmi.uima.core.type.OntologyConcept;
import edu.mayo.bmi.uima.drugner.type.DrugMentionAnnotation;

import typesystem.Annotation;
import typesystem.Attribute;
import typesystem.TypeSystem;
import onyx.utilities.FUtils;
import onyx.utilities.VUtils;
import annotation.AnnotationCollection;
import annotation.Classification;
import annotation.EVAnnotation;
import annotation.Span;

public class GrAF {

	Hashtable typeAnnotationHash = new Hashtable();
	Hashtable<String, Vector<EVAnnotation>> classificationAnnotationHash = new Hashtable();
	AnnotationCollection annotationCollection = new AnnotationCollection();
	JCas jcas = null;
	TypeSystem typeSystem = null;
	Vector<EVAnnotation> allAnnotations = null;
	String annotator = null;
	String fileName = null;
	String outputDirectory = null;

	public GrAF(JCas jcas, TypeSystem typeSystem, String filename,
			String annotator, String outputDirectory) {
		this.jcas = jcas;
		this.typeSystem = typeSystem;
		this.fileName = filename;
		this.annotator = annotator;
		this.outputDirectory = outputDirectory;
	}

	static boolean createdTypeModel = false;

	public static void writeUIMAGrAF(JCas jcas, String filename,
			String annotator, String outputDirectory) {
		GrAF graf = new GrAF(jcas, TypeSystem.getTypeSystem(), filename,
				annotator, outputDirectory);
		graf.gatherJCasAnnotations();
		graf.attachJCasAnnotations();
		writeGrAFAnnotations(graf.allAnnotations, graf.outputDirectory,
				graf.fileName, graf.annotator);
	}

	static void readXmi(JCas jcas, String filename) {
		File file = new File(filename);
		try {
			FileInputStream inputStream = new FileInputStream(file);
			try {
				XmiCasDeserializer.deserialize(inputStream, jcas.getCas(),
						false);
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				inputStream.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	static void writeXmi(JCas jcas, String filename) {
		FileOutputStream out = null;
		try {
			try {
				File file = new File(filename);
				out = new FileOutputStream(file);
				XmiCasSerializer ser = new XmiCasSerializer(
						jcas.getTypeSystem());
				XMLSerializer xmlSer = new XMLSerializer(out, false);
				ser.serialize(jcas.getCas(), xmlSer.getContentHandler());
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				if (out != null) {
					out.close();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void gatherJCasAnnotations() {
		Annotation annotationType = null;
		Attribute attribute = null;
		typesystem.Classification classification = null;
		FSIndex fsIndex = jcas.getAnnotationIndex();
		for (FSIterator rsit = fsIndex.iterator(); rsit.hasNext();) {
			AnnotationFS afs = (AnnotationFS) rsit.next();
			Type type = afs.getType();
			annotationType = typeSystem.getUimaAnnotation(type.getName());
			if (annotationType != null) {
				EVAnnotation ev = annotationType
						.createEVAnnotation(annotationType);
				ev.setAnnotationCollection(this.annotationCollection);
				ev.setId(null);
				int start = afs.getBegin();
				int end = afs.getEnd();
				ev.setUIMAStart(start);
				ev.setUIMAEnd(end);
				boolean isTerminal = (end > 0 && (!annotationType
						.hasComponents() || annotationType.getComponents()
						.size() == 0));
				if (isTerminal) {
					ev.addSpan(afs.getBegin(), afs.getEnd());
				}
				for (ListIterator<Feature> li = type.getFeatures()
						.listIterator(); li.hasNext();) {
					Feature feature = li.next();
					String fname = feature.getShortName();
					classification = typeSystem.getUimaClassification(
							type.getName(), feature.getName());
					attribute = typeSystem.getUimaAttribute(feature.getName());
					String uimaType = null;
					if (attribute != null)
						uimaType = attribute.getUimaType();
					if (classification != null) {
						String str = populateAttribute(ev, uimaType, afs,
								feature, start, end);
						if (str != null
								&& attribute != null
								&& classification
										.containsClassificationAttribute(fname)) {

							Classification c = ev.getClassification();
							if (c != null) {
								c.addValue(attribute.getName(), str);
							} else {
								c = new Classification(
										this.annotationCollection,
										classification, attribute.getName(),
										str, null);
								ev.setClassification(c);
							}
							VUtils.pushHashVector(
									this.classificationAnnotationHash, str, ev);
						}
					} else if (attribute != null) {
						String str = afs.getStringValue(feature);
						str = populateAttribute(ev, uimaType, afs, feature,
								start, end);
						ev.setAttribute(attribute.getId(), str);
					}
				}
				if (ev.getClassification() != null
						&& ev.getAttributes() != null && ev.isValid()) {
					this.allAnnotations = VUtils.add(this.allAnnotations, ev);
				}
			}
		}
	}


	/**
	 * Populates workbench attributes with UIMA attributes, taking into account
	 * the UIMA type and special attribute handling.
	 * 
	 * @param evDrugElement
	 * @param uimaTypeToken
	 * @param annotationfs
	 * @param feature
	 * @param start
	 * @param end
	 * @return
	 */
	String populateAttribute(EVAnnotation evDrugElement, String uimaTypeToken,
			AnnotationFS annotationfs, Feature feature, int start, int end) {

		if (uimaTypeToken != null && uimaTypeToken.equalsIgnoreCase("FSArray")) {
			Iterator tokenItr = jcas.getAnnotationIndex(NamedEntity.type)
					.iterator();
			while (tokenItr.hasNext()) {
				NamedEntity ne = (NamedEntity) tokenItr.next();
				FSArray array = null;
				if (ne.getBegin() == start && ne.getEnd() == end)
					if (feature.getShortName().contains("ontologyConceptArr")) {
						array = ne.getOntologyConceptArr();
						if (array != null) {
							for (int i = 0; i < array.size(); i++) {
								OntologyConcept oc = (OntologyConcept) array
										.get(i);
								String scheme = oc.getCodingScheme();
								if (scheme.compareTo("RXNORM") == 0) {
									return oc.getCode();
								}
							}
						}
					} else if (feature.getShortName()
							.contains("drugMentionArr") && ne.getTypeID() == 1) {
						if (ne.getDrugMentionArr() != null) {
							array = ne.getDrugMentionArr();
							DrugMentionAnnotation dma = (DrugMentionAnnotation) array
									.get(0);// Only return the first entry which
											// is usually the largest span
							// Only populate the ones setup in the
							// typesystemspecs
							Attribute annotRouteAttr = typeSystem
									.getUimaAttribute(feature.getDomain()
											.getShortName(), "route");
							Attribute annotFormAttr = typeSystem
									.getUimaAttribute(feature.getDomain()
											.getShortName(), "form");
							Attribute annotStrengthAttr = typeSystem
									.getUimaAttribute(feature.getDomain()
											.getShortName(), "strength");
							Attribute annotDosageAttr = typeSystem
									.getUimaAttribute(feature.getDomain()
											.getShortName(), "dosage");
							Attribute annotFrequencyAttr = typeSystem
									.getUimaAttribute(feature.getDomain()
											.getShortName(), "frequency");
							Attribute annotFrequencyUnitAttr = typeSystem
									.getUimaAttribute(feature.getDomain()
											.getShortName(), "frequencyUnit");
							Attribute annotDurationAttr = typeSystem
									.getUimaAttribute(feature.getDomain()
											.getShortName(), "duration");
							if (annotRouteAttr != null
									&& dma.getRoute() != null) {
								int begining = dma.getRouteBegin();
								int ending = dma.getRouteEnd();
								evDrugElement.setUIMAStart(begining);
								evDrugElement.setUIMAEnd(ending);
								evDrugElement.addSpan(dma.getRouteBegin(),
										dma.getRouteEnd());
								evDrugElement.setAttribute("route",
										dma.getRoute());
							}
							if (annotFormAttr != null && dma.getForm() != null) {
								int begining = dma.getFormBegin();
								int ending = dma.getFormEnd();
								evDrugElement.setUIMAStart(begining);
								evDrugElement.setUIMAEnd(ending);
								evDrugElement.addSpan(dma.getFormBegin(),
										dma.getFormEnd());
								evDrugElement.setAttribute("form",
										dma.getForm());
							}
							if (annotStrengthAttr != null
									&& dma.getStrength() != null) {
								int begining = dma.getStrengthBegin();
								int ending = dma.getStrengthEnd();
								evDrugElement.setUIMAStart(begining);
								evDrugElement.setUIMAEnd(ending);
								evDrugElement.addSpan(dma.getStrengthBegin(),
										dma.getStrengthEnd());
								evDrugElement.setAttribute("strength",
										dma.getStrength());
							}
							if (annotDosageAttr != null
									&& dma.getDosage() != null) {
								int begining = dma.getDosageBegin();
								int ending = dma.getDosageEnd();
								evDrugElement.setUIMAStart(begining);
								evDrugElement.setUIMAEnd(ending);
								evDrugElement.addSpan(dma.getDosageBegin(),
										dma.getDosageEnd());
								evDrugElement.setAttribute("dosage",
										dma.getDosage());
							}
							if (annotFrequencyAttr != null
									&& dma.getFrequency() != null) {
								int begining = dma.getFrequencyBegin();
								int ending = dma.getFrequencyEnd();
								evDrugElement.setUIMAStart(begining);
								evDrugElement.setUIMAEnd(ending);
								evDrugElement.addSpan(dma.getFrequencyBegin(),
										dma.getFrequencyEnd());
								evDrugElement.setAttribute("frequency",
										dma.getFrequency());
							}
							if (annotFrequencyUnitAttr != null
									&& dma.getFrequencyUnit() != null) {
								int begining = dma.getFuBegin();
								int ending = dma.getFuEnd();
								evDrugElement.setUIMAStart(begining);
								evDrugElement.setUIMAEnd(ending);
								evDrugElement.addSpan(dma.getFuBegin(),
										dma.getFuEnd());
								evDrugElement.setAttribute("frequencyUnit",
										dma.getFrequencyUnit());
							}
							if (annotDurationAttr != null
									&& dma.getDuration() != null) {
								int begining = dma.getDurationBegin();
								int ending = dma.getDurationEnd();
								evDrugElement.setUIMAStart(begining);
								evDrugElement.setUIMAEnd(ending);
								evDrugElement.addSpan(dma.getDurationBegin(),
										dma.getDurationEnd());
								evDrugElement.setAttribute("duration",
										dma.getDuration());
							}
							return dma.getCoveredText();
						} else {
							return ne.getCoveredText(); // SPM 12/19/2011 This
														// shouldn't be
														// happening, but
														// prevents an error in
														// the event that the
														// entries missing for
														// some reason.
						}
					}
			}

		} else if (uimaTypeToken != null
				&& uimaTypeToken.equalsIgnoreCase("Integer")) {
			return new Integer(annotationfs.getIntValue(feature)).toString();
		} else {
			return annotationfs.getStringValue(feature);
		}

		return null;
	}

	void attachJCasAnnotations() {
		if (this.allAnnotations != null) {
			for (int i = 0; i < allAnnotations.size() - 1; i++) {
				EVAnnotation a1 = allAnnotations.elementAt(i);
				for (int j = i + 1; j < allAnnotations.size(); j++) {
					EVAnnotation a2 = allAnnotations.elementAt(j);
					EVAnnotation child = null;
					EVAnnotation parent = null;
					if (a2.getType().isChildOf(a1.getType())) {
						child = a2;
						parent = a1;
					} else if (a1.getType().isChildOf(a2.getType())) {
						child = a1;
						parent = a2;
					}
					if (parent != null && parent.getUIMAEnd() > 0
							&& parent.getUIMAStart() <= child.getUIMAStart()
							&& parent.getUIMAEnd() >= child.getUIMAEnd()) {
						String cclass = child.getClassification().getValue();
						Vector<EVAnnotation> v = this.classificationAnnotationHash
								.get(cclass);
						if (v.contains(parent)) {
							child.setParentAnnotation(parent);
							parent.setRelation("component", child);
							parent.addComponent(child);
						}
					}
				}
			}
		}
	}

	public static void writeGrAFAnnotations(Vector<EVAnnotation> annotations,
			String dirname, String filename, String annotator) {
		StringBuffer sb = new StringBuffer();
		sb.append("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>\n"
				+ "<graph source_file=\""
				+ filename
				+ "\" "
				+ "annotator_name=\"" + annotator + "\">\n");
		if (annotations != null) {
			Collections.sort(annotations,
					new EVAnnotation.ClassificationSorter());
			for (EVAnnotation annotation : annotations) {
				String str = GrAF.toXML(annotation);
				sb.append(str);
			}
		}
		sb.append("</graph>\n");
		String shortName = filename;
		int index = shortName.lastIndexOf(".");
		if (index > 0) {
			shortName = shortName.substring(0, index);
		}
		String fname = dirname + File.separatorChar + shortName + "_"
				+ annotator + "_.xml";
		FUtils.writeFile(fname, sb.toString());
	}

	public static void readXML(AnnotationCollection ac) {
		try {
			Hashtable<String, Span> hash = new Hashtable();
			org.jdom.Document jdoc = new SAXBuilder()
					.build(ac.getXmlFileName());
			Element root = jdoc.getRootElement();
			String fname = root.getAttributeValue("source_file");
			String aname = root.getAttributeValue("annotator_name");
			ac.setDocument(ac.getAnalysis().getDocument(fname));
			ac.setAnnotator(ac.getAnalysis().getAnnotator(aname));
			List l = root.getChildren("node");
			for (ListIterator i = l.listIterator(); i.hasNext();) {
				Element node = (Element) i.next();
				readNode(ac, node);
			}
			l = root.getChildren("sink");
			for (ListIterator i = l.listIterator(); i.hasNext();) {
				Element sink = (Element) i.next();
				String id = sink.getAttribute("id").getValue();
				int start = sink.getAttribute("start").getIntValue();
				int end = sink.getAttribute("end").getIntValue();
				Span span = new Span(start, end);
				hash.put(id, span);
			}
			l = root.getChildren("edge");
			for (ListIterator i = l.listIterator(); i.hasNext();) {
				Element edge = (Element) i.next();
				String fromID = edge.getAttributeValue("from");
				String toID = edge.getAttributeValue("to");
				String relationName = edge.getAttributeValue("relation_name");
				EVAnnotation fromAnnotation = ac.getAnnotation(fromID);
				if (fromAnnotation != null) {
					EVAnnotation toAnnotation = ac.getAnnotation(toID);
					Classification toClassification = ac
							.getClassification(toID);
					Span span = hash.get(toID);
					if (relationName != null && toAnnotation != null) {
						fromAnnotation.setRelation(relationName, toAnnotation);
					} else if (toAnnotation != null) {
						fromAnnotation.setRelation("component", toAnnotation);
						fromAnnotation.addComponent(toAnnotation);
						toAnnotation.setRelation("parent", fromAnnotation);
					} else if (toClassification != null) {
						fromAnnotation.setClassification(toClassification);
					} else if (span != null) {
						fromAnnotation.addSpan(span);
					}
				}
			}
			ac.storeAnalysisIndices();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void readNode(AnnotationCollection ac, Element node) {
		String type = node.getAttributeValue("type");
		if ("annotation".equals(type)) {
			EVAnnotation annotation = readAnnotation(ac, node);
			ac.addAnnotation(annotation.getId(), annotation);
		} else if ("classification".equals(type)) {
			Classification c = readClassification(ac, node);
			ac.addClassification(c.getId(), c);
		}
	}

	static EVAnnotation readAnnotation(AnnotationCollection ac, Element node) {
		EVAnnotation annotation = null;
		String id = node.getAttributeValue("id");
		String[] sa = id.split("_");
		int nid = Integer.parseInt(sa[1]);
		List cl = node.getChildren("f");
		String level = null;
		String matchedID = null;
		boolean verified = false;
		boolean verifiedTrue = false;
		Vector<String> attributes = new Vector(0);
		Vector<String> values = new Vector(0);
		for (ListIterator ci = cl.listIterator(); ci.hasNext();) {
			Element feature = (Element) ci.next();
			String name = feature.getAttributeValue("name");
			String value = feature.getAttributeValue("value");
			if ("level".equals(name)) {
				level = value;
			} else if ("verified".equals(name)) {
				verified = true;
				verifiedTrue = Boolean.parseBoolean(value);
			} else if ("matchid".equals(name)) {
				matchedID = value;
			} else {
				attributes.add(name);
				values.add(value);
			}
		}
		annotation = ac.createAnnotation(level);
		annotation.setId(id);
		annotation.setNumericID(nid);
		if (verified) {
			annotation.setVerified(true);
			annotation.setVerifiedTrue(verifiedTrue);
		}
		annotation.setVerified(verified);
		annotation.setMatchedAnnotationID(matchedID);
		for (int i = 0; i < attributes.size(); i++) {
			String attribute = attributes.elementAt(i);
			String value = values.elementAt(i);
			annotation.setAttribute(attribute, value);
		}
		return annotation;
	}

	static Classification readClassification(AnnotationCollection ac,
			Element node) {
		String id = node.getAttributeValue("id");
		String[] sa = id.split("_");
		int nid = Integer.parseInt(sa[1]);
		String annotationType = node.getAttributeValue("annotationtype");
		List cl = node.getChildren("f");
		Vector<String> attributes = new Vector(0);
		Vector<String> values = new Vector(0);
		String cname = null;
		String cvalue = null;
		for (ListIterator ci = cl.listIterator(); ci.hasNext();) {
			Element feature = (Element) ci.next();
			cname = feature.getAttributeValue("name");
			cvalue = feature.getAttributeValue("value");
			attributes.add(cname);
			values.add(cvalue);
		}
		Classification c = new Classification(ac, id, nid, annotationType,
				cname, cvalue);
		for (int i = 0; i < attributes.size(); i++) {
			String attribute = attributes.elementAt(i);
			String value = values.elementAt(i);
			c.setProperty(attribute, value);
		}
		return c;
	}

	public static String toXML(EVAnnotation annotation) {
		StringBuffer sb = new StringBuffer();
		sb.append("<node id=\"" + annotation.getId()
				+ "\" type=\"annotation\">\n");
		sb.append("<f name=\"level\" value=\"" + annotation.getLevel()
				+ "\"/>\n");
		if (annotation.getMatchedAnnotation() != null) {
			sb.append("<f name=\"matchid\" value=\""
					+ annotation.getMatchedAnnotation().getId() + "\"/>\n");
		}
		if (annotation.isVerified()) {
			sb.append("<f name=\"verified\" value=\""
					+ annotation.isVerifiedTrue() + "\"/>\n");
		}
		if (annotation.getAttributeValues() != null) {
			for (Enumeration<String> e = annotation.getAttributeMap().keys(); e
					.hasMoreElements();) {
				String attribute = e.nextElement();
				for (Object value : annotation.getAttributeMap().get(attribute)) {
					sb.append("<f name=\"" + attribute + "\" value=\"" + value
							+ "\"/>\n");
				}
			}
		}
		sb.append("</node>\n");
		Classification c = annotation.getClassification();
		if (c != null) {
			sb.append("<node id=\"" + c.getId()
					+ "\" type=\"classification\" annotationtype=\""
					+ c.getAnnotationType() + "\">\n");
			for (String name : c.getPropertyNames()) {
				String value = c.getStringProperty(name);
				sb.append("<f name=\"" + name + "\" value=\"" + value
						+ "\" />\n");
			}
			sb.append("</node>\n");
			sb.append("<edge from=\"" + annotation.getId() + "\" to=\""
					+ c.getId() + "\"/>\n");
		}
		if (annotation.getRelations() != null) {
			for (Enumeration<String> e = annotation.getRelationMap().keys(); e
					.hasMoreElements();) {
				String rname = e.nextElement();
				Vector<EVAnnotation> relata = annotation.getRelationMap().get(
						rname);
				for (EVAnnotation relatum : relata) {
					sb.append("<edge from=\"" + annotation.getId() + "\" to=\""
							+ relatum.getId() + "\"/>\n");
				}
			}
		}
		if (annotation.getSpans() != null) {
			for (Span span : annotation.getSpans()) {
				sb.append("<sink id=\"" + span.getId() + "\" start=\""
						+ span.getTextStart() + "\" end=\"" + span.getTextEnd()
						+ "\"/>\n");
				sb.append("<edge from=\"" + annotation.getId() + "\" to=\""
						+ span.getId() + "\"/>\n");
			}
		}
		return sb.toString();
	}

}
