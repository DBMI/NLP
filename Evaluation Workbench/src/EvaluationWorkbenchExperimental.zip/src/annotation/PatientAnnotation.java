package annotation;

import onyx.document.document.Document;

public class PatientAnnotation extends EVAnnotation {
	
	public PatientAnnotation(Document document) {
		super(document);
	}

}
