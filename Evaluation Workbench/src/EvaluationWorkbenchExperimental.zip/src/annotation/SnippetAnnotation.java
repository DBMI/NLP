package annotation;

import onyx.document.document.Document;

public class SnippetAnnotation extends EVAnnotation {
	
	public SnippetAnnotation() {
		super();
	}
	
	public SnippetAnnotation(Document document) {
		super(document);
	}
	
	public String getLevelPrefix() {
		return "S";
	}
	
}
