package annotation;

import io.GrAF;
import java.util.Collections;
import java.util.Comparator;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Vector;
import workbench.arr.AnnotationAnalysis;
import workbench.arr.Annotator;

import onyx.document.document.Document;
import onyx.utilities.SeqUtils;
import onyx.utilities.VUtils;

public class AnnotationCollection {
	AnnotationAnalysis analysis = null;
	Document document = null;
	String xmlFileName = null;
	Annotator annotator = null;
	public Vector<EVAnnotation> annotations = null;
	public Vector<Classification> classifications = null;
	HashMap<String, EVAnnotation> annotationIDMap = new HashMap<String, EVAnnotation>();
	HashMap<String, Classification> classificationIDMap = new HashMap<String, Classification>();
	Hashtable<Class, Vector<Integer>> annotationCountMap = new Hashtable();
	Hashtable<Document, Vector<EVAnnotation>> documentAnnotationMap = new Hashtable();
	Hashtable<Class, Vector<EVAnnotation>> classAnnotationMap = new Hashtable();
	Hashtable<Vector, Vector<EVAnnotation>> classificationAnnotationMap = new Hashtable();
	int numberOfSpans = 0;
	boolean isPrimary = false;

	public AnnotationCollection() {
	}

	public AnnotationCollection(Document document) {
		this.setDocument(document);
	}

	public AnnotationCollection(AnnotationAnalysis analysis, String xmlFileName) {
		this.analysis = analysis;
		this.xmlFileName = xmlFileName;
		GrAF.readXML(this);
		wrapup();
	}

	public void writeGrAFAnnotations() {
		if (this.annotations != null) {
			GrAF.writeGrAFAnnotations(this.annotations, this.analysis.getDirectory(),
					this.document.getName(),
					this.annotator.getName());
		}
	}

	public Vector<EVAnnotation> getAnnotationsByClass(Class c) {
		Vector<EVAnnotation> annotations = classAnnotationMap.get(c);
		if (annotations != null) {
			annotations = new Vector(annotations);
		}
		return annotations;
	}

	public Vector<Class> getAnnotationClasses() {
		return new Vector(classAnnotationMap.keySet());
	}

	public int getNumberOfAnnotationsByClass(Class c) {
		Vector<EVAnnotation> annotations = classAnnotationMap.get(c);
		if (annotations != null) {
			return annotations.size();
		}
		return 0;
	}

	public void storeAnalysisIndices() {
		if (this.annotations != null) {
			for (EVAnnotation annotation : this.annotations) {
				this.addAnnotationClassification(annotation);
				if (annotation.getAttributes() != null) {
					for (String attribute : annotation.getAttributes()) {
						Object value = annotation.getAttribute(attribute);
						this.getAnalysis().addClassAttribute(
								annotation.getClass(), attribute, value);
					}
				}
				if (annotation.getRelations() != null) {
					for (String relation : annotation.getRelations()) {
						this.getAnalysis().addClassRelation(
								annotation.getClass(), relation);
					}
				}
			}
		}
	}

	public void addAnnotation(String id, EVAnnotation annotation) {
		this.annotations = VUtils.add(this.annotations, annotation);
		annotationIDMap.put(id, annotation);
	}

	public EVAnnotation getAnnotation(String id) {
		return annotationIDMap.get(id);
	}

	public void addClassification(String id, Classification classification) {
		this.classifications = VUtils.add(this.classifications, classification);
		classificationIDMap.put(id, classification);
	}

	public Classification getClassification(String id) {
		return classificationIDMap.get(id);
	}

	public EVAnnotation createAnnotation(String level) {
		EVAnnotation annotation = null;
		if (annotation == null) {
			if ("CorpusAnnotation".equals(level)) {
				annotation = new CorpusAnnotation(this.getDocument());
			} else if ("DocumentAnnotation".equals(level)) {
				annotation = new DocumentAnnotation(this.getDocument());
			} else if ("GroupAnnotation".equals(level)) {
				annotation = new GroupAnnotation(this.getDocument());
			} else if ("UtteranceAnnotation".equals(level)) {
				annotation = new UtteranceAnnotation(this.getDocument());
			} else if ("SnippetAnnotation".equals(level)) {
				annotation = new SnippetAnnotation(this.getDocument());
			} else if ("TokenAnnotation".equals(level)) {
				annotation = new TokenAnnotation(this.getDocument());
			} else if ("WordAnnotation".equals(level)) {
				annotation = new WordAnnotation(this.getDocument());
			}
		}
		if (annotation != null) {
			annotation.setAnnotationCollection(this);
		}
		return annotation;
	}

	// Add keys for all classification names
	public void addAnnotationClassification(EVAnnotation annotation) {
		Classification c = annotation.getClassification();
		if (c != null) {
			Vector<Vector<String>> keys = c.getClassificationAllValueKeys();
			if (keys != null) {
				for (Vector<String> key : keys) {
					VUtils.pushHashVector(this.classificationAnnotationMap, key,
							annotation);
					VUtils.pushIfNotHashVector(this.getAnalysis()
							.getAllClassificationAnnotationMap(), key, annotation);
					VUtils.pushIfNotHashVector(this.getAnalysis()
							.getAllAnnotationTypeClassificationMap(), annotation
							.getClass(), annotation.getClassification());
				}
			}
		}
	}
	
	// Before 3/7/2012
//	public void addAnnotationClassification(EVAnnotation annotation) {
//		Vector key = annotation.getClassificationKey();
//		if (key != null) {
//			VUtils.pushHashVector(this.classificationAnnotationMap, key,
//					annotation);
//			VUtils.pushIfNotHashVector(this.getAnalysis()
//					.getAllClassificationAnnotationMap(), key, annotation);
//			VUtils.pushIfNotHashVector(this.getAnalysis()
//					.getAllAnnotationTypeClassificationMap(), annotation
//					.getClass(), annotation.getClassification());
//		}
//	}

	public String getDocumentState(AnnotationCollection ac, Class c, Classification classification) {
		EVAnnotation annotation = getFirstAnnotation(c, classification);
		if (annotation != null) {
			return annotation.getState();
		}
		return "missing";
	}

	public EVAnnotation getFirstAnnotation(Class c,
			Classification classification) {
		Vector key = classification.getClassDisplayValueClassificationKey();
		// Before 3/8/2012
//		Vector key = EVAnnotation.getClassificationKey(c, classification);
		if (key != null) {
			Vector<EVAnnotation> annotations = this.classificationAnnotationMap
					.get(key);
			if (annotations != null) {
				return annotations.firstElement();
			}
		}
		return null;
	}

//	public Vector<EVAnnotation> getAnnotations(Class c,
//			Classification classification) {
//		Vector key = classification.getClassDisplayValueClassificationKey(c);
//		// Before 3/8/2012
////		Vector key = EVAnnotation.getClassificationKey(c, classification);
//		if (key != null) {
//			return this.classificationAnnotationMap.get(key);
//		}
//		return null;
//	}

	public static Vector<Vector<EVAnnotation>> getMatchingAnnotations(Class c,
			Classification classification, AnnotationCollection ac1,
			AnnotationCollection ac2) {
		Vector<EVAnnotation> annotations1 = null;
		Vector<EVAnnotation> annotations2 = null;
		Vector<Vector<EVAnnotation>> matching = null;
		Vector<EVAnnotation> matchedSeconds = null;
		if (classification != null) {
			Vector key = classification.getClassDisplayValueClassificationKey();
			// Before 3/8/2012
//			Vector key = EVAnnotation.getClassificationKey(c, classification);
			if (key != null) {
				annotations1 = ac1.classificationAnnotationMap.get(key);
				annotations2 = ac2.classificationAnnotationMap.get(key);
			}
		} else {
			annotations1 = ac1.classAnnotationMap.get(c);
			annotations2 = ac2.classAnnotationMap.get(c);
		}
		if (annotations1 != null) {
			for (EVAnnotation annotation1 : annotations1) {
				EVAnnotation matchedSecond = null;
				int maxOverlap = -1;
				if (annotations2 != null) {
					for (EVAnnotation annotation2 : annotations2) {
						int overlap = SeqUtils.amountOverlap(
								annotation1.getStart(), annotation1.getEnd(),
								annotation2.getStart(), annotation2.getEnd());
						Classification c1 = annotation1.getClassification();
						Classification c2 = annotation2.getClassification();
						if (c1 != null && c2 != null && c1.equals(c2)
								&& overlap > 0 && maxOverlap < overlap) {
							maxOverlap = overlap;
							matchedSecond = annotation2;
						} else if (matchedSecond != null) {
							break;
						}
					}
				}
				Vector<EVAnnotation> v = new Vector(0);
				v.add(annotation1);
				matching = VUtils.add(matching, v);
				if (matchedSecond == null) {
					v.add(null);
				} else {
					v.add(matchedSecond);
					matchedSeconds = VUtils.add(matchedSeconds, matchedSecond);
				}
			}
		}
		if (annotations2 != null
				&& (matchedSeconds == null || matchedSeconds.size() < annotations2
						.size())) {
			for (EVAnnotation annotation2 : annotations2) {
				if (matchedSeconds == null
						|| !matchedSeconds.contains(annotation2)) {
					Vector<EVAnnotation> v = new Vector(0);
					v.add(null);
					v.add(annotation2);
					matching = VUtils.add(matching, v);
				}
			}
		}
		return matching;
	}

	public Document getDocument() {
		return document;
	}

	public void setDocument(Document document) {
		this.document = document;
	}

	public Vector<EVAnnotation> getAnnotations() {
		return annotations;
	}

	public void setAnnotations(Vector<EVAnnotation> annotations) {
		this.annotations = annotations;
	}

	public Annotator getAnnotator() {
		return annotator;
	}

	public void setAnnotator(Annotator annotator) {
		this.annotator = annotator;
	}

	public AnnotationAnalysis getAnalysis() {
		return analysis;
	}

	public void setAnalysis(AnnotationAnalysis analysis) {
		this.analysis = analysis;
	}

	public HashMap<String, EVAnnotation> getAnnotationIDMap() {
		return annotationIDMap;
	}

	public EVAnnotation getClosestMatchingAnnotation(Class c, int offset) {
		Vector<EVAnnotation> matches = getAnnotationsByOffset(c, offset);
		if (matches != null) {
			if (matches.size() == 1) {
				return matches.firstElement();
			}
			EVAnnotation closest = null;
			int smallestDistance = 1000000;
			for (EVAnnotation match : matches) {
				int dist = Math.abs(match.getStart() - offset)
						+ Math.abs(match.getEnd() - offset);
				if (dist < smallestDistance) {
					smallestDistance = dist;
					closest = match;
				}
			}
			return closest;
		}
		return null;
	}

	public EVAnnotation getAnnotationByOffset(Class c, int offset) {
		Vector<EVAnnotation> matches = getAnnotationsByOffset(c, offset);
		if (matches != null) {
			return matches.firstElement();
		}
		return null;
	}

	public Vector<EVAnnotation> getAnnotationsByOffset(Class c, int offset) {
		Vector<EVAnnotation> annotations = this.getAnnotationsByClass(c);
		Vector<EVAnnotation> matches = null;
		if (annotations != null) {
			boolean foundMatch = false;
			for (EVAnnotation annotation : annotations) {
				if (annotation.getSpans() != null) {
					for (Span span : annotation.getSpans()) {
						if (span.getTextStart() <= offset
								&& offset <= span.getTextEnd()) {
							matches = VUtils.add(matches, annotation);
							foundMatch = true;
						} else if (foundMatch) {
							break;
						}
					}
				}
			}
		}
		return matches;
	}

	public int getNumberOfSpans() {
		return numberOfSpans;
	}

	public void setNumberOfSpans(int numberOfSpans) {
		this.numberOfSpans = numberOfSpans;
	}

	public String getXmlFileName() {
		return xmlFileName;
	}

	public void setXmlFileName(String xmlFileName) {
		this.xmlFileName = xmlFileName;
	}

	public void wrapup() {
		for (Enumeration e = classAnnotationMap.keys(); e.hasMoreElements();) {
			Class c = (Class) e.nextElement();
			Vector<EVAnnotation> annotations = (Vector<EVAnnotation>) classAnnotationMap
					.get(c);
			if (annotations != null) {
				Collections.sort(annotations, new PositionSorter());
			}
		}
	}

	public static class PositionSorter implements Comparator {
		public int compare(Object o1, Object o2) {
			EVAnnotation a1 = (EVAnnotation) o1;
			EVAnnotation a2 = (EVAnnotation) o2;
			if (a1.getStart() < a2.getStart()) {
				return -1;
			}
			if (a1.getStart() > a2.getStart()) {
				return 1;
			}
			return 0;
		}
	}

	public boolean isPrimary() {
		return isPrimary;
	}

	public void setPrimary(boolean isPrimary) {
		this.isPrimary = isPrimary;
	}

}
