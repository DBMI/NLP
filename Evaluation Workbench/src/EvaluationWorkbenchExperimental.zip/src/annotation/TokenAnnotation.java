package annotation;

import onyx.document.document.Document;

public class TokenAnnotation extends EVAnnotation {

	public TokenAnnotation(Document document) {
		super(document);
	}
}
