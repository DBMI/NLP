package annotation;

import java.util.Comparator;
import java.util.Enumeration;
import java.util.Vector;

import onyx.asl.expression.Information;
import onyx.utilities.VUtils;
import typesystem.TypeObject;

public class Classification extends Information {

	String id = null;
	int numericID = 0;
	String annotationType = null;
	typesystem.Annotation parentAnnotation = null;
	typesystem.Classification parentClassification = null;
	static int classificationCounter = 0;

	public Classification(AnnotationCollection ac, String id, int numericID,
			String annotationType, String name, String value) {
		this.id = id;
		TypeObject to = ac.getAnalysis().getArrTool().getTypeSystem()
				.getTypeObject(annotationType);
		if (to instanceof typesystem.Classification) {
			to = to.getParent();
		}
		this.parentAnnotation = (typesystem.Annotation) to;
		this.parentClassification = this.parentAnnotation.getFirstClassification();
		this.numericID = numericID;
		this.setProperty(name, value);
	}
	
	public Classification(AnnotationCollection ac, typesystem.Classification classification,
			String name, String value, String annotationType) {
		this.numericID = classificationCounter++;
		this.id = "Classification_" + this.numericID;
		this.parentClassification = classification;
		if (annotationType == null) {
			annotationType = classification.getId();
		}
		this.annotationType = annotationType;
		this.setProperty(name, value);
	}

	public boolean equals(Object o) {
		if (o instanceof Classification) {
			Classification c = (Classification) o;
			Object v1 = this.getValue();
			Object v2 = c.getValue();
			return (v1 != null && v2 != null && v1.equals(v2));
		} else if (o instanceof String) {
			Object v1 = this.getValue();
			return (v1 != null && this.getValue().equals(o));
		}
		return false;
	}

	public int hashCode() {
		return this.getValue().hashCode();
	}

	public String getId() {
		return id;
	}

	public int getNumericID() {
		return numericID;
	}

	public void setNumericID(int id) {
		this.numericID = id;
	}
	
	public String getName() {
		return this.getParentClassification().getDisplayAttribute().getName();
	}

//	public String getName() {
//		return this.displayedName;
//	}
	
	public String getValue() {
		return this.getStringProperty(getName());
	}

//	public String getValue() {
//		if (this.displayedValue == null) {
//			if (this.displayedName == null) {
//				for (String name : this.getPropertyNames()) {
//					this.displayedName = name;
//					break;
//				}
//			}
//			if (this.displayedName != null) {
//				this.displayedValue = this
//						.getStringProperty(this.displayedName);
//			}
//		}
//		return this.displayedValue;
//	}

	public void addValue(String name, String value) {
		this.setProperty(name, value);
	}
	
	// 3/28/2012
	public String getAttributeString() {
		StringBuffer sb = new StringBuffer();
		sb.append('[');
		for (Enumeration<String> e = this.getPropertyNames().elements(); e.hasMoreElements();) {
			String attribute = e.nextElement();
			sb.append(attribute);
			sb.append('=');
			sb.append(this.getProperty(attribute));
			if (e.hasMoreElements()) {
				sb.append(',');
			}
		}
		sb.append(']');
		return sb.toString();
	}

	public String toString() {
		return getValue();
	}

	public String getAnnotationType() {
		return annotationType;
	}

	public void setAnnotationType(String annotationType) {
		this.annotationType = annotationType;
	}

	public Vector getClassDisplayValueClassificationKey() {
		Vector key = new Vector(0);
		key.add(this.getName());
		key.add(this.getValue());
		return key;
	}

	Vector<Vector<String>> getClassificationAllValueKeys() {
		Vector<Vector<String>> keys = null;
		Vector<Vector<String>> nvkeys = this.getClassificationNameValueKeys();
		Vector<Vector<String>> tvkeys = this.getClassificationTypeValueKeys();
		keys = VUtils.appendIfNot(nvkeys, tvkeys);
		return keys;
	}

	public Vector<Vector<String>> getClassificationTypeValueKeys() {
		Vector<Vector<String>> keys = null;
		if (this.annotationType == null) {
			typesystem.Annotation parent = this.getParentAnnotation();
			if (parent != null) {
				this.annotationType = parent.getName();
			}
		}
		if (this.annotationType != null) {
			for (String name : this.getPropertyNames()) {
				Vector key = VUtils.listify(this.annotationType);
				String value = this.getStringProperty(name);
				key.add(value);
				keys = VUtils.add(keys, key);
			}
		}
		return keys;
	}

	public Vector<Vector<String>> getClassificationNameValueKeys() {
		Vector<Vector<String>> keys = null;
		for (String name : this.getPropertyNames()) {
			String value = this.getStringProperty(name);
			Vector key = VUtils.listify(name);
			key.add(value);
			keys = VUtils.add(keys, key);
		}
		return keys;
	}

	public Vector<Vector<String>> getJavaClassValueKeys() {
		Vector<Vector<String>> keys = null;
		for (String name : this.getPropertyNames()) {
			Vector key = VUtils.listify(this.annotationType);
			String value = this.getStringProperty(name);
			key.add(value);
		}
		return keys;
	}

	public static class ClassificationSorter implements Comparator {
		public int compare(Object o1, Object o2) {
			Classification c1 = (Classification) o1;
			Classification c2 = (Classification) o2;
			String s1 = c1.getValue();
			String s2 = c2.getValue();
			if (s1 != null && s2 != null) {
				return s1.compareTo(s2);
			}
			return 0;
		}
	}

//	public void setDisplayedName(String name) {
//		this.displayedName = name;
//		this.displayedValue = this.getStringProperty(this.displayedName);
//	}

	public typesystem.Annotation getParentAnnotation() {
		return parentAnnotation;
	}

	public typesystem.Classification getParentClassification() {
		return parentClassification;
	}

}
