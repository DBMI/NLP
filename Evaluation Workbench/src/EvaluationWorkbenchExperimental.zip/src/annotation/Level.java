package annotation;

public class Level {
	
	String levelName = null;
	
	public Level(String lname) {
		this.levelName = lname;
	}

}
