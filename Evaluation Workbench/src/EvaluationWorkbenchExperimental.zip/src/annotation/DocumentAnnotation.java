package annotation;

import onyx.document.document.Document;

public class DocumentAnnotation extends EVAnnotation {

	public DocumentAnnotation() {
	
	}
	
	public DocumentAnnotation(Document document) {
		super(document);
	}

	public String getLevelPrefix() {
		return "D";
	}
}
