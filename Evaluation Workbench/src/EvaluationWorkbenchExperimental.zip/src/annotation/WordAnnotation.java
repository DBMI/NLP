package annotation;

import onyx.document.document.Document;

public class WordAnnotation extends EVAnnotation {

	public WordAnnotation(Document document) {
		super(document);
	}
}
