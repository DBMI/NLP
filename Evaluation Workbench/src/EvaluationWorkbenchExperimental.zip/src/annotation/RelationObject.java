package annotation;

public class RelationObject {
	String relation = null;
	EVAnnotation relatum = null;
	
	public RelationObject(String relation, EVAnnotation relatum) {
		this.relation = relation;
		this.relatum = relatum;
	}

	public String getRelation() {
		return relation;
	}

	public void setRelation(String relation) {
		this.relation = relation;
	}

	public EVAnnotation getRelatum() {
		return relatum;
	}

	public void setRelatum(EVAnnotation relatum) {
		this.relatum = relatum;
	}

}
