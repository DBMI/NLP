package annotation;

import java.util.Collections;
import java.util.Comparator;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;
import onyx.document.document.Document;
import typesystem.Annotation;
import typesystem.Attribute;
import typesystem.TypeObject;
import onyx.utilities.StrUtils;
import onyx.utilities.VUtils;

public class EVAnnotation {
	AnnotationCollection annotationCollection = null;
	Hashtable<String, Vector<Object>> attributeMap = new Hashtable();
	Hashtable<String, Vector> relationMap = new Hashtable();
	Vector<RelationObject> relationObjects = null;
	EVAnnotation parentAnnotation = null;
	TypeObject type = null;
	boolean hasMismatch = false;
	String state = null;

	String id = null;
	int numericID = 0;
	String text = null;
	Document document = null;
	Vector<Span> spans = null;
	Classification classification = null;
	Vector<EVAnnotation> components = null;
	int UIMAStart = 0;
	int UIMAEnd = 0;
	boolean isVerified = false;
	boolean isVerifiedTrue = false;
	EVAnnotation matchedAnnotation = null;
	String matchedAnnotationID = null;
	int numberOfAttributes = -1;
	static String[] stateAttributeNames = { "state", "status", "directionality" };
	static String[] presentNames = { "present", "acute", "affirmed", "chronic" };
	static String[] absentNames = { "absent", "negated" };
	static String[] missingNames = { "missing" };
	static Vector<Class> annotationLevels = null;

	public EVAnnotation() {

	}

	public EVAnnotation(Document document) {
		this.document = document;
		annotationLevels = VUtils.addIfNot(annotationLevels, this.getClass());
	}

	public String toXML() {
		StringBuffer sb = new StringBuffer();
		sb.append("<annotation id=\"" + this.getId() + "\" level=\""
				+ this.getLevel() + "\">\n");
		if (this.getClassification() != null) {
			sb.append("\t<classification name=\"" + this.getClassification()
					+ "\"/>\n");
		}
		if (this.getAttributeValues() != null) {
			sb.append("\t<attributes>\n");
			for (Enumeration<String> e = attributeMap.keys(); e
					.hasMoreElements();) {
				String aname = e.nextElement();
				for (Object attribute : attributeMap.get(aname)) {
					sb.append("\t\t<attribute name=\"" + aname + "\" value=\""
							+ attribute + "\"/>\n");
				}
			}
			sb.append("\t</attributes>\n");
		}
		if (this.getRelations() != null) {
			sb.append("\t<relations>\n");
			for (Enumeration<String> e = relationMap.keys(); e
					.hasMoreElements();) {
				String rname = e.nextElement();
				Vector<EVAnnotation> relata = relationMap.get(rname);
				for (EVAnnotation relatum : relata) {
					sb.append("\t\t<relation name=\"" + rname + "\" value=\""
							+ relatum.getId() + "\"/>\n");
				}
			}
			sb.append("\t</relations>\n");
		}
		if (this.getSpans() != null) {
			sb.append("\t<spans>\n");
			for (Span span : this.getSpans()) {
				sb.append("\t\t<span start=\"" + span.getTextStart()
						+ "\" end=\"" + span.getTextEnd() + "\" text=\"");
				sb.append(span.getText() + "\"/>\n");
			}
			sb.append("\t</spans>\n");
		}
		sb.append("</annotation>\n");
		return sb.toString();
	}
	
	public static boolean isSameLevelState(EVAnnotation annotation1,
			EVAnnotation annotation2, Class level) {
		if ((isPresentLevel(annotation1, level) && isPresentLevel(annotation2,
				level))
				|| (!isPresentLevel(annotation1, level) && !isPresentLevel(
						annotation2, level))) {
			return true;
		}
		return false;
	}

	public static boolean isPresentLevel(EVAnnotation annotation, Class level) {
		if (annotation != null && level != null
				&& level.equals(annotation.getClass())) {
			String state = annotation.getState();
			if (StrUtils.getMatchingStringIndex(presentNames, state) >= 0) {
				return true;
			}
		}
		return false;
	}

	public static boolean isAbsentLevel(EVAnnotation annotation, Class level) {
		if (annotation == null || !level.equals(annotation.getClass())) {
			return true;
		}
		if (level.equals(annotation.getClass())) {
			String state = annotation.getState();
			if (StrUtils.getMatchingStringIndex(absentNames, state) >= 0
					|| StrUtils.getMatchingStringIndex(missingNames, state) >= 0) {
				return true;
			}
		}
		return false;
	}
	
	public static boolean isSameClassificationState(EVAnnotation annotation1,
			EVAnnotation annotation2, Classification classification) {
		if ((isPresentClassification(annotation1, classification) && isPresentClassification(
				annotation2, classification))
				|| (!isPresentClassification(annotation1, classification) && !isPresentClassification(
						annotation2, classification))) {
			return true;
		}
		return false;
	}

	public static boolean isPresentClassification(EVAnnotation annotation,
			Classification classification) {
		if (annotation != null && classification != null
				&& classification.equals(annotation.getClassification())) {
			String state = annotation.getState();
			if (StrUtils.getMatchingStringIndex(presentNames, state) >= 0) {
				return true;
			}
		}
		return false;
	}

	public static boolean isAbsentClassification(EVAnnotation annotation,
			Classification classification) {
		if (annotation == null
				|| !classification.equals(annotation.getClassification())) {
			return true;
		}
		if (classification.equals(annotation.getClassification())) {
			String state = annotation.getState();
			if (StrUtils.getMatchingStringIndex(absentNames, state) >= 0
					|| StrUtils.getMatchingStringIndex(missingNames, state) >= 0) {
				return true;
			}
		}
		return false;
	}

	public static boolean isStrictAbsentClassification(EVAnnotation annotation,
			Classification classification) {
		if (annotation != null
				&& classification.equals(annotation.getClassification())) {
			String state = annotation.getState();
			if (StrUtils.getMatchingStringIndex(absentNames, state) >= 0) {
				return true;
			}
		}
		return false;
	}

	public static boolean isMissingClassification(EVAnnotation annotation,
			Classification classification) {
		if (annotation == null
				|| !classification.equals(annotation.getClassification())) {
			return true;
		}
		if (classification.equals(annotation.getClassification())) {
			String state = annotation.getState();
			if (StrUtils.getMatchingStringIndex(missingNames, state) >= 0) {
				return true;
			}
		}
		return false;
	}

	public static boolean isPresentAttributeValue(EVAnnotation annotation,
			String attribute, String value) {
		if (annotation != null) {
			if (value.equals(annotation.getAttribute(attribute))) {
				return true;
			}
		}
		return false;
	}
	
	public static boolean isSameAttributeValue(EVAnnotation annotation1,
			EVAnnotation annotation2, String attribute) {
		Object v1 = annotation1.getAttribute(attribute);
		Object v2 = annotation2.getAttribute(attribute);
		return ((v1 == null && v2 == null)
				||
				(v1 != null && v1.equals(v2)));
	}

	public static boolean isAbsentAttributeValue(EVAnnotation annotation,
			String attribute, String value) {
		if (annotation == null
				|| !value.equals(annotation.getAttribute(attribute))) {
			return true;
		}
		return false;
	}
	
	public String getLevel() {
		return this.getClass().getSimpleName();
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public Document getDocument() {
		return document;
	}

	public void setDocument(Document doc) {
		this.document = doc;
	}

	public boolean isSnippet() {
		return this instanceof SnippetAnnotation;
	}

	public boolean isValid() {
		if (this.getClassification() == null) {
			return false;
		}
		Vector attributes = this.getAttributeValues();
		if (attributes == null) {
			return false;
		}
		// 8/25/2011:  Hack.  Other typesystems won't have this.
		if (this.isSnippet()) {
			for (Object attribute : attributes) {
				if ("missing".equals(attribute.toString())) {
					return false;
				}
			}
		}
		return true;
	}

	public void setSpans(Vector<Span> spans) {
		this.spans = spans;
	}

	public Vector<Span> getSpans() {
		Vector<Span> allSpans = null;
		if (this.spans == null && this.getComponents() != null) {
			for (EVAnnotation component : this.getComponents()) {
				allSpans = VUtils.appendIfNot(allSpans, component.getSpans());
			}
			if (allSpans != null) {
				Collections.sort(allSpans, new Span.PositionSorter());
				this.setSpans(allSpans);
			}
		}
		return this.spans;
	}

	public Span getFirstSpan() {
		if (spans != null) {
			return spans.firstElement();
		}
		return null;
	}

	public void addSpan(int start, int end) {
		Span span = new Span(this, start, end);
		this.spans = VUtils.add(this.spans, span);
		Collections.sort(this.spans, new Span.PositionSorter());
	}

	public void addSpan(Span span) {
		span.annotation = this;
		span.setId(span.getId());
		this.spans = VUtils.add(this.spans, span);
		Collections.sort(this.spans, new Span.PositionSorter());
	}

	public int getStart() {
		if (this.getSpans() != null) {
			return this.getSpans().firstElement().getTextStart();
		}
		return -1;
	}

	public int getEnd() {
		if (this.getSpans() != null) {
			return this.getSpans().lastElement().getTextEnd();
		}
		return -1;
	}

	public Vector<EVAnnotation> getComponents() {
		if (this.components == null) {
			Vector<EVAnnotation> relata = this.getRelata("component_of");
			if (relata != null) {
				this.setComponents(relata);
			}
		}
		return components;
	}

	public void setComponents(Vector<EVAnnotation> components) {
		this.components = components;
	}

	public void addComponent(EVAnnotation component) {
		this.components = VUtils.addIfNot(this.components, component);
	}

	public Classification getClassification() {
		return classification;
	}

	public void setClassification(Classification classification) {
		this.classification = classification;
	}

	public Object getAttribute(String aname) {
		if (aname != null) {
			Vector v = (Vector) attributeMap.get(aname);
			if (v != null) {
				return v.firstElement();
			}
		}
		return null;
	}
	
	public void setAttribute(String attribute, Object value) {
		if (attribute != null && value != null) {
			String aname = attribute;
			VUtils.pushHashVector(this.attributeMap, aname, value);
			if (attribute.indexOf(':') > 0) {
				Vector<String> v = StrUtils.stringList(attribute, ':');
				if (v != null) {
					String last = v.lastElement();
					VUtils.pushHashVector(this.attributeMap, last, value);
				}
			}
			Annotation annotationType = Annotation.getAnnotationByClass(this
					.getClass());
			if (annotationType != null) {
				Attribute atype = annotationType.getAttribute(attribute);
				if (atype != null) {
					atype.addValue(value);
				}
			}
		}
	}
	
	public int getNumberOfAttributes() {
		if (this.numberOfAttributes < 0) {
			this.numberOfAttributes = this.attributeMap.keySet().size();
		}
		return this.numberOfAttributes;
	}

	public Vector<String> getAttributes() {
		Vector<String> attributes = null;
		for (Enumeration<String> e = this.attributeMap.keys(); e.hasMoreElements();) {
			attributes = VUtils.add(attributes, e.nextElement());
		}
		return attributes;
	}

	public Vector getAttributeValues() {
		Vector values = null;
		if (!this.attributeMap.isEmpty()) {
			for (Enumeration e = this.attributeMap.elements(); e.hasMoreElements();) {
				values = VUtils.append(values, (Vector) e.nextElement());
			}
		}
		return values;
	}

	public Vector getRelata(String rname) {
		return relationMap.get(rname);
	}

	public void setRelation(String relation, Object value) {
		if (relation != null && value != null) {
			String rname = relation;
			VUtils.pushIfNotHashVector(this.relationMap, rname, value);
			if (value instanceof EVAnnotation) {
				((EVAnnotation) value).parentAnnotation = this;
			}
		}
	}

	public Vector<String> getRelations() {
		return new Vector(this.relationMap.keySet());
	}

	public Vector<RelationObject> getRelationObjects() {
		if (this.relationObjects == null) {
			for (Enumeration<String> e = this.relationMap.keys(); e
					.hasMoreElements();) {
				String relation = e.nextElement();
				Vector<EVAnnotation> relata = this.relationMap.get(relation);
				for (EVAnnotation relatum : relata) {
					RelationObject ro = new RelationObject(relation, relatum);
					this.relationObjects = VUtils.add(this.relationObjects, ro);
				}
			}
		}
		return this.relationObjects;
	}

	public EVAnnotation getParentAnnotation() {
		return this.parentAnnotation;
	}

	public void setParentAnnotation(EVAnnotation parentAnnotation) {
		this.parentAnnotation = parentAnnotation;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		if (id == null) {
			int num = this.getAnnotationCollection()
					.getNumberOfAnnotationsByClass(this.getClass());
			id = this.getLevel() + "_" + num;
		}
		this.id = id;
		this.getAnnotationCollection().getAnnotationIDMap().put(id, this);
	}

	public AnnotationCollection getAnnotationCollection() {
		return annotationCollection;
	}

	public void setAnnotationCollection(AnnotationCollection ac) {
		this.annotationCollection = ac;
		VUtils.pushHashVector(ac.classAnnotationMap, this.getClass(), this);
	}
	
	public String getState() {
		if (this.state == null) {
			for (int i = 0; i < stateAttributeNames.length; i++) {
				String sname = stateAttributeNames[i];
				for (Enumeration<String> e = this.attributeMap.keys(); this.state == null
						&& e.hasMoreElements();) {
					String key = e.nextElement();
					if (key.toLowerCase().contains(sname)) {
						this.state = (String) this.attributeMap.get(key)
								.firstElement();
					}
				}
			}
			if (this.state == null) {
				this.state = "present";
			}
		}
		return this.state;
	}

	public String toString() {
		return "<" + this.getLevelPrefix() + ":" + this.getClassification()
				+ ":" + this.getNumericID() + ">";
	}

	public String getLevelPrefix() {
		return "?";
	}

	public int getNumericID() {
		return this.numericID;
	}

	public void setNumericID(int id) {
		this.numericID = id;
	}
	
//	public Vector getClassificationKey() {
//		Vector key = null;
//		if (this.getClassification() != null) {
//			key = new Vector(0);
//			key.add(this.getClassification().getName());
//			key.add(this.getClassification().getValue());
//		}
//		return key;
//	}
//
//	public static Vector getClassificationKey(Class c,
//			Classification classification) {
//		return VUtils.arrayToVector(new Object[] { classification.getName(),
//				classification.getValue() });
//	}
//	
//	public Vector<Vector<String>> getClassificationKeys() {
//		Vector<Vector<String>> keys = null;
//		if (this.getClassification() != null) {
//			Classification c = this.getClassification();
//			for (String name : c.getPropertyNames()) {
//				String value = c.getStringProperty(name);
//				Vector key = VUtils.listify(name);
//				key.add(value);
//				keys = VUtils.add(keys, key);
//			}
//		}
//		return keys;
//	}

	public Hashtable<String, Vector<Object>> getAttributeMap() {
		return attributeMap;
	}

	public void setAttributeMap(Hashtable<String, Vector<Object>> attributeMap) {
		this.attributeMap = attributeMap;
	}

	public Hashtable<String, Vector> getRelationMap() {
		return relationMap;
	}

	public void setRelationMap(Hashtable<String, Vector> relationMap) {
		this.relationMap = relationMap;
	}

	public void setRelationObjects(Vector<RelationObject> relationObjects) {
		this.relationObjects = relationObjects;
	}

	public static class ClassificationSorter implements Comparator {
		public int compare(Object o1, Object o2) {
			EVAnnotation a1 = (EVAnnotation) o1;
			EVAnnotation a2 = (EVAnnotation) o2;
			return a1.getClassification().getValue()
					.compareTo(a2.getClassification().getValue());
		}
	}

	public static Vector<Class> getAnnotationLevels() {
		return annotationLevels;
	}

	public int getUIMAStart() {
		return UIMAStart;
	}

	public void setUIMAStart(int uIMAStart) {
		UIMAStart = uIMAStart;
	}

	public int getUIMAEnd() {
		return UIMAEnd;
	}

	public void setUIMAEnd(int uIMAEnd) {
		UIMAEnd = uIMAEnd;
	}

	public TypeObject getType() {
		return type;
	}

	public void setType(TypeObject type) {
		this.type = type;
	}
	
	public boolean isStartEndAssigned() {
		return this.getStart() >= 0;
	}

	public boolean isHasMismatch() {
		return hasMismatch;
	}

	public void setHasMismatch(boolean hasMismatch) {
		this.hasMismatch = hasMismatch;
	}

	public boolean isVerified() {
		return isVerified;
	}

	public void setVerified(boolean isVerified) {
		this.isVerified = isVerified;
	}

	public boolean isVerifiedTrue() {
		return isVerifiedTrue;
	}

	public void setVerifiedTrue(boolean isVerifiedTrue) {
		this.isVerifiedTrue = isVerifiedTrue;
	}

	public EVAnnotation getMatchedAnnotation() {
		return matchedAnnotation;
	}

	public void setMatchedAnnotation(EVAnnotation matchedAnnotation) {
		this.matchedAnnotation = matchedAnnotation;
	}

	public String getMatchedAnnotationID() {
		return matchedAnnotationID;
	}

	public void setMatchedAnnotationID(String matchedAnnotationID) {
		this.matchedAnnotationID = matchedAnnotationID;
	}
	

}
