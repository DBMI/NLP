package annotation;

import onyx.document.document.Document;

public class UtteranceAnnotation extends EVAnnotation {

	public UtteranceAnnotation(Document document) {
		super(document);
	}
}
