package annotation;

import onyx.document.document.Document;

public class CorpusAnnotation extends EVAnnotation {
	
	public CorpusAnnotation(Document document) {
		super(document);
	}

}
