package annotation;

import onyx.document.document.Document;

public class GroupAnnotation extends EVAnnotation {
	
	public GroupAnnotation() {
		
	}
	public GroupAnnotation(Document document) {
		super(document);
	}
	// SPM 12/21/2011 Add group level tagging 
	public String getLevelPrefix() {
		return "G";
	}
}
