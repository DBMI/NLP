package typesystem;

import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import typesystem.UIMAResultJTree.UIMATreeFeature;

public class ClassificationEditPane extends JPanel implements ActionListener,
		ItemListener {
	JFrame frame = null;
	JTextField text = null;
	private UIMATreeFeature uimaTreeFeature = null;
	private JCheckBox checkbox = null;
	private boolean checked = false;

	public ClassificationEditPane(JFrame frame, Point point, UIMATreeFeature uto) {
		this.frame = frame;
		frame.setLocation(point);
		uimaTreeFeature = uto;
		JLabel label = new JLabel("Name:");
		add(label);
		text = new JTextField(uto.name, 20);
		add(text);
		checkbox = new JCheckBox("Default Display");
		add(checkbox);
		checkbox.addItemListener(this);
		JButton button = new JButton("Remove");
		button.addActionListener(this);
		add(button);
		button = new JButton("Cancel");
		button.addActionListener(this);
		add(button);
		button = new JButton("Done");
		button.addActionListener(this);
		add(button);
	}

	public void itemStateChanged(ItemEvent e) {
		Object source = e.getItemSelectable();
		if (source == checkbox) {
			checked = !checked;
		}
	}

	public void actionPerformed(ActionEvent e) {
		String command = e.getActionCommand();
		if ("Remove".equals(command)) {
			if (UIMATypeSystem.currentTypeSystem.resultJTree.selectedNode != null) {
				UIMATypeSystem.currentTypeSystem.resultJTree.selectedNode
						.removeUIMATreeObject();
			}
			UIMATypeSystem.currentTypeSystem.resultJTree.reinstantiate();
			this.frame.dispose();
		}
		if ("Done".equals(command)) {
			this.uimaTreeFeature.name = text.getText();
			this.uimaTreeFeature.doDisplay = checked;
			UIMATypeSystem.currentTypeSystem.resultJTree.reinstantiate();
			this.frame.dispose();
		} else if ("Cancel".equals(command)) {
			this.frame.dispose();
		}

	}

}
