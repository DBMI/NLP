package typesystem;

import java.awt.Point;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTree;
import javax.swing.event.TreeModelEvent;
import javax.swing.event.TreeModelListener;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreePath;
import javax.swing.tree.TreeSelectionModel;

import workbench.arr.EvaluationWorkbench;

public class TypeSystemJTree extends JPanel implements TreeSelectionListener,
		MouseMotionListener {
	TypeSystem typeSystem = null;
	EvaluationWorkbench arrTool = null;
	TypeObject rootTypeObject = null;
	DefaultTreeModel treeModel = null;
	TypeObjectJTree tree = null;
	TypeObjectMutableTreeNode rootNode = null;
	TypeObjectMutableTreeNode selectedNode = null;
	TreePath lastTreePath = null;
	static boolean userInteraction = false;

	public TypeSystemJTree(EvaluationWorkbench tool) {
		this.typeSystem = tool.typeSystem;
		this.arrTool = tool;
		rootTypeObject = tool.typeSystem.getRoot();
		createJTree();
	}

	void createJTree() {
		// SPM 12/16/2011 Refresh uima annotation tree
		typeSystem.clearUIMAAnnotations();
		rootNode = new TypeObjectMutableTreeNode(rootTypeObject);
		treeModel = new TypeObjectDefaultTreeModel(rootNode);
		wrapChildNodes(rootNode);
		treeModel.addTreeModelListener(new TypeObjectTreeModelListener());
		tree = new TypeObjectJTree(treeModel);
		tree.setEditable(true);
		tree.getSelectionModel().setSelectionMode(
				TreeSelectionModel.SINGLE_TREE_SELECTION);
		tree.setShowsRootHandles(true);
		tree.addTreeSelectionListener(this);
		tree.addMouseMotionListener(this);
		for (int i = 0; i < tree.getRowCount(); i++) {
			tree.expandRow(i);
		}
		JScrollPane scrollPane = new JScrollPane(tree);
		this.removeAll();
		add(scrollPane);
	}

	private void wrapChildNodes(TypeObjectMutableTreeNode pnode) {
		TypeObject o = (TypeObject) pnode.getUserObject();
		// Removed 3/15/2012
//		if (o.getClassifications() != null) {
//			TypeObjectMutableTreeNode edge = new TypeObjectMutableTreeNode(
//					"<classifications>");
//			treeModel.insertNodeInto(edge, pnode, pnode.getChildCount());
//			for (Classification c : o.getClassifications()) {
//				TypeObjectMutableTreeNode cnode = new TypeObjectMutableTreeNode(
//						c);
//				treeModel.insertNodeInto(cnode, edge, edge.getChildCount());
//			}
//		}
		if (o.getComponents() != null) {
			TypeObjectMutableTreeNode edge = new TypeObjectMutableTreeNode(
					"<components>");
			treeModel.insertNodeInto(edge, pnode, pnode.getChildCount());
			for (Annotation annotation : o.getComponents()) {
				TypeObjectMutableTreeNode cnode = new TypeObjectMutableTreeNode(
						annotation);
				treeModel.insertNodeInto(cnode, edge, edge.getChildCount());
				wrapChildNodes(cnode);
			}
		}
		if (o.getAttributes() != null) {
			TypeObjectMutableTreeNode edge = new TypeObjectMutableTreeNode(
					"<attributes>");
			treeModel.insertNodeInto(edge, pnode, pnode.getChildCount());
			for (Attribute attribute : o.getAttributes()) {
				TypeObjectMutableTreeNode cnode = new TypeObjectMutableTreeNode(
						attribute);
				treeModel.insertNodeInto(cnode, edge, edge.getChildCount());
			}
		}
	}

	void processValueSelection(Object o) {
		Class level = null;
		if (o instanceof Annotation) {
			level = ((Annotation) o).getAnnotationClass();
		} else if (o instanceof Attribute) {
			level = ((Attribute) o).getParent().getAnnotationClass();
		}
		if (level != null) {
			arrTool.getAnalysis().setSelectedLevel(level, true);
		}
		if (o instanceof Annotation || o instanceof Attribute) {
			arrTool.getGeneralStatistics(o);
			// GeneralStatistics.create(arrTool, o);
		} else {
			this.arrTool.statistics = null;
			this.arrTool.accuracyPane.fireTableDataChanged();
		}
		this.arrTool.fireAllTableDataChanged();
	}

	public void selectLevel(Class c) {
		Annotation annotation = Annotation.getAnnotationByClass(c);
		TreePath path = this.tree.getPathForRow(annotation.getRowNumber());
		this.tree.setSelectionPath(path);
		this.tree.scrollPathToVisible(path);
	}

	public TypeObjectMutableTreeNode getSelectedNode() {
		return this.selectedNode;
	}

	public void valueChanged(TreeSelectionEvent e) {
		userInteraction = true;
		TypeObjectMutableTreeNode node = (TypeObjectMutableTreeNode) tree
				.getLastSelectedPathComponent();
		if (node != null) {
			Object o = node.getUserObject();
			if (o instanceof Annotation) {
				Class c = ((Annotation) o).getAnnotationClass();
				// GeneralStatistics.create(arrTool, c);
				arrTool.getGeneralStatistics(c);
				// this.arrTool.fireAllTableDataChanged();
			}
		}
		userInteraction = false;
	}

	public static boolean withUserInteraction() {
		return userInteraction;
	}

	class TypeObjectMutableTreeNode extends DefaultMutableTreeNode {
		public static final long serialVersionUID = 0;

		TypeObjectMutableTreeNode(Object o) {
			super(o);
		}

		public String toString() {
			if (this.getUserObject() instanceof String) {
				return this.getUserObject().toString();
			}
			if (this.getUserObject() instanceof TypeObject) {
				TypeObject o = (TypeObject) this.getUserObject();
				return o.getName();
			}
			return "?";
		}
	}

	class TypeObjectDefaultTreeModel extends DefaultTreeModel {
		public static final long serialVersionUID = 0;

		TypeObjectDefaultTreeModel(TypeObjectMutableTreeNode node) {
			super(node);
		}

		public void valueForPathChanged(TreePath path, Object newValue) {
			TypeObjectMutableTreeNode pathnode = (TypeObjectMutableTreeNode) path
					.getLastPathComponent();
			pathnode = pathnode;
		}
	}

	class TypeObjectJTree extends JTree {
		public static final long serialVersionUID = 0;

		TypeObjectJTree(DefaultTreeModel model) {
			super(model);
		}

		public String getToolTipText(MouseEvent e) {
			Point p = e.getPoint();
			TreePath path = tree.getClosestPathForLocation(p.x, p.y);
			TypeObjectMutableTreeNode node = (TypeObjectMutableTreeNode) path
					.getLastPathComponent();
			return "";
		}

	}

	class TypeObjectTreeModelListener implements TreeModelListener {
		public void treeNodesChanged(TreeModelEvent e) {
			TypeObjectMutableTreeNode node = (TypeObjectMutableTreeNode) (e
					.getTreePath().getLastPathComponent());
			try {
				int index = e.getChildIndices()[0];
				node = (TypeObjectMutableTreeNode) (node.getChildAt(index));
			} catch (NullPointerException exc) {
			}
		}

		public void treeNodesInserted(TreeModelEvent e) {
		}

		public void treeNodesRemoved(TreeModelEvent e) {
		}

		public void treeStructureChanged(TreeModelEvent e) {
		}
	}

	public TypeObjectJTree getTree() {
		return tree;
	}

	public void setTree(TypeObjectJTree tree) {
		this.tree = tree;
	}

	public void mouseClicked(MouseEvent e) {
	}

	public void mouseExited(MouseEvent e) {
	}

	public void mouseEntered(MouseEvent e) {
	}

	public void mousePressed(MouseEvent e) {
	}

	public void mouseReleased(MouseEvent e) {
	}

	public void mouseDragged(MouseEvent e) {
	}

	public void mouseMoved(MouseEvent e) {
		if (e.isControlDown()) {
			userInteraction = true;
			TreePath path = tree.getPathForLocation(e.getX(), e.getY());
			if (path != null && path != this.lastTreePath) {
				this.lastTreePath = path;
				if (tree.isPathSelected(path)) {
					tree.removeSelectionPath(path);
				} else {
					Object lastElement = path.getLastPathComponent();
					this.selectedNode = (TypeObjectMutableTreeNode) lastElement;
					tree.addSelectionPath(path);
					processValueSelection(this.selectedNode.getUserObject());
				}
			}
			userInteraction = false;
		}
	}

}
