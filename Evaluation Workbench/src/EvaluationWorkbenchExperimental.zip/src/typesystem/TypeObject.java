package typesystem;

import java.util.Vector;
import onyx.utilities.VUtils;

public abstract class TypeObject {

	TypeSystem typeSystem = null;
	String javaType = null;
	String id = null;
	String name = null;
	String uima = null;
	String shortUima = null;
	// SPM 12/16/2011 Add UIMA type system parameter
	String uimaType = null;
	TypeObject parent = null;
	// SPM 12/16/2011 Static necessary to maintain vector contents
	// static Vector<Classification> classifications = null;
	// static Vector<Attribute> attributes = null;
	// static Vector<Annotation> components = null;
	Vector<Classification> classifications = null;
	Vector<Attribute> attributes = null;
	Vector<Annotation> components = null;
	int row = 0;

	public TypeObject() {
		this.javaType = this.getClass().getSimpleName();
	}
	
	public TypeObject(TypeSystem ts, String name) {
		this.typeSystem = ts;
		this.name = name;
	}
	
	public TypeObject(TypeSystem ts, String name, String uima) {
		typeSystem = ts;
		this.id = this.getClass().getSimpleName() + "_"
		+ typeSystem.typeObjectCount++;
		this.name = name;
		this.uima = uima;
		this.shortUima = getShortUimaName(uima);
		this.javaType = this.getClass().getSimpleName();
	}

	public TypeObject(TypeSystem ts, String id, String name, String uima) {
		this(ts, id, name, uima, null);
	}

	// SPM 12/16/2011 Add UIMA type system parameter
	public TypeObject(TypeSystem ts, String id, String name, String uima,
			String uimaType) {
		typeSystem = ts;
		this.id = id;
		this.name = name;
		this.uima = uima;
		this.shortUima = getShortUimaName(uima);
		this.javaType = this.getClass().getSimpleName();
		this.uimaType = uimaType;
	}

	// SPM 12/16/2011 Refresh child component tree
	public void clearComponentChild() {
		if (this.components != null) {
			components.clear();
		}
	}

	public Object getValue(String name) {
		return VUtils.findIfMatchingField(attributes, "name", name);
	}

	void assignRowNumber() {
		this.row = typeSystem.rowNumber++;
		Vector<TypeObject> children = getChildren();
		if (children != null) {
			for (TypeObject child : children) {
				child.assignRowNumber();
			}
		}
	}

	public int getRowNumber() {
		return this.row;
	}

	public String toString() {
		return "<[" + this.getClass().getSimpleName() + "],Id=" + this.getId() + ",Name=" + this.getName() + ",UIMA="
				+ this.getUima() + ",Type=" + this.getClass().getSimpleName()
				+ ">";
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Vector<Classification> getClassifications() {
		return classifications;
	}

	public Classification getFirstClassification() {
		if (classifications != null) {
			return classifications.firstElement();
		}
		return null;
	}

	public void setClassification(Classification classification) {
		this.classifications = VUtils.add(this.classifications, classification);
	}

	public Vector<Attribute> getAttributes() {
		return attributes;
	}

	public void setAttributes(Vector<Attribute> attributes) {
		this.attributes = attributes;
	}

	public Vector<Annotation> getComponents() {
		return components;
	}

	public void addComponent(Annotation component) {
		this.components = VUtils.add(this.components, component);
	}

	public boolean hasComponents() {
		return this.components != null;
	}

	public void addAttribute(Attribute attribute) {
		this.attributes = VUtils.add(this.attributes, attribute);
	}

	public TypeObject getParent() {
		return parent;
	}
	
	public Attribute getAttribute(String aname) {
		if (this.attributes != null) {
			for (Attribute attribute : this.attributes) {
				if (aname.equalsIgnoreCase(attribute.getName())) {
					return attribute;
				}
			}
		}
		return null;
	}

	// SPM 12/16/2011 Add UIMA type system parameter
	public String getUimaType() {
		return this.uimaType;
	}

	public void setParent(TypeObject parent) {
		this.parent = parent;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Vector<TypeObject> getChildren() {
		Vector<TypeObject> children = null;
		children = VUtils.append(children, this.getClassifications());
		children = VUtils.append(children, this.getAttributes());
		children = VUtils.append(children, this.getComponents());
		return children;
	}

	public String getUima() {
		return uima;
	}

	public boolean isChildOf(TypeObject c) {
		return (this.getParent() != null && this.getParent().equals(c));
	}

	public Class getAnnotationClass() {
		if (this instanceof Annotation) {
			return ((Annotation) this).getAnnotationClass();
		}
		return null;
	}

	public String getParentUIMA() {
		if (this.getParent() != null) {
			if (this.getParent().getUima() != null) {
				return this.getParent().getUima();
			}
			return this.getParent().getParentUIMA();
		}
		return null;
	}
	
	String getShortUima() {
		return this.shortUima;
	}

	static String getShortUimaName(String umlsName) {
		String str = null;
		if (umlsName != null) {
			int cindex = umlsName.lastIndexOf(':');
			int pindex = umlsName.lastIndexOf('.');
			if (cindex > 0) {
				str = umlsName.substring(cindex + 1);
			} else if (pindex > 0) {
				str = umlsName.substring(pindex + 1);
			}
		}
		return str;
	}
	
	String toLisp(int depth) {
		return "";
	}
	
	void addSpaces(StringBuffer sb, int num) {
		sb.append("\n");
		for (int i = 0; i < num; i++) {
			sb.append(' ');
		}
	}

	public String getJavaType() {
		return javaType;
	}

	public void setJavaType(String javaType) {
		this.javaType = javaType;
	}

}
