package typesystem;

import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import typesystem.UIMAResultJTree.UIMATreeFeature;

public class AttributeEditPane extends JPanel implements ActionListener {
	JFrame frame = null;
	JTextField text = null;
	private UIMATreeFeature uimaTreeFeature = null;
	
	public AttributeEditPane(JFrame frame, Point point, UIMATreeFeature uto) {
		this.frame = frame;
		frame.setLocation(point);
		uimaTreeFeature = uto;
		JLabel label = new JLabel("Name:");
		add(label);
		text = new JTextField(uto.name);
		add(text);
		JButton button = new JButton("Cancel");
		button.addActionListener(this);
		add(button);
		button = new JButton("Done");
		button.addActionListener(this);
		add(button);
	}
	
	public void actionPerformed(ActionEvent e) {
		String command = e.getActionCommand();
		if ("Done".equals(command)) {
			this.uimaTreeFeature.name = text.getText();
			this.frame.dispose();
			UIMATypeSystem.currentTypeSystem.resultJTree.reinstantiate();
		} else if ("Cancel".equals(command)) {
			this.frame.dispose();
		}

	}

}
