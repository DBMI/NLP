package typesystem;

public class Classification extends TypeObject {
	
	Attribute displayAttribute = null;

	public Classification(TypeSystem ts, String name, String uima) {
		super(ts, name, uima);
	}
	
	// SPM 12/16/2011  Add UIMA type system parameter
	public Classification(TypeSystem ts, String id, String name, String uima) {
		super(ts, id, name, uima);
	}
	
	public String toString() {
		return this.getName();
	}
	
	public String getShortUimaDisplayClassificationName() {
		if (this.attributes != null) {
			for (Attribute attribute : this.attributes) {
				if (attribute.isDisplay() || this.attributes.size() == 1) {
					return attribute.getShortUima();
				}
			}
		}
		return null;
	}
	
	// 3/6/2012
	public boolean containsClassificationAttribute(String aname) {
		if (aname != null && this.attributes != null) {
			for (Attribute attribute : this.attributes) {
				if (aname.equalsIgnoreCase(attribute.getShortUima())) {
					return true;
				}
			}
		}
		return false;
	}
	
	// SPM 12/16/2011 Returns displayed classification also testing parent/child relationship
	public String getDisplayClassification(String parent) {
		if (this.attributes != null) {
			for (Attribute attribute : this.attributes) {
				if ((attribute.isDisplay() || this.attributes.size() == 1)
						&& parent.contentEquals(attribute.parent.getName())) {
					return attribute.getName();
				}
			}
		}
		return null;
	}
	
	String toLisp(int depth) {
		StringBuffer sb = new StringBuffer();
		if (this.attributes != null) {
			for (Attribute attribute : this.attributes) {
				sb.append(attribute.toLisp(depth + 6));
			}
		}
		return sb.toString();
	}

	public Attribute getDisplayAttribute() {
		if (this.displayAttribute == null && this.getAttributes() != null) {
			Attribute first = this.attributes.firstElement();
			this.setDisplayAttribute(first.getName());
		}
		return this.displayAttribute;
	}

	public void setDisplayAttribute(String aname) {
		if (this.getAttributes() != null) {
			for (Attribute attribute : this.getAttributes()) {
				attribute.setIsDisplay(false);
			}
		}
		this.displayAttribute = this.getAttribute(aname);
		if (this.displayAttribute != null) {
			this.displayAttribute.setIsDisplay(true);
		}
	}
	
	
}
