package typesystem;

import java.awt.Component;
import java.awt.Dimension;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTree;
import javax.swing.event.TreeModelEvent;
import javax.swing.event.TreeModelListener;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreePath;
import javax.swing.tree.TreeSelectionModel;
import org.apache.uima.cas.Feature;
import org.apache.uima.cas.Type;
import org.apache.uima.jcas.JCas;
import onyx.utilities.HUtils;
import onyx.utilities.VUtils;
import typesystem.UIMAResultJTree.UIMATreeAnnotation;
import typesystem.UIMAResultJTree.UIMATreeRelation;
//import typesystem.UIMAResultJTree.UIMATreeClassification;
import typesystem.UIMAResultJTree.UIMATreeFeature;

public class UIMATypeSystemJTree extends JPanel implements
		TreeSelectionListener, MouseMotionListener {
	org.apache.uima.cas.TypeSystem typeSystem = null;
	org.apache.uima.cas.Type UIMATopType = null;
	UIMATypeObjectDefaultTreeModel treeModel = null;
	UIMATypeObjectJTree tree = null;
	UIMATypeObjectMutableTreeNode rootNode = null;
	UIMATypeObjectMutableTreeNode selectedNode = null;
	TreePath lastTreePath = null;
	Vector<UIMATreeObject> selectedTypeObjects = null;
	UIMATreeAnnotation selectedAnnotation = null;
	UIMATreeAnnotation lastSelectedAnnotation = null;
	Vector<UIMATreeAnnotation> allAnnotations = null;
	static UIMATreeObject isEditableUIMATreeObject = null;
	static Component treeCellEditorComponent = null;
	static UIMATreeObject lastMouseMovedUIMATreeObject = null;
	String selectedLevel = null;
	static UIMAResultJTree resultTree = null;
	static Vector<String> ignorableFeatureNames = VUtils
			.arrayToVector(new String[] { "sofa", "begin", "end", "uri",
					"language", "string" });
	static int UIMAAttribute = 0;
	static int UIMAFeature = 1;
	public static String[] levels = { "document", "group", "snippet", "word",
			"token" };
	public static String[] workbenchJavaClasses = { "DocumentAnnotation",
			"GroupAnnotation", "SnippetAnnotation", "WordAnnotation",
			"TokenAnnotation" };
	public static HashMap<String, String> levelToWorkbenchMap = HUtils
			.createMap(levels, workbenchJavaClasses);

	public UIMATypeSystemJTree() {

	}

	public UIMATypeSystemJTree(JCas jcas) {
		resultTree = UIMATypeSystem.currentTypeSystem.resultJTree;
		typeSystem = jcas.getTypeSystem();
		org.apache.uima.cas.Type atype = findAnnotationType(typeSystem
				.getTopType());
		rootNode = new UIMATypeObjectMutableTreeNode(new UIMATreeObject(null,
				atype));
		initialize();
	}

	void initialize() {
		treeModel = new UIMATypeObjectDefaultTreeModel(rootNode);
		treeModel.addTreeModelListener(new UIMATypeObjectTreeModelListener());
		tree = new UIMATypeObjectJTree(treeModel);
		wrapNodes(rootNode);
		tree.setEditable(true);
		tree.getSelectionModel().setSelectionMode(
				TreeSelectionModel.DISCONTIGUOUS_TREE_SELECTION);
		tree.setShowsRootHandles(true);
		tree.addTreeSelectionListener(this);
		tree.addMouseMotionListener(this);
		JScrollPane scrollPane = new JScrollPane(tree);
		this.removeAll();
		tree.expandRows(true);
		tree.setPreferredSize(new Dimension(400, 500));
		add(scrollPane);
	}

	boolean isUIMATree() {
		return !isResultTree();
	}

	boolean isResultTree() {
		return (this instanceof UIMAResultJTree);
	}

	void wrapNodes(UIMATypeObjectMutableTreeNode pnode) {
		UIMATreeObject userObject = (UIMATreeObject) pnode.getUserObject();
		Type ptype = (Type) userObject.uimaObject;
		if (!ptype.isPrimitive()) {
			Vector<UIMATypeObjectMutableTreeNode> featureNodes = null;
			Vector<UIMATypeObjectMutableTreeNode> componentNodes = null;
			List<Feature> features = ptype.getFeatures();
			if (features != null) {
				for (Iterator<Feature> it = features.iterator(); it.hasNext();) {
					Feature feature = it.next();
					if (!ignorableFeatureNames.contains(feature.getShortName())) {
						UIMATreeObject object = resultTree.new UIMATreeFeature(
								userObject, feature);
						UIMATypeObjectMutableTreeNode cfnode = new UIMATypeObjectMutableTreeNode(
								object);
						featureNodes = VUtils.add(featureNodes, cfnode);
					}
				}
			}
			List<Type> subtypes = this.typeSystem.getDirectSubtypes(ptype);
			if (subtypes != null) {
				Iterator<Type> ti = subtypes.iterator();
				while (ti.hasNext()) {
					Type ctype = ti.next();
					UIMATreeObject object = resultTree.new UIMATreeAnnotation(
							userObject, ctype);
					UIMATypeObjectMutableTreeNode cnode = new UIMATypeObjectMutableTreeNode(
							object);
					componentNodes = VUtils.add(componentNodes, cnode);
				}
			}
			if (featureNodes != null) {
				for (UIMATypeObjectMutableTreeNode fnode : new Vector<UIMATypeObjectMutableTreeNode>(
						featureNodes)) {
					treeModel.insertNodeInto(fnode, pnode,
							pnode.getChildCount());
				}
			}
			if (componentNodes != null) {
				for (UIMATypeObjectMutableTreeNode cnode : new Vector<UIMATypeObjectMutableTreeNode>(
						componentNodes)) {
					treeModel.insertNodeInto(cnode, pnode,
							pnode.getChildCount());
					wrapNodes(cnode);
				}
			}
		}
	}

	org.apache.uima.cas.Type findAnnotationType(org.apache.uima.cas.Type type) {
		if ("annotation".equalsIgnoreCase(type.getShortName())) {
			return type;
		}
		List<Type> subtypes = this.typeSystem.getDirectSubtypes(type);
		if (subtypes != null) {
			Iterator<Type> ti = subtypes.iterator();
			while (ti.hasNext()) {
				Type ctype = ti.next();
				org.apache.uima.cas.Type atype = findAnnotationType(ctype);
				if (atype != null) {
					return atype;
				}
			}
		}
		return null;
	}

	void processValueSelection(Object o) {
	}

	public void valueChanged(TreeSelectionEvent e) {
		TreePath[] paths = tree.getSelectionPaths();
		Vector<UIMATreeObject> objects = null;
		if (paths != null) {
			for (int i = 0; i < paths.length; i++) {
				Object[] nodes = paths[i].getPath();
				UIMATypeObjectMutableTreeNode node = (UIMATypeObjectMutableTreeNode) nodes[nodes.length - 1];
				this.selectedNode = node;
				UIMATreeObject o = (UIMATreeObject) node.getUserObject();
				objects = VUtils.add(objects, o);
			}
		}
		this.selectedTypeObjects = objects;
	}

	public UIMATreeObject getSelectedTypeObject() {
		if (selectedTypeObjects != null) {
			return selectedTypeObjects.firstElement();
		}
		return null;
	}

	public Vector<UIMATreeObject> getSelectedTypeObjects() {
		return selectedTypeObjects;
	}

	class UIMATypeObjectMutableTreeNode extends DefaultMutableTreeNode {
		boolean isMouseSelected = false;
		boolean visited = false;
		public static final long serialVersionUID = 0;

		UIMATypeObjectMutableTreeNode(Object o) {
			super(o);
			// if (o instanceof UIMATreeObject) {
			// UIMATreeObject uto = (UIMATreeObject) o;
			// this.toolTipText = uto.name;
			// }
		}

		boolean isSelectedAnnotation() {
			if (UIMATypeSystem.currentTypeSystem != null
					&& UIMATypeSystem.currentTypeSystem.resultJTree != null
					&& this.getUserObject() == UIMATypeSystem.currentTypeSystem.resultJTree.selectedAnnotation) {
				return true;
			}
			return false;
		}

		boolean isLastSelectedAnnotation() {
			if (UIMATypeSystem.currentTypeSystem != null
					&& UIMATypeSystem.currentTypeSystem.resultJTree != null
					&& this.getUserObject() == UIMATypeSystem.currentTypeSystem.resultJTree.lastSelectedAnnotation) {
				return true;
			}
			return false;
		}

		void removeUIMATreeObject() {
			UIMATreeObject uto = resultTree.getSelectedResultObject();
			if (uto != null) {
				if (uto.isAnnotation() && uto.typeSystemParent != null) {
					uto.typeSystemParent.components = VUtils.remove(
							uto.typeSystemParent.components, uto);
					if (UIMATypeSystem.currentTypeSystem.resultJTree.allAnnotations != null) {
						UIMATypeSystem.currentTypeSystem.resultJTree.allAnnotations = VUtils
								.remove(UIMATypeSystem.currentTypeSystem.resultJTree.allAnnotations,
										uto);
					}
					((UIMATreeAnnotation) uto).attributes = null;
					((UIMATreeAnnotation) uto).classifications = null;

				} else if (uto.isFeature()) {
					UIMATreeFeature utf = (UIMATreeFeature) uto;
					UIMATreeAnnotation parent = (UIMATreeAnnotation) uto.uimaParent;
					parent.classifications = VUtils.remove(
							parent.classifications, utf);
					parent.attributes = VUtils.remove(parent.attributes, utf);
				} else if (uto.isRelation()) {
					UIMATreeRelation relation = (UIMATreeRelation) uto;
					UIMATreeAnnotation parent = (UIMATreeAnnotation) uto.uimaParent;
					parent.relations = VUtils
							.remove(parent.relations, relation);
				}
				uto.typeSystemParent = null;
				UIMATypeSystem.currentTypeSystem.resultJTree.reinstantiate();
			}
		}

		public String toString() {
			UIMATreeObject userObject = (UIMATreeObject) this.getUserObject();
			return userObject.getUOS();
		}
	}

	class UIMATypeObjectDefaultTreeModel extends DefaultTreeModel {
		public static final long serialVersionUID = 0;
		public Vector<UIMATypeObjectMutableTreeNode> allNodes = null;

		UIMATypeObjectDefaultTreeModel(UIMATypeObjectMutableTreeNode node) {
			super(node);
		}

		public void valueForPathChanged(TreePath path, Object newValue) {
			System.out.println("ValueForPathChanged");
		}

		void setNodesChanged() {
			if (allNodes != null) {
				for (UIMATypeObjectMutableTreeNode node : treeModel.allNodes) {
					node.isMouseSelected = false;
					treeModel.nodeChanged(node);
				}
			}
		}

		public void insertNodeInto(UIMATypeObjectMutableTreeNode newChild,
				UIMATypeObjectMutableTreeNode parent, int index) {
			super.insertNodeInto((DefaultMutableTreeNode) newChild,
					(DefaultMutableTreeNode) parent, index);
			this.allNodes = VUtils.addIfNot(this.allNodes, newChild);
		}

	}

	class UIMATypeObjectJTree extends JTree {
		public static final long serialVersionUID = 0;
		
		UIMATypeObjectJTree(DefaultTreeModel model) {
			super(model);
			setToolTipText("");
		}

		void expandRows(boolean expand) {
			for (int i = 1; i < this.getRowCount(); i++) {
				if (expand) {
					this.expandRow(i);
				} else {
					this.collapseRow(i);
				}
			}
		}

		public boolean isPathEditable(TreePath path) {
			UIMATypeObjectMutableTreeNode lastElement = (UIMATypeObjectMutableTreeNode) path
					.getLastPathComponent();
			isEditableUIMATreeObject = (UIMATreeObject) lastElement
					.getUserObject();
			return true;
		}

		public String getToolTipText(MouseEvent e) {
			if (lastMouseMovedUIMATreeObject != null) {
				return lastMouseMovedUIMATreeObject.getToolTipText();
			}
			return null;
		}

	}

	class UIMATypeObjectTreeModelListener implements TreeModelListener {

		public void treeNodesChanged(TreeModelEvent e) {
			UIMATypeObjectMutableTreeNode node = (UIMATypeObjectMutableTreeNode) (e
					.getTreePath().getLastPathComponent());
			try {
				int index = e.getChildIndices()[0];
				node = (UIMATypeObjectMutableTreeNode) (node.getChildAt(index));
			} catch (NullPointerException exc) {
			}
		}

		public void treeNodesInserted(TreeModelEvent e) {
		}

		public void treeNodesRemoved(TreeModelEvent e) {
		}

		public void treeStructureChanged(TreeModelEvent e) {
		}
	}

	public class UIMATreeObject {
		UIMATreeObject uimaParent = null;
		UIMATreeAnnotation typeSystemParent = null;
		Object uimaObject = null;
		Vector<UIMATreeFeature> attributes = null;
		public String name = null;
		String longName = null;
		String uimaName = null;
		boolean doDisplay = false;
		boolean usedInResultTree = false;

		public UIMATreeObject() {
		}

		public UIMATreeObject(UIMATreeObject uimaParent, Object uimaObject) {
			this.uimaParent = uimaParent;
			this.uimaObject = uimaObject;
			this.getUOS();
		}

		public String getToolTipText() {
			return this.name;
		}

		void addFeatures(Vector<UIMATreeObject> features) {
			if (features != null) {
				for (UIMATreeObject feature : features) {
					if (feature.usedInResultTree) {
						return;
					}
					if (feature instanceof UIMATreeFeature) {
						UIMATreeFeature tf = (UIMATreeFeature) feature;
						this.attributes = VUtils.addIfNot(this.attributes, tf);
					}
				}
			}
		}

		public UIMATreeAnnotation findParentAnnotation() {
			if (this.isAnnotation()) {
				return (UIMATreeAnnotation) this;
			}
			if (this.uimaParent != null) {
				return this.uimaParent.findParentAnnotation();
			}
			return null;
		}

		public UIMATreeObject getTypeSystemParent() {
			return this.typeSystemParent;
		}

		public void toggleWorkbenchDisplay() {
			if (this.isFeature()) {
				this.doDisplay = !this.doDisplay;
			}
		}

		public String toString() {
			return getUOS();
		}

		String getUOS() {
			if (this.name == null) {
				if (this.uimaObject != null) {
					String str = this.uimaObject.toString();
					this.longName = this.uimaName = this.uimaObject.toString();
					int cindex = str.lastIndexOf(':');
					int pindex = str.lastIndexOf('.');
					if (cindex > 0) {
						str = str.substring(cindex + 1);
					} else if (pindex > 0) {
						str = str.substring(pindex + 1);
					}
					this.name = str;
				} else {
					this.name = this.toString();
				}
			}
			return this.name;
		}

		boolean isAnnotation() {
			return this instanceof UIMATreeAnnotation;
		}

		boolean isFeature() {
			return this instanceof UIMATreeFeature;
		}

		boolean isClassificationFeature() {
			if (this.isFeature()) {
				return this.uimaParent != null
						&& this.uimaParent instanceof UIMATreeAnnotation;
			}
			return false;
		}

		boolean isAttributeFeature() {
			if (this.isFeature()) {
				return this.uimaParent != null
						&& this.uimaParent.uimaObject instanceof String;
			}
			return false;
		}

		boolean isRelation() {
			return this instanceof UIMATreeRelation;
		}

		boolean isResultTreeObject() {
			return isAnnotation() || isFeature();
		}

		boolean isClassificationHeader() {
			return this instanceof UIMATreeAnnotation;
		}

		boolean isAttributeHeader() {
			if (this.uimaObject instanceof String) {
				String str = (String) this.uimaObject;
				return str.indexOf("Attribute") >= 0;
			}
			return false;
		}

		boolean isRelationHeader() {
			if (this.uimaObject instanceof String) {
				String str = (String) this.uimaObject;
				return str.indexOf("Relation") >= 0;
			}
			return false;
		}

		boolean isComponentHeader() {
			if (this.uimaObject instanceof String) {
				String str = (String) this.uimaObject;
				return str.indexOf("Component") >= 0;
			}
			return false;
		}

	}

	public UIMATreeAnnotation getRootAnnotation() {
		return null;
	}

	public void mouseClicked(MouseEvent e) {
	}

	public void mouseExited(MouseEvent e) {
	}

	public void mouseEntered(MouseEvent e) {
	}

	public void mousePressed(MouseEvent e) {
	}

	public void mouseReleased(MouseEvent e) {
	}

	public void mouseDragged(MouseEvent e) {
	}

	public void mouseMoved(MouseEvent e) {
	}

}
