package typesystem;

public class Property extends TypeObject {
	
	String name = null;
	String value = null;
	
	public Property(String name, String value) {
		this.name = name;
		this.value = value;
	}

	public String getName() {
		return name;
	}

	public String getValue() {
		return value;
	}
	

}
