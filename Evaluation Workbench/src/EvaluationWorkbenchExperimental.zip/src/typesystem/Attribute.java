package typesystem;

import java.util.Vector;
import onyx.utilities.VUtils;

public class Attribute extends TypeObject {

	Vector values = null;
	boolean isDisplay = false;

	public Attribute(TypeSystem ts, String id, String name, String uima) {
		super(ts, id, name, uima);
	}
	// SPM 12/16/2011  Add UIMA type system parameter
	public Attribute(TypeSystem ts, String id, String name, String uima, String type) {
		super(ts, id, name, uima, type);
	}
	public void addValue(Object value) {
		this.values = VUtils.addIfNot(this.values, value);
	}

	public Vector getValues() {
		return this.values;
	}

	// 3/1/2012 Test...
	public boolean isDisplay() {
		return isDisplay;
	}
	
	public void setIsDisplay(boolean isDisplay) {
		this.isDisplay = isDisplay;
	}
	
	String toLisp(int depth) {
		StringBuffer sb = new StringBuffer();
		addSpaces(sb, depth);
		sb.append("(\"" + this.name + "\"");
		if (this.isDisplay) {
			sb.append(" (display true)");
		}
		sb.append(")");
		return sb.toString();
	}
	
	public String toString() {
		return this.getName();
	}
	
}
