package typesystem;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.EventObject;
import java.util.Vector;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTree;
import javax.swing.SwingUtilities;
import javax.swing.event.CellEditorListener;
import javax.swing.event.ChangeEvent;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.DefaultTreeCellEditor;
import javax.swing.tree.DefaultTreeCellRenderer;
import javax.swing.tree.TreePath;
import javax.swing.tree.TreeSelectionModel;
import onyx.utilities.VUtils;
import workbench.arr.Colors;

public class UIMAResultJTree extends UIMATypeSystemJTree implements
		MouseListener, TreeSelectionListener, CellEditorListener {

	Vector<UIMATreeObject> selectedResultObjects = null;
	Object currentDefaultEditorValue = null;

	public UIMAResultJTree() {
		rootNode = new UIMATypeObjectMutableTreeNode(new UIMATreeObject(null,
				"                                                            "));
		initialize();
	}

	void initialize() {
		treeModel = new UIMATypeObjectDefaultTreeModel(rootNode);
		treeModel.addTreeModelListener(new UIMATypeObjectTreeModelListener());
		tree = new UIMATypeObjectJTree(treeModel);
		wrapNodes(rootNode);
		tree.setEditable(true);
		tree.getSelectionModel().setSelectionMode(
				TreeSelectionModel.SINGLE_TREE_SELECTION);
		tree.setShowsRootHandles(true);
		tree.addTreeSelectionListener(this);
		tree.addMouseMotionListener(this);
		tree.addMouseListener(this);
		tree.setCellRenderer(new UIMAResultTreeCellRenderer());
		UIMAResultTreeCellEditor treeCellEditor = new UIMAResultTreeCellEditor(
				(JTree) tree, (DefaultTreeCellRenderer) tree.getCellRenderer());
		tree.setCellEditor(treeCellEditor);
		tree.getCellEditor().addCellEditorListener(this);
		JScrollPane scrollPane = new JScrollPane(tree);
		this.removeAll();
		tree.expandRows(true);
		tree.setPreferredSize(new Dimension(400, 500));
		add(scrollPane);
	}

	void wrapNodes(UIMATypeObjectMutableTreeNode pnode) {
		UIMATreeObject userObject = (UIMATreeObject) pnode.getUserObject();
		userObject.usedInResultTree = true;
		if (userObject instanceof UIMATreeAnnotation) {
			UIMATreeAnnotation annotation = (UIMATreeAnnotation) userObject;
			annotation.usedInResultTree = true;
			if (annotation.classifications != null) {
				for (UIMATreeFeature feature : annotation.classifications) {
					feature.usedInResultTree = true;
					UIMATypeObjectMutableTreeNode cfnode = new UIMATypeObjectMutableTreeNode(
							feature);
					treeModel.insertNodeInto(cfnode, pnode,
							pnode.getChildCount());
				}
			}
			UIMATypeObjectMutableTreeNode hnode = new UIMATypeObjectMutableTreeNode(
					new UIMATreeObject(userObject, "<Attributes>"));
			treeModel.insertNodeInto(hnode, pnode, pnode.getChildCount());
			if (annotation.attributes != null) {
				for (UIMATreeFeature feature : new Vector<UIMATreeFeature>(
						annotation.attributes)) {
					feature.usedInResultTree = true;
					UIMATypeObjectMutableTreeNode cfnode = new UIMATypeObjectMutableTreeNode(
							feature);
					treeModel.insertNodeInto(cfnode, hnode,
							hnode.getChildCount());
				}
			}
			hnode = new UIMATypeObjectMutableTreeNode(new UIMATreeObject(
					userObject, "<Relations>"));
			treeModel.insertNodeInto(hnode, pnode, pnode.getChildCount());
			if (annotation.relations != null) {
				for (UIMATreeRelation relation : new Vector<UIMATreeRelation>(
						annotation.relations)) {
					UIMATypeObjectMutableTreeNode rcnode = new UIMATypeObjectMutableTreeNode(
							relation);
					treeModel.insertNodeInto(rcnode, hnode,
							hnode.getChildCount());
				}
			}
			hnode = new UIMATypeObjectMutableTreeNode(new UIMATreeObject(
					userObject, "<Components>"));
			treeModel.insertNodeInto(hnode, pnode, pnode.getChildCount());
			if (annotation.components != null) {
				for (UIMATreeAnnotation cnode : new Vector<UIMATreeAnnotation>(
						annotation.components)) {
					UIMATypeObjectMutableTreeNode ccnode = new UIMATypeObjectMutableTreeNode(
							cnode);
					treeModel.insertNodeInto(ccnode, hnode,
							hnode.getChildCount());
					wrapNodes(ccnode);
				}
			}
		}
	}

	void reinstantiate() {
		UIMATypeObjectDefaultTreeModel model = (UIMATypeObjectDefaultTreeModel) this.treeModel;
		if (model.allNodes != null) {
			for (UIMATypeObjectMutableTreeNode node : model.allNodes) {
				if (node.getUserObject() instanceof UIMATreeObject) {
					UIMATreeObject uto = (UIMATreeObject) node.getUserObject();
					uto.usedInResultTree = false;
				}
				node.removeFromParent();
				node.removeAllChildren();
			}
		}
		model.allNodes = VUtils.listify(this.rootNode);
		UIMATreeAnnotation rootAnnotation = this.getRootAnnotation();
		if (rootAnnotation != null) {
			this.rootNode.setUserObject(rootAnnotation);
			this.wrapNodes(this.rootNode);
		}
		model.reload();
		this.tree.expandRows(true);
	}

	public Vector<UIMATreeObject> getSelectedTypeObjects() {
		return UIMATypeSystem.currentTypeSystem.typeSystemJTree
				.getSelectedTypeObjects();
	}

	public UIMATreeObject getSelectedTypeObject() {
		Vector<UIMATreeObject> objects = getSelectedTypeObjects();
		if (objects != null) {
			return objects.firstElement();
		}
		return null;
	}

	public void valueChanged(TreeSelectionEvent e) {
		TreePath[] paths = tree.getSelectionPaths();
		Vector<UIMATreeObject> objects = null;
		if (paths != null) {
			for (int i = 0; i < paths.length; i++) {
				Object[] nodes = paths[i].getPath();
				UIMATypeObjectMutableTreeNode node = (UIMATypeObjectMutableTreeNode) nodes[nodes.length - 1];
				this.selectedNode = node;
				UIMATreeObject o = (UIMATreeObject) node.getUserObject();
				objects = VUtils.add(objects, o);
			}
		}
		setSelectedResultObjects(objects);
		if (objects != null && objects.size() == 1
				&& objects.firstElement() instanceof UIMATreeAnnotation) {
			setSelectedAnnotation((UIMATreeAnnotation) objects.firstElement());
		}
	}

	public void assignName(String name) {
		if (this.selectedTypeObjects != null) {
			UIMATreeObject object = this.getSelectedTypeObject();
			object.name = name;
		}
	}

	public UIMATreeAnnotation getRootAnnotation() {
		if (this.rootNode.getUserObject() instanceof UIMATreeAnnotation) {
			return (UIMATreeAnnotation) this.rootNode.getUserObject();
		}
		if (this.allAnnotations != null) {
			for (UIMATreeAnnotation annotation : this.allAnnotations) {
				if (annotation.typeSystemParent == null) {
					return annotation;
				}
			}
		}
		return null;
	}

	public String toLisp() {
		UIMATreeAnnotation root = this.getRootAnnotation();
		StringBuffer sb = new StringBuffer();
		if (root != null) {
			sb.append("'");
			sb.append(root.toLisp(0));
		}
		return sb.toString();
	}

	public void assignClassification(Vector<UIMATreeObject> objects) {
		if (getSelectedAnnotation() != null && objects != null) {
			for (UIMATreeObject o : objects) {
				if (!(o.isFeature() && !o.usedInResultTree)) {
					return;
				}
			}
			getSelectedAnnotation().classifications = VUtils.appendIfNot(
					getSelectedAnnotation().classifications, objects);
			for (UIMATreeObject o : objects) {
				UIMATreeFeature f = (UIMATreeFeature) o;
				f.setIsClassification();
			}
		}
	}

	public UIMATreeAnnotation getSelectedAnnotation() {
		return selectedAnnotation;
	}

	public UIMATreeAnnotation getLastSelectedAnnotation() {
		return lastSelectedAnnotation;
	}

	public void setSelectedAnnotation(UIMATreeAnnotation annotation) {
		if (annotation != null && annotation != this.selectedAnnotation) {
			this.lastSelectedAnnotation = this.selectedAnnotation;
			this.selectedAnnotation = annotation;
			// UIMATypeSystem.currentTypeSystem.levelComboBox
			// .displaySelectedLevel();
		}
	}

	public void addAnnotation(UIMATreeAnnotation annotation) {
		if (annotation != null && !annotation.usedInResultTree) {
			if (this.selectedAnnotation != null
					&& !this.selectedAnnotation.equals(annotation)) {
				this.selectedAnnotation.components = VUtils.addIfNot(
						this.selectedAnnotation.components, annotation);
				annotation.typeSystemParent = this.selectedAnnotation;
			}
			this.allAnnotations = VUtils.addIfNot(this.allAnnotations,
					annotation);
			setSelectedAnnotation(annotation);
		}
	}

	private class UIMAResultTreeCellEditor extends DefaultTreeCellEditor {

		public UIMAResultTreeCellEditor(JTree tree,
				DefaultTreeCellRenderer renderer) {
			super(tree, renderer);
		}

		// public UIMAResultTreeCellEditor(JTree tree,
		// DefaultTreeCellRenderer renderer) {
		// super(tree, renderer, null);
		// JTextField tf = new JTextField(1000);
		// UIMATreeObject to = getSelectedResultObject();
		// if (to != null) {
		// tf.setText(to.name);
		// }
		// editingContainer = tf;
		// }

		public Component getTreeCellEditorComponent(JTree tree, Object value,
				boolean isSelected, boolean expanded, boolean leaf, int row) {
			Component comp = super.getTreeCellEditorComponent(tree, value,
					isSelected, expanded, leaf, row);
			UIMATypeSystemJTree.treeCellEditorComponent = comp;
			return comp;
		}

		public Object getCellEditorValue() {
			// JTextField tf = (JTextField) this.editingContainer;
			// System.out.println("getCellEditorValue");
			// UIMATreeObject to = getSelectedResultObject();
			// if (to != null) {
			// to.name = tf.getText();
			// }
			// return currentDefaultEditorValue;
			UIMATreeObject uto = isEditableUIMATreeObject;
			Component comp = UIMATypeSystemJTree.treeCellEditorComponent;
			return uto;
		}

		public boolean isCellEditable(EventObject event) {
			// UIMATreeObject uto = isEditableUIMATreeObject;
			// if (uto != null) {
			// return uto.isAnnotation() || uto.isFeature();
			// }
			return false;
		}
	}

	private class UIMAResultTreeCellRenderer extends DefaultTreeCellRenderer {

		public Component getTreeCellRendererComponent(JTree jtree,
				Object pValue, boolean pIsSelected, boolean pIsExpanded,
				boolean pIsLeaf, int pRow, boolean pHasFocus) {
			UIMATypeObjectMutableTreeNode node = (UIMATypeObjectMutableTreeNode) pValue;
			super.getTreeCellRendererComponent(jtree, pValue, pIsSelected,
					pIsExpanded, pIsLeaf, pRow, pHasFocus);
			UIMATreeObject uo = (UIMATreeObject) node.getUserObject();
			if (node.isSelectedAnnotation()) {
				this.setBackgroundNonSelectionColor(Colors.darkTan);
			} else if (node.isLastSelectedAnnotation()) {
				this.setBackgroundNonSelectionColor(Colors.lightTan);
			} else if (node.isMouseSelected) {
				this.setBackgroundNonSelectionColor(Colors.lightBlueGray);
			} else if (uo.doDisplay) {
				this.setBackgroundNonSelectionColor(Colors.lightTaupe);
				this.setForeground(Color.blue);
			} else {
				this.setBackgroundNonSelectionColor(Color.white);
			}
			if (uo.doDisplay) {
				this.setForeground(Color.black);
			} else {
				this.setForeground(Color.black);
			}
			return (this);
		}
	}

	static Vector<UIMATreeObject> gatherAllObjects(UIMATreeAnnotation annotation) {
		return annotation.gatherAllObjects();
	}

	public class UIMATreeAnnotation extends UIMATreeObject {
		Vector<UIMATreeAnnotation> components = null;
		Vector<UIMATreeFeature> classifications = null;
		Vector<UIMATreeRelation> relations = null;
		public String level = "document";

		public UIMATreeAnnotation(UIMATreeObject uimaParent, Object uimaObject) {
			super(uimaParent, uimaObject);
		}

		public String getToolTipText() {
			return "Name=" + this.name + ",Level=" + this.level;
		}

		Vector<UIMATreeObject> gatherAllObjects() {
			Vector<UIMATreeObject> objects = VUtils.listify(this);
			if (this.components != null) {
				for (UIMATreeAnnotation component : this.components) {
					objects = VUtils.appendIfNot(objects,
							component.gatherAllObjects());
				}
			}
			objects = VUtils.appendIfNot(objects, this.classifications);
			objects = VUtils.appendIfNot(objects, this.attributes);
			return objects;
		}

		public String getLevel() {
			return level;
		}

		public void setLevel(String level) {
			this.level = level;
		}

		String toLisp(int depth) {
			StringBuffer sb = new StringBuffer();
			addSpaces(sb, depth);
			sb.append("(\"" + this.name + "\"");
			addSpaces(sb, depth + 2);
			sb.append("(level \"" + this.level + "\")");
			addSpaces(sb, depth + 2);
			sb.append("(uima \"" + this.uimaName + "\")");
			addSpaces(sb, depth + 2);
			String jclass = levelToWorkbenchMap.get(this.level);
			sb.append("(workbench \"" + jclass + "\")");
			if (this.classifications != null) {
				addSpaces(sb, depth + 2);
				sb.append("(classifications ");
				for (UIMATreeFeature f : this.classifications) {
					sb.append(f.toLisp(depth + 6));
				}
				sb.append(")");
			}
			if (this.attributes != null) {
				addSpaces(sb, depth + 2);
				sb.append("(attributes ");
				for (UIMATreeFeature f : this.attributes) {
					sb.append(f.toLisp(depth + 6));
				}
				sb.append(")");
			}
			if (this.components != null) {
				addSpaces(sb, depth + 2);
				sb.append("(components ");
				for (UIMATreeAnnotation c : this.components) {
					sb.append(c.toLisp(depth + 6));
				}
				sb.append(")");
			}
			if (this.relations != null) {
				addSpaces(sb, depth + 2);
				sb.append("(relations ");
				for (UIMATreeRelation r : this.relations) {
					sb.append(r.toLisp(depth + 6));
				}
				sb.append(")");
			}
			if (this.doDisplay) {
				sb.append(" (display true)");
			}
			sb.append(")");
			return sb.toString();
		}
	}

	public class UIMATreeFeature extends UIMATreeObject {
		boolean isAttribute = true;

		public UIMATreeFeature(UIMATreeObject uimaParent, Object uimaObject) {
			super(uimaParent, uimaObject);
		}

		void setIsAttribute() {
			this.isAttribute = true;
		}

		void setIsClassification() {
			this.isAttribute = false;
		}

		boolean isAttribute() {
			return this.isAttribute;
		}

		boolean isClassification() {
			return !this.isAttribute;
		}

		String toLisp(int depth) {
			StringBuffer sb = new StringBuffer();
			addSpaces(sb, depth);
			sb.append("(\"" + this.name + "\" (uima \"" + this.uimaName + "\")");
			if (this.uimaObject != null
					&& this.uimaObject instanceof org.apache.uima.cas.impl.FeatureImpl) {
				org.apache.uima.cas.impl.FeatureImpl fimpl = (org.apache.uima.cas.impl.FeatureImpl) this.uimaObject;
				String rname = fimpl.getRange().getName();
				sb.append(" (type \"" + rname + "\")");
			}
			if (this.doDisplay) {
				sb.append(" (display true)");
			}
			sb.append(")");
			return sb.toString();
		}
	}

	public void addRelation() {
		UIMATreeAnnotation subject = UIMATypeSystem.currentTypeSystem.resultJTree
				.getSelectedAnnotation();
		UIMATreeAnnotation modifier = UIMATypeSystem.currentTypeSystem.resultJTree
				.getLastSelectedAnnotation();
		if (subject != null && modifier != null && !(subject == modifier)) {
			String rname = JOptionPane.showInputDialog(new JFrame(),
					"Relation Name");
			if (rname != null) {
				UIMATreeRelation relation = new UIMATreeRelation(rname,
						subject, modifier);
				Object vcheck = relation.checkValidity();
				if (vcheck != null) {
					JOptionPane.showMessageDialog(new JFrame(), vcheck);
				} else {
					relation.subject.relations = VUtils.add(subject.relations,
							relation);
					reinstantiate();
				}
			}
		}
	}

	public class UIMATreeRelation extends UIMATreeObject {
		String relName = null;
		UIMATreeAnnotation subject = null;
		UIMATreeAnnotation modifier = null;

		public UIMATreeRelation(String relname, UIMATreeAnnotation subject,
				UIMATreeAnnotation modifier) {
			this.relName = relname;
			this.subject = subject;
			this.modifier = modifier;
			this.uimaParent = subject;
		}

		String toLisp(int depth) {
			StringBuffer sb = new StringBuffer();
			addSpaces(sb, depth);
			sb.append("(\"" + this.relName + "\" \"" + this.subject + "\" \""
					+ this.modifier + "\")");
			return sb.toString();
		}

		public String toString() {
			String str = "<\"" + this.relName + "\" \"" + this.subject + " \""
					+ this.modifier + "\">";
			return str;
		}

		public Object checkValidity() {
			if (this.subject == this.modifier
					|| !(subject instanceof UIMATreeAnnotation)
					|| !(modifier instanceof UIMATreeAnnotation)) {
				return "Relational arguments must be different classifications";
			}
			if (this.subject.relations != null) {
				for (UIMATreeRelation relation : this.subject.relations) {
					if (relation.relName.equals(this.relName)) {
						return "Duplicate relation";
					}
				}
			}
			return null;
		}
	}

	public void setSelectedResultObjects(Vector<UIMATreeObject> selectedObjects) {
		this.selectedResultObjects = selectedObjects;
	}
	
	public void setSelectedResultObject(UIMATreeObject selectedObject) {
		this.selectedResultObjects = VUtils.listify(selectedObject);
	}

	public Vector<UIMATreeObject> getSelectedResultObjects() {
		return this.selectedResultObjects;
	}

	public UIMATreeObject getSelectedResultObject() {
		if (this.selectedResultObjects != null) {
			return this.selectedResultObjects.firstElement();
		}
		return null;
	}

	void addSpaces(StringBuffer sb, int num) {
		sb.append("\n");
		for (int i = 0; i < num; i++) {
			sb.append(' ');
		}
	}

	public void setNodeName(String name) {
		if (this.isResultTree() && this.getSelectedResultObject() != null
				&& name != null) {
			UIMATreeObject object = this.getSelectedResultObject();
			object.name = name;
		}
	}

	String checkErrors() {
		if (this.allAnnotations != null) {
			Vector<UIMATreeObject> objects = this.getRootAnnotation()
					.gatherAllObjects();
			Vector<String> names = VUtils.gatherFields(objects, "name");
			if (VUtils.containsDuplicates(names)) {
				return "Contains duplicate object names" + names;
			}
			Vector<String> levels = VUtils.gatherFields(this.allAnnotations,
					"level");
			if (VUtils.containsDuplicates(levels)) {
				return "Contains duplicate Level(s)";
			}
			for (UIMATreeAnnotation annotation : this.allAnnotations) {
				if (annotation.uimaParent != null
						&& annotation.uimaParent instanceof UIMATreeAnnotation) {
					UIMATreeAnnotation parent = (UIMATreeAnnotation) annotation.uimaParent;
					if (annotation.getLevel() != null
							&& annotation.getLevel().equals(parent.getLevel())) {
						return "Duplicate level(s)";
					}
				}
				if (annotation.classifications != null) {
					for (UIMATreeFeature classification : annotation.classifications) {
						boolean doDisplay = false;
						if (doDisplay && classification.doDisplay) {
							return "More than one visible classification property";
						}
						doDisplay = true;
					}
				}
			}
		}
		return null;
	}

	public void mouseMoved(MouseEvent e) {
		lastMouseMovedUIMATreeObject = null;
		TreePath path = tree.getPathForLocation(e.getX(), e.getY());
		UIMATypeObjectMutableTreeNode pnode = null;
		UIMATreeObject uto = null;
		if (path != null) {
			Object lastElement = path.getLastPathComponent();
			pnode = (UIMATypeObjectMutableTreeNode) lastElement;
			if (pnode.getUserObject() instanceof UIMATreeObject) {
				uto = (UIMATreeObject) pnode.getUserObject();
				lastMouseMovedUIMATreeObject = uto;
			}
			if (e.isControlDown()) {
				if (path != null && !path.equals(this.lastTreePath)) {
					this.lastTreePath = path;
					if (tree.isPathSelected(path)) {
						tree.removeSelectionPath(path);
					} else {
						if (uto != null) {
							setSelectedResultObjects(VUtils.listify(uto));
							UIMATreeAnnotation parent = uto
									.findParentAnnotation();
							if (parent != null) {
								setSelectedAnnotation(parent);
							}
							treeModel.setNodesChanged();
							pnode.isMouseSelected = true;
						}
					}
				}
			}
		}
	}

	public void mousePressed(MouseEvent e) {
		TreePath path = tree.getPathForLocation(e.getX(), e.getY());
		if (path != null) {
			UIMATypeObjectMutableTreeNode lastElement = selectedNode = (UIMATypeObjectMutableTreeNode) path
					.getLastPathComponent();
			UIMATreeObject o = (UIMATreeObject) lastElement.getUserObject();
			if (this.getSelectedTypeObjects() != null) {
				if (e.isControlDown()) {
					if (o.isClassificationHeader()
							&& getSelectedTypeObjects() != null) {
						this.assignClassification(getSelectedTypeObjects());
						reinstantiate();
					} else if (o.isAttributeHeader()
							&& getSelectedAnnotation() != null
							&& getSelectedTypeObjects() != null) {
						getSelectedAnnotation().addFeatures(
								getSelectedTypeObjects());
						reinstantiate();
					} else if (o.isRelationHeader()) {
						addRelation();
					} else if (o.isComponentHeader()
							&& getSelectedAnnotation() != null
							&& getSelectedTypeObject().isAnnotation()) {
						addAnnotation((UIMATreeAnnotation) getSelectedTypeObject());
						reinstantiate();
					}
				} else if (e.isAltDown()) {
					setSelectedResultObject(o);
					Point point = new Point(e.getPoint());
					SwingUtilities.convertPointToScreen(point, this);
					JFrame frame = new JFrame();
					JPanel pane = null;
					if (o instanceof UIMATreeAnnotation) {
						UIMATreeAnnotation annotation = (UIMATreeAnnotation) o;
						pane = new AnnotationEditPane(frame, point, annotation);
					} else if (o.isClassificationFeature()) {
						UIMATreeFeature feature = (UIMATreeFeature) o;
						pane = new ClassificationEditPane(frame, point, feature);
					} else if (o.isAttributeFeature()) {
						UIMATreeFeature feature = (UIMATreeFeature) o;
						pane = new AttributeEditPane(frame, point, feature);
					}
					if (pane != null) {
						frame.setContentPane(pane);
						frame.pack();
						frame.setVisible(true);
					}
				}
			}
		}
	}

	public void editingStopped(ChangeEvent e) {
		Object o = e.getSource();
		System.out.println("A cell has been edited.");
	}

	public void editingCanceled(ChangeEvent e) {
		System.out.println("Editing of a cell has been canceled.");
	}

	class UIMATypeSystemComboBox extends JComboBox {
		public static final long serialVersionUID = 0;

		JComponent container = null;

		public UIMATypeSystemComboBox() {
		}

		public UIMATypeSystemComboBox(JComponent container) {
			this.container = container;
			setPreferredSize(new Dimension(150, 20));
			for (int i = 0; i < levels.length; i++) {
				addItem(levels[i]);
			}
			setSelectedItem(levels[0]);
			this.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					comboBoxActionPerformed(e);
				}
			});
		}

		public String toString() {
			Object o = getSelectedItem();
			return o.toString();
		}

		protected void comboBoxActionPerformed(ActionEvent e) {
			if ("comboBoxChanged".equals(e.getActionCommand())) {
				UIMATypeSystemComboBox cb = (UIMATypeSystemComboBox) e
						.getSource();
				String lstr = (String) cb.getSelectedItem();
				if (getSelectedAnnotation() != null) {
					getSelectedAnnotation().setLevel(lstr.toLowerCase());
					selectedLevel = lstr;
				}
			}
		}

		void displaySelectedLevel() {
			if (getSelectedAnnotation() != null) {
				String lstr = getSelectedAnnotation().level;
				getSelectedAnnotation().setLevel(lstr.toLowerCase());
				selectedLevel = lstr;
				UIMATypeSystem.currentTypeSystem.levelComboBox
						.setSelectedItem(lstr);
				UIMATypeSystem.currentTypeSystem.levelComboBox
						.selectedItemChanged();
			}
		}
	}

}
