package typesystem;

import java.awt.BorderLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Properties;
import java.util.Vector;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import onyx.utilities.FUtils;

import org.apache.uima.UIMAException;
import org.apache.uima.jcas.JCas;
import org.apache.uima.resource.metadata.TypeSystemDescription;
import org.uimafit.factory.JCasFactory;
import org.uimafit.factory.TypeSystemDescriptionFactory;

import typesystem.UIMAResultJTree.UIMATreeAnnotation;
import typesystem.UIMAResultJTree.UIMATypeSystemComboBox;
import typesystem.UIMATypeSystemJTree.UIMATreeObject;

public class UIMATypeSystem extends JPanel implements ActionListener {
	UIMATypeSystemJTree typeSystemJTree = null;
	UIMAResultJTree resultJTree = null;
	JFrame frame = new JFrame();
	String selectedLevel = "document";
	File directory = null;
	String outfileName = null;
	boolean rowsExpanded = true;
	UIMATreeObject selectedParent = null;
	UIMATypeSystemComboBox levelComboBox = null;

	static String[] commands = { "Add Annotation", "Remove", "Open/Close Folders",
			"Write Output File" };
	static UIMATypeSystem currentTypeSystem = null;

	public static void main(String[] args) {
		try {
			Properties properties = new Properties();
			InputStream is = null;
			try {
				is = UIMATypeSystem.class
						.getResourceAsStream("/startup.properties");
				if (is == null) {
					is = new FileInputStream("./startup.properties");
				}
				if (is != null) {
					properties.load(is);
				}
			} catch (Exception e) {

			}
			String filename = (String) properties.get("UIMATypeSystem");
			String outfile = (String) properties.get("WorkbenchTypeSystem");
			File directory = null;
			File file = null;
			if (filename == null) {
				file = FUtils.chooseFile(null);
			} else {
				file = new File(filename);
			}
			if (file != null && file.exists()) {
				directory = file.getParentFile();
			}
			if (directory == null) {
				JOptionPane.showMessageDialog(new JFrame(),
						"Unable to find UIMA type system description file");
				System.exit(-1);
			}
			if (file != null && file.exists()) {
				TypeSystemDescription tsd = TypeSystemDescriptionFactory
				// SPM 12/12/2011 Universally handle paths
						.createTypeSystemDescriptionFromPath(file
								.getAbsoluteFile().toURI().toString());
				// .getAbsolutePath());
				JCas jcas = JCasFactory.createJCas(tsd);
				new UIMATypeSystem(jcas, directory, outfile);
			} else {
				System.exit(0);
			}
		} catch (UIMAException e) {
			e.printStackTrace();
		}
	}

	public UIMATypeSystem(JCas jcas, File directory, String outfile) {
		currentTypeSystem = this;
		this.directory = directory;
		this.outfileName = outfile;
		this.setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();
		this.frame.setContentPane(this);
		resultJTree = new UIMAResultJTree();
		typeSystemJTree = new UIMATypeSystemJTree(jcas);
		JPanel rpanel = new JPanel(new BorderLayout());
		rpanel.add(new JLabel("Workbench Types"), BorderLayout.PAGE_START);
		rpanel.add(resultJTree, BorderLayout.PAGE_END);
		JPanel buttonpanel = new JPanel(new GridLayout(0, 1));
		// levelComboBox = resultJTree.new UIMATypeSystemComboBox(this);
		// buttonpanel.add(new JLabel("Annotation Level:"));
		// buttonpanel.add(levelComboBox);
		// buttonpanel.add(new JSeparator(SwingConstants.VERTICAL));
		// buttonpanel.add(new JLabel("Functions:"));
		for (int i = 0; i < commands.length; i++) {
			JButton button = new JButton(commands[i]);
			button.setActionCommand(commands[i]);
			button.addActionListener(this);
			buttonpanel.add(button);
		}

		BorderLayout bl = new BorderLayout();
		JPanel upanel = new JPanel(bl);
		upanel.add(new JLabel("UIMA Types"), BorderLayout.PAGE_START);
		upanel.add(typeSystemJTree, BorderLayout.PAGE_END);

		c.gridx = 0;
		c.gridy = 0;
		c.weightx = 0.90;
		add(upanel, c);
		c.gridx = 1;
		c.weightx = 0.10;
		add(rpanel, c);

		c.gridx = 2;
		add(buttonpanel, c);

		this.frame.setContentPane(this);
		this.frame.pack();
		this.frame.setVisible(true);
	}

	public void actionPerformed(ActionEvent e) {
		String command = e.getActionCommand();
		Vector<UIMATreeObject> objects = typeSystemJTree
				.getSelectedTypeObjects();
		if (objects != null) {
			UIMATreeObject object = objects.firstElement();
			if ("Add Annotation".equals(command)
					&& object instanceof UIMATreeAnnotation) {
				resultJTree.addAnnotation((UIMATreeAnnotation) object);
				resultJTree.reinstantiate();
			} else if ("Add Attributes".equals(command)
					&& resultJTree.getSelectedAnnotation() != null) {
				resultJTree.getSelectedAnnotation().addFeatures(objects);
				resultJTree.reinstantiate();
			} else if ("Add Relation".equals(command)) {
				resultJTree.addRelation();
			} else if ("Add Classification Names".equals(command)) {
				resultJTree.assignClassification(objects);
				resultJTree.reinstantiate();
			} else if ("Show Attribute In Workbench".equals(command)) {
				UIMATreeObject robject = resultJTree.getSelectedResultObject();
				if (robject != null) {
					robject.toggleWorkbenchDisplay();
					this.resultJTree.treeModel.setNodesChanged();
				}
			} else if ("Remove".equals(command)) {
				if (resultJTree.selectedNode != null) {
					resultJTree.selectedNode.removeUIMATreeObject();
				}
			} else if ("Change Name".equals(command)) {
				UIMATreeObject o = resultJTree.getSelectedResultObject();
				String str = "";
				if (o != null) {
					str = o.getUOS();
				}
				String name = JOptionPane.showInputDialog("New Name:", str);
				if (name != null && name.length() > 3) {
					resultJTree.setNodeName(name);
					resultJTree.reinstantiate();
				}
			} else if ("Write Output File".equals(command)) {
				String error = resultJTree.checkErrors();
				if (error != null) {
					JOptionPane.showMessageDialog(new JFrame(), error);
				} else {
					if (this.outfileName == null) {
						String fname = JOptionPane
								.showInputDialog("Output File:");
						if (fname != null && fname.length() > 3) {
							this.outfileName = directory.getAbsolutePath()
									+ File.separatorChar + fname;
						}
					}
					if (this.outfileName != null) {
						String str = resultJTree.toLisp();
						FUtils.writeFile(this.outfileName, str);
						JOptionPane.showMessageDialog(new JFrame(), "Wrote: "
								+ this.outfileName);
					} else {
						JOptionPane.showMessageDialog(new JFrame(),
								"Unable to write file.");
					}
				}
			} else if ("Open/Close Folders".equals(command)) {
				this.rowsExpanded = !this.rowsExpanded;
				typeSystemJTree.tree.expandRows(this.rowsExpanded);
			}
		}
	}

}
