package typesystem;

import java.io.File;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.List;
import java.util.ListIterator;
import java.util.Vector;

import onyx.jlisp.JLUtils;
import onyx.jlisp.JLisp;
import onyx.jlisp.Sexp;

import org.jdom.Element;
import org.jdom.input.SAXBuilder;

import onyx.utilities.VUtils;

public class TypeSystem {

	int typeObjectCount = 0;
	Hashtable<String, TypeObject> typeObjectIDHash = new Hashtable();
	Vector<TypeObject> allTypeObjects = null;
	int rowNumber = 0;
	Hashtable<org.apache.uima.jcas.tcas.Annotation, org.apache.uima.jcas.tcas.Annotation> parentChildAnnotationHash = new Hashtable();
	Vector<org.apache.uima.jcas.tcas.Annotation> allUIMAAnnotations = null;
	Hashtable workbenchAnnotationJavaClassMap = new Hashtable();
	static TypeSystem currentTypeSystem = null;
	static String typeSystemFilename = null;
	static String typeSystemLispFilename = null;
	static String defaultTypeSystemFilename = typeSystemLispFilename;

	public static void createTypeSystem(String filename) {
		if (currentTypeSystem == null) {
			typeSystemFilename = filename;
			currentTypeSystem = new TypeSystem();
			if (filename != null) {
				String lcfilename = filename.toLowerCase();
				if (lcfilename.indexOf("lisp") >= 0) {
					currentTypeSystem.readLisp(filename);
				} else {
					currentTypeSystem.readXML(filename);
				}
			}
		}
	}

	public static TypeSystem getTypeSystem(String filename) {
		createTypeSystem(filename);
		return currentTypeSystem;
	}

	public static TypeSystem getTypeSystem() {
		return getTypeSystem(typeSystemFilename);
	}

	public void storeChildParentUIMAAnnotations(
			org.apache.uima.jcas.tcas.Annotation parent,
			org.apache.uima.jcas.tcas.Annotation child) {
		this.allUIMAAnnotations = VUtils.add(this.allUIMAAnnotations, parent);
		this.allUIMAAnnotations = VUtils.add(this.allUIMAAnnotations, child);
		this.parentChildAnnotationHash.put(child, parent);
	}

	public static void addTypeObjectByID(TypeObject to) {
		TypeSystem ts = getTypeSystem();
		ts.typeObjectIDHash.put(to.getId(), to);
		ts.typeObjectIDHash.put(to.getName(), to);
		if (to instanceof Annotation) {
			Annotation annotation = (Annotation) to;
			ts.typeObjectIDHash.put(annotation.javaClass.getSimpleName(), to);
		}
		if (to.getUima() != null) {
			ts.typeObjectIDHash.put(to.getUima(), to);
		}
	}

	public static void addTypeObjectByUima(TypeObject to) {
		if (to.getUima() != null && to.getParentUIMA() != null) {
			TypeSystem ts = getTypeSystem();
			String key = to.getParentUIMA() + "=" + to.getUima();
			ts.typeObjectIDHash.put(key, to);
		}
	}

	// SPM 12/16/2011 Prevents loop over static components in TypeObject
	public static void removeChildComponent(TypeObject to) {
		to.clearComponentChild();
	}

	public static org.apache.uima.jcas.tcas.Annotation getParentUIMAAnnotation(
			org.apache.uima.jcas.tcas.Annotation child) {
		return getTypeSystem().parentChildAnnotationHash.get(child);
	}

	public void clearUIMAAnnotations() {
		this.parentChildAnnotationHash.clear();
		this.allUIMAAnnotations = null;
	}

	void readLisp(String filename) {
		try {
			JLisp jlisp = JLisp.getJLisp();
			Sexp sexp = (Sexp) jlisp.loadFile(filename);
			Vector v = JLUtils.toVector(sexp, true);
			readLispAnnotation(v, null);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	void readLispAnnotation(Vector v, Annotation parent) {
		try {
			String name = v.firstElement().toString();
			String uima = (String) VUtils.assocValueTopLevel("uima", v);
			String workbench = (String) VUtils.assocValueTopLevel("workbench",
					v);
			Class c = null;
			if (workbench != null) {
				String fname = "annotation." + workbench;
				c = Class.forName(fname);
				workbenchAnnotationJavaClassMap.put(c, workbench);
				workbenchAnnotationJavaClassMap.put(workbench, c);
			}
			Annotation annotation = new Annotation(this, name, name, c, uima);
			TypeSystem.addTypeObjectByID(annotation);
			if (parent != null) {
				annotation.setParent(parent);
				parent.addComponent(annotation);
			}
			Vector rv = VUtils.assocTopLevel("classifications", v);
			if (rv != null) {
				readLispClassification(rv, annotation);
			}
			rv = VUtils.assocTopLevel("attributes", v);
			if (rv != null) {
				Vector<Vector> attributes = VUtils.rest(rv);
				for (Vector av : attributes) {
					readLispAttribute(av, annotation);
				}
			}
			rv = VUtils.assocTopLevel("components", v);
			if (rv != null) {
				Vector<Vector> components = VUtils.rest(rv);
				for (Vector cv : components) {
					readLispAnnotation(cv, annotation);
				}
			}
			// 3/13/2012
			rv = VUtils.assocTopLevel("relations", v);
			if (rv != null) {
				Vector<Vector> relations = VUtils.rest(rv);
				for (Vector cv : relations) {
					String rname = (String) cv.elementAt(0);
					String rid = (String) cv.elementAt(2);
					TypeObject relatum = this.getUimaAnnotation(rid);
					if (relatum instanceof Classification) {
						relatum = ((Classification) relatum).parent;
					}
					annotation.addRelation(rname, (Annotation) relatum);
				}
			}
			TypeSystem.addTypeObjectByUima(annotation);
			// SPM 12/16/2011
			TypeSystem.removeChildComponent(annotation);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

	// 3-1-2012
	void readLispClassification(Vector<Vector> v, TypeObject parent) {
		String uima = (String) VUtils.assocValueTopLevel("uima", v);
		String cname = parent.getName();
		Classification classification = new Classification(this, cname, cname,
				uima);
		classification.setParent(parent);
		parent.setClassification(classification);
		TypeSystem.addTypeObjectByID(classification);
		for (Enumeration e = VUtils.rest(v).elements(); e.hasMoreElements();) {
			Vector av = (Vector) e.nextElement();
			readLispAttribute(av, classification);
		}
		TypeSystem.addTypeObjectByUima(classification);
	}

	void readLispAttribute(Vector v, TypeObject parent) {
		String name = v.firstElement().toString();
		String uima = (String) VUtils.assocValueTopLevel("uima", v);
		// SPM 12/16/2011 Add UIMA type system parameter
		String uimatype = (String) VUtils.assocValueTopLevel("type", v);
		// Attribute attribute = new Attribute(this, name, uima, uima,
		// uimatype);// change name to uima for lookup
		// Lee changed back...
		Attribute attribute = new Attribute(this, name, name, uima, uimatype);
		if ("true".equals(VUtils.assocValueTopLevel("display", v))) {
			attribute.isDisplay = true;
		}
		attribute.setParent(parent);
		parent.addAttribute(attribute);
		TypeSystem.addTypeObjectByID(attribute);
		TypeSystem.addTypeObjectByUima(attribute);
	}

	void readXML(String filename) {
		try {
			org.jdom.Document jdoc = new SAXBuilder().build(new File(filename));
			Element root = jdoc.getRootElement();
			List l = root.getChildren("node");
			for (ListIterator li = l.listIterator(); li.hasNext();) {
				Element node = (Element) li.next();
				String id = node.getAttributeValue("id");
				String type = node.getAttributeValue("type");
				String name = node.getAttributeValue("name");
				String uima = node.getAttributeValue("uima");
				TypeObject typeObject = null;
				if ("annotation".equals(type)) {
					String cname = node.getAttributeValue("workbench");
					Class c = null;
					if (cname != null) {
						cname = "annotation." + cname;
						c = Class.forName(cname);
					}
					typeObject = new Annotation(this, id, name, c, uima);
				} else if ("classification".equals(type)) {
					typeObject = new Classification(this, id, name, uima);
				} else if ("attribute".equals(type)) {
					typeObject = new Attribute(this, id, name, uima);
				}
				TypeSystem.addTypeObjectByID(typeObject);
			}
			l = root.getChildren("edge");
			for (ListIterator i = l.listIterator(); i.hasNext();) {
				Element edge = (Element) i.next();
				String fromID = edge.getAttributeValue("from");
				String toID = edge.getAttributeValue("to");
				TypeObject from = getTypeObject(fromID);
				TypeObject to = getTypeObject(toID);
				to.setParent(from);
				if (to instanceof Classification) {
					from.setClassification((Classification) to);
				} else if (to instanceof Attribute) {
					from.addAttribute((Attribute) to);
				} else if (to instanceof Annotation) {
					from.addComponent((Annotation) to);
				}
				TypeSystem.addTypeObjectByUima(to);
			}
			assignRowNumbers();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	void assignRowNumbers() {
		rowNumber = 0;
		getRoot().assignRowNumber();
	}

	public Vector<TypeObject> getAllTypeObjects() {
		return new Vector(typeObjectIDHash.entrySet());
	}

	public Annotation getUimaAnnotation(String name) {
		return (Annotation) typeObjectIDHash.get(name);
	}

	public Attribute getUimaAttribute(String aname, String atname) {
		String key = aname + "=" + atname;
		return getUimaAttribute(key);
	}

	public Attribute getUimaAttribute(String key) {
		TypeObject to = typeObjectIDHash.get(key);
		if (to instanceof Attribute) {
			return (Attribute) to;
		}
		return null;
	}

	public Classification getUimaClassification(String aname, String cname) {
		String key = aname + "=" + cname;
		return getUimaClassification(key);
	}

	public Classification getUimaClassification(String key) {
		TypeObject to = typeObjectIDHash.get(key);
		if (to instanceof Attribute && to.getParent() != null
				&& to.getParent() instanceof Classification) {
			return (Classification) to.getParent();
		}
		if (to instanceof Classification) {
			return (Classification) to;
		}
		return null;
	}

	public TypeObject getRoot() {
		for (Enumeration<TypeObject> e = typeObjectIDHash.elements(); e
				.hasMoreElements();) {
			TypeObject to = e.nextElement();
			// 3/16/2012 -- Added test for Annotation
			if (to instanceof Annotation && to.getParent() == null) {
				return to;
			}
		}
		return null;
	}

	public TypeObject getTypeObject(String id) {
		return typeObjectIDHash.get(id);
	}

	public int getTypeObjectCount() {
		return typeObjectCount;
	}

	public Class mapAnnotationTypeToJavaClass(String annotationType) {
		return (Class) workbenchAnnotationJavaClassMap.get(annotationType);
	}

	public String mapJavaClassToAnnotationType(Class c) {
		return (String) workbenchAnnotationJavaClassMap.get(c);
	}

}
