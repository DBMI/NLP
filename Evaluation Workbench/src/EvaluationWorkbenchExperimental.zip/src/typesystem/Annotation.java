package typesystem;

import java.lang.reflect.Constructor;
import java.util.Hashtable;
import java.util.Vector;

import onyx.utilities.VUtils;

import annotation.EVAnnotation;

public class Annotation extends TypeObject {

	Class javaClass = null;
	Constructor constructor = null;
	Vector<Classification> classifications = null;
	Vector<Attribute> attributes = null;
	Vector<Annotation> components = null;
	String level = null;
	// 3/13/2012
	Hashtable<String, Vector<Annotation>> relationHash = new Hashtable();
	static Hashtable<Class, Annotation> classAnnotationHash = new Hashtable();
	

	public Annotation(TypeSystem ts, String name, Class c, String uima) {
		super(ts, name, uima);
		this.javaClass = c;
		if (c != null) {
			try {
				Class constructorClass = Class.forName(c.getName());
				this.constructor = constructorClass.getConstructor();
				classAnnotationHash.put(c, this);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	public Annotation(TypeSystem ts, String id, String name, Class c,
			String uima) {
		super(ts, id, name, uima);
		this.javaClass = c;
		if (c != null) {
			try {
				Class constructorClass = Class.forName(c.getName());
				this.constructor = constructorClass.getConstructor();
				classAnnotationHash.put(c, this);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	public EVAnnotation createEVAnnotation(TypeObject type) {
		EVAnnotation ev = null;
		try {
			ev = (EVAnnotation) this.constructor.newInstance();
			ev.setType(type);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return ev;
	}

	public static Annotation getAnnotationByClass(Class c) {
		return classAnnotationHash.get(c);
	}

	public Class getAnnotationClass() {
		return javaClass;
	}

	public void setAnnotationClass(Class c) {
		this.javaClass = c;
	}

	/*******/
	public Vector<Classification> getClassifications() {
		return classifications;
	}

	public Classification getFirstClassification() {
		if (classifications != null) {
			return classifications.firstElement();
		}
		return null;
	}

	public void setClassification(Classification classification) {
		this.classifications = VUtils.add(this.classifications, classification);
	}

	public Vector<Attribute> getAttributes() {
		return attributes;
	}

	public void setAttributes(Vector<Attribute> attributes) {
		this.attributes = attributes;
	}

	public Vector<Annotation> getComponents() {
		return components;
	}

	public void addComponent(Annotation component) {
		this.components = VUtils.add(this.components, component);
	}

	public boolean hasComponents() {
		return this.components != null;
	}

	public void addAttribute(Attribute attribute) {
		this.attributes = VUtils.add(this.attributes, attribute);
	}

	public Object getValue(String name) {
		return VUtils.findIfMatchingField(attributes, "name", name);
	}

	public Attribute getAttribute(String aname) {
		if (this.attributes != null) {
			for (Attribute attribute : this.attributes) {
				if (aname.equalsIgnoreCase(attribute.getName())
						|| (attribute.getShortUima() != null && aname
								.equalsIgnoreCase(attribute.getShortUima()))
						|| (attribute.getUima() != null && aname
								.equalsIgnoreCase(attribute.getUima()))) {
					return attribute;
				}
			}
		}
		return null;
	}
	
	// 3/13/2012
	public Vector<Annotation> getRelata(String rname) {
		return this.relationHash.get(rname);
	}
	
	public void addRelation(String rname, Annotation relatum) {
		VUtils.pushIfNotHashVector(this.relationHash, rname, relatum);
	}
	
	public Vector<String> getRelations() {
		return new Vector(this.relationHash.keySet());
	}

	public Vector<TypeObject> getChildren() {
		Vector<TypeObject> children = null;
		children = VUtils.append(children, this.getClassifications());
		children = VUtils.append(children, this.getAttributes());
		children = VUtils.append(children, this.getComponents());
		return children;
	}
	
	public void setLevel(String level) {
		this.level = level;
	}
	
	public String getLevel() {
		return this.level;
	}
	
	public String toLisp(int depth) {
		StringBuffer sb = new StringBuffer();
		addSpaces(sb, depth);
		sb.append("(\"" + this.name + "\"");
		addSpaces(sb, depth + 2);
		sb.append("(level \"" + this.level + "\")");
		addSpaces(sb, depth + 2);
		String jclass = UIMATypeSystemJTree.levelToWorkbenchMap.get(this.level);
		sb.append("(workbench \"" + jclass + "\")");
		if (this.classifications != null) {
			addSpaces(sb, depth + 2);
			sb.append("(classifications ");
			for (Classification c : this.classifications) {
				sb.append(c.toLisp(depth + 6));
			}
			sb.append(")");
		}
		if (this.attributes != null) {
			addSpaces(sb, depth + 2);
			sb.append("(attributes ");
			for (Attribute a : this.attributes) {
				sb.append(a.toLisp(depth + 6));
			}
			sb.append(")");
		}
		if (this.components != null) {
			addSpaces(sb, depth + 2);
			sb.append("(components ");
			for (Annotation a : this.components) {
				sb.append(a.toLisp(depth + 6));
			}
			sb.append(")");
		}
		sb.append(")");
		return sb.toString();
	}

}
