package typesystem;

public class Relation extends TypeObject {

	TypeObject subject = null;
	TypeObject modifier = null;

	public Relation(TypeSystem ts, String name, TypeObject subject,
			TypeObject modifier) {
		super(ts, name);
		this.subject = subject;
		this.modifier = modifier;
	}

}
