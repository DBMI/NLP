package typesystem;

import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;
import java.util.Vector;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTree;
import javax.swing.event.TreeModelEvent;
import javax.swing.event.TreeModelListener;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreePath;
import javax.swing.tree.TreeSelectionModel;
import onyx.utilities.VUtils;
import typesystem.UIMAResultJTree.UIMATreeAnnotation;
import typesystem.UIMATypeSystemJTree.UIMATreeObject;

public class UIMARelationJTree extends JPanel implements TreeSelectionListener,
		MouseMotionListener {
	RelationJTree tree = null;
	UIMARelationMutableTreeNode rootNode = null;
	UIMARelationTreeModel treeModel = null;
	Vector<UIMATreeRelation> allRelations = null;
	UIMATreeRelation selectedRelation = null;

	public UIMARelationJTree() {
		rootNode = new UIMARelationMutableTreeNode(
				new UIMARelationMutableTreeNode("                                    "));
		treeModel = new UIMARelationTreeModel(rootNode);
		treeModel.addTreeModelListener(new UIMARelationTreeModelListener());
		tree = new RelationJTree(treeModel);
		wrapNodes();
		tree.setEditable(true);
		tree.getSelectionModel().setSelectionMode(
				TreeSelectionModel.SINGLE_TREE_SELECTION);
		tree.setShowsRootHandles(true);
		tree.addTreeSelectionListener(this);
		tree.addMouseMotionListener(this);
		JScrollPane scrollPane = new JScrollPane(tree);
		this.removeAll();
		add(scrollPane);
	}

	void wrapNodes() {
		if (allRelations != null) {
			for (UIMATreeRelation relation : allRelations) {
				UIMARelationMutableTreeNode rnode = new UIMARelationMutableTreeNode(
						relation.getRelationName());
				treeModel.insertNodeInto(rnode, this.rootNode,
						this.rootNode.getChildCount());
				UIMARelationMutableTreeNode snode = new UIMARelationMutableTreeNode(
						relation.getSubject());
				treeModel.insertNodeInto(snode, rnode, rnode.getChildCount());
				UIMARelationMutableTreeNode mnode = new UIMARelationMutableTreeNode(
						relation.getModifier());
				treeModel.insertNodeInto(mnode, rnode, rnode.getChildCount());
			}
		}
	}

	void reinstantiate() {
		UIMARelationTreeModel model = (UIMARelationTreeModel) this.treeModel;
		if (model.allNodes != null) {
			for (UIMARelationMutableTreeNode node : model.allNodes) {
				node.removeFromParent();
				node.removeAllChildren();
			}
		}
		model.allNodes = VUtils.listify(this.rootNode);
		this.wrapNodes();
		model.reload();
	}

	public void valueChanged(TreeSelectionEvent e) {
		TreePath[] paths = tree.getSelectionPaths();
		if (paths != null) {
			Object[] nodes = paths[0].getPath();
			UIMARelationMutableTreeNode node = (UIMARelationMutableTreeNode) nodes[0];
			Object o = node.getUserObject();
			if (o instanceof UIMATreeRelation) {
				this.selectedRelation = (UIMATreeRelation) o;
			}
		}
	}

	class RelationJTree extends JTree {
		public static final long serialVersionUID = 0;

		RelationJTree(DefaultTreeModel model) {
			super(model);
		}
	}

	class UIMARelationTreeModel extends DefaultTreeModel {
		public static final long serialVersionUID = 0;
		Vector<UIMARelationMutableTreeNode> allNodes = null;

		UIMARelationTreeModel(DefaultMutableTreeNode node) {
			super(node);
		}

		public void insertNodeInto(UIMARelationMutableTreeNode newChild,
				UIMARelationMutableTreeNode parent, int index) {
			super.insertNodeInto((UIMARelationMutableTreeNode) newChild,
					(UIMARelationMutableTreeNode) parent, index);
			this.allNodes = VUtils.addIfNot(this.allNodes, newChild);
		}

		public void valueForPathChanged(TreePath path, Object newValue) {
		}
	}

	class UIMARelationMutableTreeNode extends DefaultMutableTreeNode {
		public static final long serialVersionUID = 0;

		UIMARelationMutableTreeNode(Object o) {
			super(o);
		}
	}

	class UIMARelationTreeModelListener implements TreeModelListener {

		public void treeNodesChanged(TreeModelEvent e) {
			UIMARelationMutableTreeNode node = (UIMARelationMutableTreeNode) (e
					.getTreePath().getLastPathComponent());
			try {
				int index = e.getChildIndices()[0];
				node = (UIMARelationMutableTreeNode) (node.getChildAt(index));
			} catch (NullPointerException exc) {
			}
		}

		public void treeNodesInserted(TreeModelEvent e) {
		}

		public void treeNodesRemoved(TreeModelEvent e) {
		}

		public void treeStructureChanged(TreeModelEvent e) {
		}
	}

	public void addRelation() {
		UIMATreeAnnotation subject = UIMATypeSystem.currentTypeSystem.resultJTree
				.getSelectedAnnotation();
		UIMATreeAnnotation modifier = UIMATypeSystem.currentTypeSystem.resultJTree
				.getLastSelectedAnnotation();
		if (subject != null && modifier != null) {
			String rname = JOptionPane.showInputDialog(new JFrame(),
					"Relation Name");
			if (rname != null) {
				UIMATreeRelation relation = new UIMATreeRelation(rname,
						subject, modifier);
				this.allRelations = VUtils.addIfNot(allRelations, relation);
				subject.relations = VUtils.addIfNot(subject.relations, relation);
				reinstantiate();
			}
		}
	}

	public class UIMATreeRelation {
		String relationName = null;
		UIMATreeObject subject = null;
		UIMATreeObject modifier = null;

		public UIMATreeRelation(String rname, UIMATreeObject subject,
				UIMATreeObject modifier) {
			this.relationName = rname;
			this.subject = subject;
			this.modifier = modifier;
//			subject.relations = VUtils.add(subject.relations, this);
		}

		public String getRelationName() {
			return this.relationName;
		}

		public UIMATreeObject getSubject() {
			return this.subject;
		}

		public UIMATreeObject getModifier() {
			return this.modifier;
		}
		
		public boolean equals(Object o) {
			if (o instanceof UIMATreeRelation) {
				UIMATreeRelation rel = (UIMATreeRelation) o;
				return rel.relationName.equals(this.relationName)
						&& rel.subject.equals(this.subject)
						&& rel.modifier.equals(this.modifier);
			}
			return false;
		}

	}

	public void mouseDragged(MouseEvent e) {
	}

	public void mouseMoved(MouseEvent e) {
		if (e.isControlDown()) {
		}
	}

}
