package typesystem;

import java.awt.Dimension;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import typesystem.UIMAResultJTree.UIMATreeAnnotation;

public class AnnotationEditPane extends JPanel implements ActionListener {
	JFrame frame = null;
	JTextField text = null;
	private UIMATreeAnnotation uimaTreeAnnotation = null;
	private static String[] levels = { "document", "group", "snippet", "word",
			"token" };

	public AnnotationEditPane(JFrame frame, Point point, UIMATreeAnnotation uto) {
		this.frame = frame;
		frame.setLocation(point);
		uimaTreeAnnotation = uto;
		JLabel label = new JLabel("Name:");
		add(label);
		text = new JTextField(uto.name, 20);
		add(text);
		UIMATypeSystemComboBox cb = new UIMATypeSystemComboBox(this);
		add(cb);
		JButton button = new JButton("Remove");
		button.addActionListener(this);
		add(button);
		button = new JButton("Cancel");
		button.addActionListener(this);
		add(button);
		button = new JButton("Done");
		button.addActionListener(this);
		add(button);
	}

	public void actionPerformed(ActionEvent e) {
		String command = e.getActionCommand();
		if ("Remove".equals(command)) {
			if (UIMATypeSystem.currentTypeSystem.resultJTree.selectedNode != null) {
				UIMATypeSystem.currentTypeSystem.resultJTree.selectedNode
						.removeUIMATreeObject();
			}
			UIMATypeSystem.currentTypeSystem.resultJTree.reinstantiate();
			this.frame.dispose();
		}
		if ("Done".equals(command)) {
			this.uimaTreeAnnotation.name = text.getText();
			UIMATypeSystem.currentTypeSystem.resultJTree.reinstantiate();
			this.frame.dispose();
		} else if ("Cancel".equals(command)) {
			this.frame.dispose();
		}
	}

	class UIMATypeSystemComboBox extends JComboBox {
		public static final long serialVersionUID = 0;
		private AnnotationEditPane annotationEditPane = null;
		JComponent container = null;

		public UIMATypeSystemComboBox(AnnotationEditPane pane) {
			annotationEditPane = pane;
			setPreferredSize(new Dimension(150, 20));
			for (int i = 0; i < levels.length; i++) {
				addItem(levels[i]);
			}
			setSelectedItem(levels[0]);
			this.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					comboBoxActionPerformed(e);
				}
			});
		}

		public UIMATypeSystemComboBox(JComponent container) {
			this.container = container;
			setPreferredSize(new Dimension(150, 20));
			for (int i = 0; i < levels.length; i++) {
				addItem(levels[i]);
			}
			setSelectedItem(levels[0]);
			this.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					comboBoxActionPerformed(e);
				}
			});
		}

		public String toString() {
			Object o = getSelectedItem();
			return o.toString();
		}

		protected void comboBoxActionPerformed(ActionEvent e) {
			if ("comboBoxChanged".equals(e.getActionCommand())) {
				UIMATypeSystemComboBox cb = (UIMATypeSystemComboBox) e
						.getSource();
				String lstr = (String) cb.getSelectedItem();
				annotationEditPane.uimaTreeAnnotation.setLevel(lstr);
				UIMATypeSystem.currentTypeSystem.resultJTree.reinstantiate();
			}
		}

	}

}
